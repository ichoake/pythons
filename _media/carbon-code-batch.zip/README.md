# Carbon Batch — PATH-fixed scripts for macOS

Use these when Automator or a Droplet says `carbon-now: command not found`.

Files:
- `carbon-batch.sh` — batch renderer (zsh + robust PATH)
- `Automator_RunShellScript_example.zsh` — paste this into Automator → Run Shell Script (shell: /bin/zsh, Pass input: as arguments).
- `build_carbon_droplet.command` — builds a Droplet .app via Platypus using zsh.

Prereqs:
  brew install node
  npm i -g carbon-now-cli
  brew install --cask platypus   # only for droplet building

Tip: In Automator, set Shell = /bin/zsh (not /bin/bash).
