#!/usr/bin/env zsh
set -euo pipefail

# ---- Normalize PATH for Automator/Platypus ----
# Intel Homebrew
if [ -x /usr/local/bin/brew ]; then
  eval "$(/usr/local/bin/brew shellenv)"
fi
# Apple Silicon Homebrew
if [ -x /opt/homebrew/bin/brew ]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
fi
# Common global npm locations
export PATH="$HOME/.npm-global/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
# nvm (if present)
if [ -s "$HOME/.nvm/nvm.sh" ]; then
  . "$HOME/.nvm/nvm.sh"
  nvm use --lts >/dev/null 2>&1 || true
fi
# Yarn global (optional)
export PATH="$HOME/.yarn/bin:$HOME/.config/yarn/global/node_modules/.bin:$PATH"
# ----------------------------------------------

PRESET="${PRESET:-just_black}"
OUTDIR="${OUTDIR:-$HOME/Desktop/CarbonCards}"
FORMAT="${FORMAT:-png}"
EXPORT="${EXPORT:-2x}"
LANG="${LANG:-python}"
mkdir -p "$OUTDIR"
if ! command -v carbon-now >/dev/null 2>&1; then
  osascript -e 'display alert "carbon-now-cli not found" message "Install: brew install node; npm i -g carbon-now-cli"'
  exit 1
fi
for f in "$@"; do
  [ -f "$f" ] || continue
  carbon-now "$f" --preset "$PRESET" --language "$LANG" --type "$FORMAT" --export-size "$EXPORT" --save-to "$OUTDIR" --title "$(basename "$f")"
done
echo "Done → $OUTDIR"
