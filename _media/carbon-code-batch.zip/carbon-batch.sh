#!/usr/bin/env zsh
set -euo pipefail

# ---- Normalize PATH for Automator/Platypus ----
# Intel Homebrew
if [ -x /usr/local/bin/brew ]; then
  eval "$(/usr/local/bin/brew shellenv)"
fi
# Apple Silicon Homebrew
if [ -x /opt/homebrew/bin/brew ]; then
  eval "$(/opt/homebrew/bin/brew shellenv)"
fi
# Common global npm locations
export PATH="$HOME/.npm-global/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
# nvm (if present)
if [ -s "$HOME/.nvm/nvm.sh" ]; then
  . "$HOME/.nvm/nvm.sh"
  nvm use --lts >/dev/null 2>&1 || true
fi
# Yarn global (optional)
export PATH="$HOME/.yarn/bin:$HOME/.config/yarn/global/node_modules/.bin:$PATH"
# ----------------------------------------------


if ! command -v carbon-now >/dev/null 2>&1; then
  echo "❌ carbon-now-cli not found in PATH."
  echo "   Install with: brew install node && npm i -g carbon-now-cli"
  exit 1
fi

PRESET="${PRESET:-just_black}"
OUTDIR="${OUTDIR:-$HOME/Desktop/CarbonCards}"
FORMAT="${FORMAT:-png}"
EXPORT="${EXPORT:-2x}"
LANG="${LANG:-python}"

mkdir -p "$OUTDIR"

if [ "$#" -eq 0 ]; then
  echo "Drop files onto the app / Quick Action, or pass paths as arguments."
  exit 0
fi

count_ok=0; count_skip=0
for f in "$@"; do
  if [ ! -f "$f" ]; then
    echo "⚠️  Skip (not found): $f"; ((count_skip++)) || true; continue
  fi
  echo "▶︎ Rendering: $f"
  carbon-now "$f"     --preset "$PRESET" --language "$LANG"     --type "$FORMAT" --export-size "$EXPORT"     --save-to "$OUTDIR" --title "$(basename "$f")"
  ((count_ok++)) || true
done

echo "✅ Done. Rendered: $count_ok | Skipped: $count_skip"
echo "📁 Output: $OUTDIR"
