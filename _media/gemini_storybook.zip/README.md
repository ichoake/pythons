# Gemini Storybook Downloader (macOS)

Downloads **public** Gemini storybook/share pages and their assets (images, videos, audio) using Playwright (headless Chromium). Saves a fully rendered `page.html`, extracted `text.md`, `metadata.json`, and an `assets/` folder with a `manifest.csv`.

## Quick Start

```bash
# 1) Create a venv (recommended)
python3 -m venv .venv
source .venv/bin/activate

# 2) Install deps
pip install -r requirements.txt

# 3) Install Chromium for Playwright (first time only)
playwright install chromium

# 4) Run on your links (edit urls.txt as needed)
python gemini_storybook_downloader.py --file urls.txt
# or:
python gemini_storybook_downloader.py https://gemini.google.com/gem/storybook/dd80e41b93e6a1e0
```

Outputs go to `./downloads/<title-or-id>/`.

## Notes

- Works best with **public share** URLs like:
  - `https://gemini.google.com/gem/storybook/<id>`
  - `https://g.co/gemini/share/<id>`
- If a page is behind login, the script will save whatever it can render (you may see a sign-in page).
- Deduplicates files by content hash and writes `manifest.csv`.
- You can re-run; existing files are kept (hash prevents duplicates).

## Troubleshooting

- If you see errors about Playwright, re-run:
  ```bash
  playwright install chromium
  ```
- If your Python is 3.11+, the requirements should install cleanly.
- To capture even more assets, try increasing batch size or adding additional selectors in `gather_src_candidates`.

## License

MIT (do what you want, no warranty).
