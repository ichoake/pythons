"""Axolotl CLI module initialization."""

import os

os.environ["HF_HUB_ENABLE_HF_TRANSFER"] = "1"
