"""
Various shared constants
"""

DEFAULT_DATASET_PREPARED_PATH = "last_run_prepared"
