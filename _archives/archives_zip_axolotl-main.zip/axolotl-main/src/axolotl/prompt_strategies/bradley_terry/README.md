### example yaml

```yaml
chat_template: gemma
datasets:
  - path: argilla/distilabel-intel-orca-dpo-pairs
    type: bradley_terry.chat_template
val_set_size: 0.0
output_dir: ./outputs/out
```
