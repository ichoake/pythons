#!/usr/bin/env python3
"""
API Selector - Interactive menu to choose which APIs to enable
"""

import os
import webbrowser
import time
import sys

class APISelector:
    def __init__(self):
        self.api_service_mapping = {
            "PERPLEXITY_API_KEY": "llm-apis.env",
            "GEMINI_API_KEY": "llm-apis.env",
            "XAI_API_KEY": "llm-apis.env",
            "HUGGINGFACE_API_KEY": "llm-apis.env",
            "LEONARDO_API_KEY": "art-vision.env",
            "IMAGGA_API_KEY": "art-vision.env",
            "STABILITY_API_KEY": "art-vision.env",
            "REPLICATE_API_TOKEN": "art-vision.env",
            "RUNWAY_API_KEY": "art-vision.env",
            "IDEOGRAM_API_KEY": "art-vision.env",
            "KAIBER_API_KEY": "art-vision.env",
            "PIKA_API_KEY": "art-vision.env",
            "SUNO_API_KEY": "audio-music.env",
            "ELEVENLABS_API_KEY": "audio-music.env",
            "ASSEMBLYAI_API_KEY": "audio-music.env",
            "DEEPGRAM_API_KEY": "audio-music.env",
            "INVIDEO_API_KEY": "audio-music.env",
            "SORAI_API_KEY": "audio-music.env",
            "COHERE_API_KEY": "llm-apis.env",
            "FIREWORKS_API_KEY": "llm-apis.env",
            "PINECONE_API_KEY": "vector-memory.env",
            "SUPABASE_KEY": "vector-memory.env",
            "QDRANT_API_KEY": "vector-memory.env",
            "OPENROUTER_API_KEY": "llm-apis.env",
            "LANGSMITH_API_KEY": "llm-apis.env",
            "SERPAPI_KEY": "seo-analytics.env",
            "NEWSAPI_KEY": "seo-analytics.env",
            "AZURE_OPENAI_KEY": "cloud-infrastructure.env",
            "TWILIO_ACCOUNT_SID": "notifications.env",
            "ZAPIER_API_KEY": "automation-agents.env",
            "MAKE_API_KEY": "automation-agents.env",
            "NOTION_TOKEN": "documents.env",
            "SLITE_API_KEY": "documents.env",
            "CHROMADB_API_KEY": "vector-memory.env",
            "ZEP_API_KEY": "vector-memory.env",
            "MOONVALLEY_API_KEY": "other-tools.env",
            "ARCGIS_API_KEY": "other-tools.env",
            "SUPERNORMAL_API_KEY": "other-tools.env",
            "DESCRIPT_API_KEY": "other-tools.env",
            "SONIX_API_KEY": "other-tools.env",
            "REVAI_API_KEY": "other-tools.env",
            "SPEECHMATICS_API_KEY": "other-tools.env",
        }
        self.services = {
            # HIGH PRIORITY - AI/LLM Services
            "xai": {
                "name": "xAI (Grok)",
                "url": "https://console.x.ai/",
                "key": "XAI_API_KEY",
                "description": "Elon Musk's AI company - Grok models",
                "priority": "HIGH",
                "essential": True
            },
            "perplexity": {
                "name": "Perplexity AI",
                "url": "https://www.perplexity.ai/settings/api",
                "key": "PERPLEXITY_API_KEY",
                "description": "AI-powered search and research",
                "priority": "HIGH",
                "essential": True
            },
            "gemini": {
                "name": "Google Gemini",
                "url": "https://makersuite.google.com/app/apikey",
                "key": "GEMINI_API_KEY",
                "description": "Google's AI model (free tier available)",
                "priority": "HIGH",
                "essential": True
            },
            "huggingface": {
                "name": "Hugging Face",
                "url": "https://huggingface.co/settings/tokens",
                "key": "HUGGINGFACE_API_KEY",
                "description": "Open source AI models and datasets",
                "priority": "HIGH",
                "essential": False
            },
            
            # IMAGE GENERATION
            "leonardo": {
                "name": "Leonardo AI",
                "url": "https://leonardo.ai/",
                "key": "LEONARDO_API_KEY",
                "description": "AI image generation",
                "priority": "MEDIUM",
                "essential": False
            },
            "stability": {
                "name": "Stability AI",
                "url": "https://platform.stability.ai/account/keys",
                "key": "STABILITY_API_KEY",
                "description": "Stable Diffusion and image generation",
                "priority": "MEDIUM",
                "essential": False
            },
            "replicate": {
                "name": "Replicate",
                "url": "https://replicate.com/account/api-tokens",
                "key": "REPLICATE_API_TOKEN",
                "description": "Run AI models in the cloud",
                "priority": "MEDIUM",
                "essential": False
            },
            "runway": {
                "name": "Runway ML",
                "url": "https://runwayml.com/",
                "key": "RUNWAY_API_KEY",
                "description": "AI video and image generation",
                "priority": "LOW",
                "essential": False
            },
            "ideogram": {
                "name": "Ideogram",
                "url": "https://ideogram.ai/",
                "key": "IDEOGRAM_API_KEY",
                "description": "AI image generation with text",
                "priority": "LOW",
                "essential": False
            },
            "kaiber": {
                "name": "Kaiber",
                "url": "https://kaiber.ai/",
                "key": "KAIBER_API_KEY",
                "description": "AI music video generation",
                "priority": "LOW",
                "essential": False
            },
            "pika": {
                "name": "Pika Labs",
                "url": "https://pika.art/",
                "key": "PIKA_API_KEY",
                "description": "AI video generation",
                "priority": "LOW",
                "essential": False
            },
            
            # AUDIO/VIDEO
            "suno": {
                "name": "Suno AI",
                "url": "https://suno.ai/",
                "key": "SUNO_API_KEY",
                "description": "AI music generation",
                "priority": "MEDIUM",
                "essential": False
            },
            "elevenlabs": {
                "name": "ElevenLabs",
                "url": "https://elevenlabs.io/app/settings/api-keys",
                "key": "ELEVENLABS_API_KEY",
                "description": "AI voice synthesis",
                "priority": "MEDIUM",
                "essential": False
            },
            "assemblyai": {
                "name": "AssemblyAI",
                "url": "https://www.assemblyai.com/dashboard/signup",
                "key": "ASSEMBLYAI_API_KEY",
                "description": "Speech-to-text API",
                "priority": "LOW",
                "essential": False
            },
            "deepgram": {
                "name": "Deepgram",
                "url": "https://console.deepgram.com/signup",
                "key": "DEEPGRAM_API_KEY",
                "description": "Speech recognition and understanding",
                "priority": "LOW",
                "essential": False
            },
            "invideo": {
                "name": "InVideo",
                "url": "https://invideo.io/",
                "key": "INVIDEO_API_KEY",
                "description": "AI video creation",
                "priority": "LOW",
                "essential": False
            },
            "sora": {
                "name": "Sora AI",
                "url": "https://openai.com/sora",
                "key": "SORAI_API_KEY",
                "description": "OpenAI's video generation",
                "priority": "LOW",
                "essential": False
            },
            
            # AUTOMATION & VECTOR DB
            "cohere": {
                "name": "Cohere",
                "url": "https://dashboard.cohere.ai/",
                "key": "COHERE_API_KEY",
                "description": "Language AI platform",
                "priority": "MEDIUM",
                "essential": False
            },
            "fireworks": {
                "name": "Fireworks AI",
                "url": "https://fireworks.ai/",
                "key": "FIREWORKS_API_KEY",
                "description": "Fast inference for open source models",
                "priority": "MEDIUM",
                "essential": False
            },
            "pinecone": {
                "name": "Pinecone",
                "url": "https://app.pinecone.io/",
                "key": "PINECONE_API_KEY",
                "description": "Vector database for AI",
                "priority": "MEDIUM",
                "essential": False
            },
            "supabase": {
                "name": "Supabase",
                "url": "https://supabase.com/dashboard",
                "key": "SUPABASE_KEY",
                "description": "Open source Firebase alternative",
                "priority": "LOW",
                "essential": False
            },
            "qdrant": {
                "name": "Qdrant",
                "url": "https://cloud.qdrant.io/",
                "key": "QDRANT_API_KEY",
                "description": "Vector database and similarity search",
                "priority": "LOW",
                "essential": False
            },
            "openrouter": {
                "name": "OpenRouter",
                "url": "https://openrouter.ai/",
                "key": "OPENROUTER_API_KEY",
                "description": "Universal API for LLMs",
                "priority": "MEDIUM",
                "essential": False
            },
            "langsmith": {
                "name": "LangSmith",
                "url": "https://smith.langchain.com/",
                "key": "LANGSMITH_API_KEY",
                "description": "LangChain's debugging and monitoring",
                "priority": "LOW",
                "essential": False
            },
            
            # SEARCH & NEWS
            "serpapi": {
                "name": "SerpAPI",
                "url": "https://serpapi.com/",
                "key": "SERPAPI_KEY",
                "description": "Google search results API",
                "priority": "MEDIUM",
                "essential": False
            },
            "newsapi": {
                "name": "NewsAPI",
                "url": "https://newsapi.org/register",
                "key": "NEWSAPI_KEY",
                "description": "News headlines API",
                "priority": "LOW",
                "essential": False
            },
            
            # CLOUD & INFRASTRUCTURE
            "azure": {
                "name": "Azure OpenAI",
                "url": "https://portal.azure.com/",
                "key": "AZURE_OPENAI_KEY",
                "description": "Microsoft's OpenAI service",
                "priority": "LOW",
                "essential": False
            },
            
            # AUTOMATION
            "twilio": {
                "name": "Twilio",
                "url": "https://console.twilio.com/",
                "key": "TWILIO_ACCOUNT_SID",
                "description": "Communication platform (SMS, voice, etc.)",
                "priority": "LOW",
                "essential": False
            },
            "zapier": {
                "name": "Zapier",
                "url": "https://zapier.com/app/settings/integrations",
                "key": "ZAPIER_API_KEY",
                "description": "Workflow automation",
                "priority": "LOW",
                "essential": False
            },
            "make": {
                "name": "Make (Integromat)",
                "url": "https://www.make.com/",
                "key": "MAKE_API_KEY",
                "description": "Visual automation platform",
                "priority": "LOW",
                "essential": False
            },
            
            # DOCUMENTS & KNOWLEDGE
            "notion": {
                "name": "Notion",
                "url": "https://www.notion.so/my-integrations",
                "key": "NOTION_TOKEN",
                "description": "All-in-one workspace",
                "priority": "LOW",
                "essential": False
            },
            "slite": {
                "name": "Slite",
                "url": "https://slite.com/",
                "key": "SLITE_API_KEY",
                "description": "Team knowledge base",
                "priority": "LOW",
                "essential": False
            },
            
            # VECTOR & MEMORY
            "chroma": {
                "name": "Chroma",
                "url": "https://www.trychroma.com/",
                "key": "CHROMADB_API_KEY",
                "description": "Open source vector database",
                "priority": "LOW",
                "essential": False
            },
            "zep": {
                "name": "Zep",
                "url": "https://www.getzep.com/",
                "key": "ZEP_API_KEY",
                "description": "Long-term memory for AI applications",
                "priority": "LOW",
                "essential": False
            }
        }
    
    def display_menu(self, selected=None):
        """Display the selection menu"""
        if selected is None:
            selected = set()
        
        print("\n🤖 API Selector - Choose which APIs to enable")
        print("=" * 60)
        print("Select APIs by typing their numbers (space-separated)")
        print("Examples: '1 2 3' or '1-5' or 'all' or 'essential'")
        print("Commands: 'q'=quit, 'r'=reset, 's'=show selected, 'o'=open selected")
        print()
        
        # Group by priority
        high_priority = [(k, v) for k, v in self.services.items() if v['priority'] == 'HIGH']
        medium_priority = [(k, v) for k, v in self.services.items() if v['priority'] == 'MEDIUM']
        low_priority = [(k, v) for k, v in self.services.items() if v['priority'] == 'LOW']
        
        all_items = []
        
        print("🔥 HIGH PRIORITY (Essential for AI CLI):")
        for i, (key, service) in enumerate(high_priority, 1):
            status = "✅" if key in selected else "  "
            essential = " ⭐" if service['essential'] else ""
            print(f"{status} {i:2d}. {service['name']}{essential}")
            print(f"     {service['description']}")
            all_items.append((key, service))
        
        print(f"\n⚡ MEDIUM PRIORITY (Great features):")
        for i, (key, service) in enumerate(medium_priority, len(high_priority) + 1):
            status = "✅" if key in selected else "  "
            print(f"{status} {i:2d}. {service['name']}")
            print(f"     {service['description']}")
            all_items.append((key, service))
        
        print(f"\n📋 LOW PRIORITY (Specialized tools):")
        for i, (key, service) in enumerate(low_priority, len(high_priority) + len(medium_priority) + 1):
            status = "✅" if key in selected else "  "
            print(f"{status} {i:2d}. {service['name']}")
            print(f"     {service['description']}")
            all_items.append((key, service))
        
        return all_items
    
    def parse_selection(self, input_str, all_items):
        """Parse user input and return selected keys"""
        input_str = input_str.strip().lower()
        
        if input_str == 'q':
            return 'quit'
        elif input_str == 'r':
            return 'reset'
        elif input_str == 's':
            return 'show'
        elif input_str == 'o':
            return 'open'
        elif input_str == 'all':
            return set(self.services.keys())
        elif input_str == 'essential':
            return set(k for k, v in self.services.items() if v['essential'])
        elif input_str == '':
            return set()
        
        selected = set()
        
        # Parse ranges and individual numbers
        parts = input_str.split()
        for part in parts:
            if '-' in part:
                # Handle ranges like "1-5"
                try:
                    start, end = map(int, part.split('-'))
                    for i in range(start, end + 1):
                        if 1 <= i <= len(all_items):
                            selected.add(all_items[i-1][0])
                except ValueError:
                    pass
            else:
                # Handle individual numbers
                try:
                    num = int(part)
                    if 1 <= num <= len(all_items):
                        selected.add(all_items[num-1][0])
                except ValueError:
                    pass
        
        return selected
    
    def open_selected_apis(self, selected_keys):
        """Open registration pages for selected APIs"""
        if not selected_keys:
            print("❌ No APIs selected!")
            return
        
        print(f"\n🚀 Opening registration pages for {len(selected_keys)} selected APIs...")
        print("=" * 60)
        
        for key in selected_keys:
            service = self.services[key]
            print(f"🌐 Opening {service['name']}...")
            print(f"   {service['description']}")
            print(f"   {service['url']}")
            
            try:
                webbrowser.open(service['url'])
                time.sleep(0.5)  # Small delay between opens
                print(f"   ✅ Opened")
            except Exception as e:
                print(f"   ❌ Error: {e}")
            print()
        
        print(f"✅ Opened {len(selected_keys)} registration pages!")
        print("\n📝 Next steps:")
        print("1. Sign up and get API keys from the opened pages")
        print("2. Add the keys to the appropriate categorized files in your ~/.env.d directory.")
        print("3. Run 'source ~/.env.d/loader.sh' to load the new keys.")
        print("4. Test with: grok 'Hello world!' (after setting XAI_API_KEY)")

        # Show template for .env file
        print(f"\n📄 Add these to your categorized .env files in ~/.env.d:")
        print("-" * 40)
        for key in selected_keys:
            service = self.services[key]
            category_file = self.api_service_mapping.get(service['key'], "other-tools.env")
            print(f"In ~/.env.d/{category_file}:")
            print(f"{service['key']}=your-{key}-key-here")
            print()
    
    def show_selected(self, selected_keys):
        """Show currently selected APIs"""
        if not selected_keys:
            print("❌ No APIs selected!")
            return
        
        print(f"\n✅ Currently selected ({len(selected_keys)} APIs):")
        print("=" * 50)
        
        for key in sorted(selected_keys):
            service = self.services[key]
            priority_icon = {"HIGH": "🔥", "MEDIUM": "⚡", "LOW": "📋"}[service['priority']]
            essential = " ⭐" if service['essential'] else ""
            print(f"{priority_icon} {service['name']}{essential}")
            print(f"   {service['description']}")
            print(f"   Key: {service['key']}")
            print()
    
    def run(self):
        """Main interactive loop"""
        selected = set()
        
        while True:
            all_items = self.display_menu(selected)
            
            print(f"\nSelected: {len(selected)} APIs")
            print("Enter your selection: ", end="")
            
            try:
                user_input = input().strip()
            except (EOFError, KeyboardInterrupt):
                print("\n👋 Goodbye!")
                break
            
            if not user_input:
                continue
            
            result = self.parse_selection(user_input, all_items)
            
            if result == 'quit':
                print("👋 Goodbye!")
                break
            elif result == 'reset':
                selected = set()
                print("🔄 Selection reset!")
            elif result == 'show':
                self.show_selected(selected)
            elif result == 'open':
                self.open_selected_apis(selected)
            elif isinstance(result, set):
                selected = result
                print(f"✅ Updated selection: {len(selected)} APIs selected")

def main():
    selector = APISelector()
    selector.run()

if __name__ == "__main__":
    main()