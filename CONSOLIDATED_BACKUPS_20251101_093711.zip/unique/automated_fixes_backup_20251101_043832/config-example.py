# Reddit Praw
praw_client_id = "xxxxxx"
praw_client_secret = "xxxxxx"
praw_user_agent = "xxxxxx"

# Amazon Polly
aws_access_key_id = "xxxxxx"
aws_secret_access_key = "xxxxxx"
