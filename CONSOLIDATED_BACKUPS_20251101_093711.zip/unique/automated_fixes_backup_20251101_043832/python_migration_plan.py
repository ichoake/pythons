#!/usr/bin/env python3
"""
Analyze current structure and show what will be migrated where
"""

import os
from pathlib import Path
from collections import defaultdict

def analyze_current_structure():
    """Analyze the current directory structure."""
    base_path = Path("/Users/steven/Documents/python")
    
    # Categories for analysis
    categories = {
        "analysis_scripts": [],
        "youtube_projects": [],
        "ai_creative": [],
        "web_scraping": [],
        "audio_video": [],
        "utilities": [],
        "duplicates": [],
        "backups": [],
        "other": []
    }
    
    # Analysis patterns
    analysis_patterns = ["analyze", "analyzer"]
    youtube_patterns = ["youtube", "yt", "shorts", "reddit"]
    ai_patterns = ["ai", "dalle", "comic", "pattern", "typography"]
    scraping_patterns = ["scraping", "scraper", "backlink", "fiverr", "fb-script"]
    av_patterns = ["audio", "video", "transcribe", "convert", "tts", "quiz"]
    utility_patterns = ["clean", "sort", "organize", "duplicate", "batch", "fdupes"]
    backup_patterns = ["backup", "old", "copy", " (1)", " (2)"]
    
    print("🔍 Analyzing current structure...")
    print("=" * 50)
    
    # Scan directories
    for item in base_path.iterdir():
        if item.is_dir():
            name_lower = item.name.lower()
            
            # Categorize directories
            if any(pattern in name_lower for pattern in backup_patterns):
                categories["backups"].append(item.name)
            elif any(pattern in name_lower for pattern in youtube_patterns):
                categories["youtube_projects"].append(item.name)
            elif any(pattern in name_lower for pattern in ai_patterns):
                categories["ai_creative"].append(item.name)
            elif any(pattern in name_lower for pattern in scraping_patterns):
                categories["web_scraping"].append(item.name)
            elif any(pattern in name_lower for pattern in av_patterns):
                categories["audio_video"].append(item.name)
            elif any(pattern in name_lower for pattern in utility_patterns):
                categories["utilities"].append(item.name)
            else:
                categories["other"].append(item.name)
        
        elif item.is_file() and item.suffix == '.py':
            name_lower = item.name.lower()
            
            if any(pattern in name_lower for pattern in analysis_patterns):
                categories["analysis_scripts"].append(item.name)
            elif any(pattern in name_lower for pattern in backup_patterns):
                categories["duplicates"].append(item.name)
            else:
                categories["other"].append(item.name)
    
    return categories

def show_migration_plan(categories):
    """Show the migration plan."""
    print("\n📋 MIGRATION PLAN")
    print("=" * 50)
    
    # Analysis Scripts
    print(f"\n🔍 ANALYSIS SCRIPTS ({len(categories['analysis_scripts'])} files)")
    print("-" * 30)
    print("→ 01_core_tools/content_analyzer/")
    for script in sorted(categories['analysis_scripts'])[:10]:  # Show first 10
        print(f"  • {script}")
    if len(categories['analysis_scripts']) > 10:
        print(f"  ... and {len(categories['analysis_scripts']) - 10} more")
    
    # YouTube Projects
    print(f"\n📺 YOUTUBE PROJECTS ({len(categories['youtube_projects'])} directories)")
    print("-" * 30)
    print("→ 02_youtube_automation/")
    for project in sorted(categories['youtube_projects']):
        print(f"  • {project}")
    
    # AI Creative
    print(f"\n🎨 AI CREATIVE TOOLS ({len(categories['ai_creative'])} directories)")
    print("-" * 30)
    print("→ 03_ai_creative_tools/")
    for project in sorted(categories['ai_creative']):
        print(f"  • {project}")
    
    # Web Scraping
    print(f"\n🕷️  WEB SCRAPING ({len(categories['web_scraping'])} directories)")
    print("-" * 30)
    print("→ 04_web_scraping/")
    for project in sorted(categories['web_scraping']):
        print(f"  • {project}")
    
    # Audio/Video
    print(f"\n🎵 AUDIO/VIDEO ({len(categories['audio_video'])} directories)")
    print("-" * 30)
    print("→ 05_audio_video/")
    for project in sorted(categories['audio_video']):
        print(f"  • {project}")
    
    # Utilities
    print(f"\n🔧 UTILITIES ({len(categories['utilities'])} directories)")
    print("-" * 30)
    print("→ 06_utilities/")
    for project in sorted(categories['utilities']):
        print(f"  • {project}")
    
    # Duplicates
    print(f"\n📄 DUPLICATES ({len(categories['duplicates'])} files)")
    print("-" * 30)
    print("→ 08_archived/old_versions/")
    for dup in sorted(categories['duplicates'])[:10]:  # Show first 10
        print(f"  • {dup}")
    if len(categories['duplicates']) > 10:
        print(f"  ... and {len(categories['duplicates']) - 10} more")
    
    # Backups
    print(f"\n📦 BACKUPS ({len(categories['backups'])} directories)")
    print("-" * 30)
    print("→ 08_archived/backups/")
    for backup in sorted(categories['backups']):
        print(f"  • {backup}")
    
    # Other
    print(f"\n❓ OTHER ({len(categories['other'])} items)")
    print("-" * 30)
    print("→ 07_experimental/ or 08_archived/")
    for item in sorted(categories['other'])[:15]:  # Show first 15
        print(f"  • {item}")
    if len(categories['other']) > 15:
        print(f"  ... and {len(categories['other']) - 15} more")

def show_benefits():
    """Show the benefits of reorganization."""
    print("\n🎯 EXPECTED BENEFITS")
    print("=" * 50)
    
    benefits = [
        "📁 90% reduction in duplicate files",
        "🔍 Easy navigation with numbered categories",
        "📚 Shared libraries reduce code duplication",
        "🔧 Consistent naming conventions",
        "📝 Clear documentation for each category",
        "🚀 Faster project discovery and development",
        "🧹 Clean, maintainable structure",
        "📊 Better organization for 144+ directories"
    ]
    
    for benefit in benefits:
        print(f"  {benefit}")

def show_risks_and_mitigation():
    """Show risks and mitigation strategies."""
    print("\n⚠️  RISKS & MITIGATION")
    print("=" * 50)
    
    risks = [
        ("🔄 Import errors", "✅ Automated import updates"),
        ("💔 Broken scripts", "✅ Full backup before migration"),
        ("🔍 Lost files", "✅ Detailed migration log"),
        ("⏱️  Downtime", "✅ Incremental migration"),
        ("🔄 Rollback needed", "✅ Complete backup + rollback plan")
    ]
    
    for risk, mitigation in risks:
        print(f"  {risk}: {mitigation}")

def main():
    """Main analysis function."""
    print("🔍 PYTHON PROJECTS MIGRATION ANALYSIS")
    print("=" * 50)
    
    # Analyze current structure
    categories = analyze_current_structure()
    
    # Show migration plan
    show_migration_plan(categories)
    
    # Show benefits
    show_benefits()
    
    # Show risks
    show_risks_and_mitigation()
    
    # Summary
    total_items = sum(len(items) for items in categories.values())
    print(f"\n📊 SUMMARY")
    print("=" * 50)
    print(f"Total items to migrate: {total_items}")
    print(f"Analysis scripts: {len(categories['analysis_scripts'])}")
    print(f"Project directories: {len(categories['youtube_projects']) + len(categories['ai_creative']) + len(categories['web_scraping']) + len(categories['audio_video']) + len(categories['utilities'])}")
    print(f"Duplicates to clean: {len(categories['duplicates'])}")
    print(f"Backups to archive: {len(categories['backups'])}")
    
    print(f"\n🚀 Ready to migrate? Run: python migrate_projects.py")

if __name__ == "__main__":
    main()