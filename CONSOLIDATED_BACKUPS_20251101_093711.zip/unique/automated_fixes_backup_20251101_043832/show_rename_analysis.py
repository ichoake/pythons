#!/usr/bin/env python3
"""Show what was actually analyzed for each rename"""
import csv
import ast
from pathlib import Path

csv_file = "/Users/steven/rename_results_20251031_221542.csv"

print("🔍 ANALYZING RENAMED FILES (showing actual content)\n")
print("="*100)

with open(csv_file, 'r') as f:
    reader = csv.DictReader(f)

    # Focus on problematic renames
    for row in reader:
        old_name = row['Old Name']
        new_name = row['New Name']
        full_new_path = row['Full New Path']

        # Check for generic names or specific problem files
        if new_name == 'youtube_tool.py' or old_name in ['quiz-.py', '169-.py', 'midj--.py']:
            print(f"\n📄 {old_name} → {new_name}")
            print(f"   Path: {full_new_path}")

            # Analyze actual content
            try:
                with open(full_new_path, 'r', encoding='utf-8', errors='ignore') as file:
                    content = file.read()
                    tree = ast.parse(content)

                    funcs = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
                    classes = [node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]

                    print(f"   🔧 Functions found: {funcs[:5]}")
                    print(f"   📦 Classes found: {classes[:3]}")

                    # Suggest better name
                    if funcs and funcs[0] not in ['main', '__init__']:
                        better = f"{funcs[0]}.py"
                        print(f"   💡 SHOULD BE: {better}")
                    elif classes:
                        better = f"{classes[0]}.py"
                        print(f"   💡 SHOULD BE: {better}")

            except Exception as e:
                print(f"   ❌ Error analyzing: {e}")

print("\n" + "="*100)
print("\n🎯 ISSUE: Tool fell back to generic 'youtube_tool.py' when it couldn't find good content")
print("💡 SOLUTION: Need to show analysis results and avoid generic fallbacks!")
