import os
import shutil

# Path to the CSV file
csv_path = "/Users/steven/image_list.csv"

# The root directory where you want to backup the files
backup_root = "/Volumes/iMac/backup"

# The root directory where you want to move the files
destination_root = "/Volumes/iMac/ogMac images"

# Open and read the CSV file line by line
with open(csv_path, "r") as file:
    for line in file:
        file_path = line.strip()
        if file_path:
            # For backup: Generate the backup path and copy the file
            backup_path = os.path.join(
                backup_root,
                os.path.relpath(file_path, start=os.path.commonpath([file_path])),
            )
            os.makedirs(os.path.dirname(backup_path), exist_ok=True)
            shutil.copy(file_path, backup_path)

            # For move: Generate the destination path and move the file
            destination_path = os.path.join(
                destination_root,
                os.path.relpath(file_path, start=os.path.commonpath([file_path])),
            )
            os.makedirs(os.path.dirname(destination_path), exist_ok=True)
            shutil.move(file_path, destination_path)
            print(f"Backed up and moved {file_path} to {destination_path}")
