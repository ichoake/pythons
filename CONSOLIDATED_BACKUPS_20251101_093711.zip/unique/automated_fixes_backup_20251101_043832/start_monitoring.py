#!/usr/bin/env python3
"""
Start Periodic Quality Monitoring
=================================

Starts the periodic quality monitoring system.
"""

import sys
import os
from pathlib import Path

# Add the development tools to the path
sys.path.insert(0, str(Path(__file__).parent / "06_development_tools"))

from periodic_quality_monitor import PeriodicQualityMonitor

if __name__ == "__main__":
    base_path = Path(__file__).parent
    monitor = PeriodicQualityMonitor(str(base_path))
    
    print("🚀 Starting Periodic Quality Monitoring...")
    print("Press Ctrl+C to stop")
    
    try:
        monitor.start_monitoring()
    except KeyboardInterrupt:
        print("\n⏹️ Monitoring stopped by user")
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)
