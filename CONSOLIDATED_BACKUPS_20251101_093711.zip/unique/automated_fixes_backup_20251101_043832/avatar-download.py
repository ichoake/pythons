import os

import paramiko

# SSH Config
hostname = "access981577610.webspace-data.io"
username = "u114071855"
password = "A^p1yT@AHn*akbhs"
local_dir = "/Users/steven/AvaTarArTs"
rremote_dirs = [
    "/2025",
    "/Users",
    "/all",
    "/audio-texts",
    "/blog",
    "/build",
    "/card",
    "/city",
    "/clickandbuilds",
    "/convo",
    "/covers",
    "/covers-bak",
    "/css",
    "/csv",
    "/dad",
    "/dalle",
    "/disco",
    "/docs",
    "/etsy",
    "/flow",
    "/follow",
    "/gdrive",
    "/html",
    "/images",
    "/img",
    "/leo",
    "/leoai",
    "/leonardo",
    "/march",
    "/md",
    "/melody",
    "/mp4",
    "/music",
    "/mydesigns",
    "/number",
    "/ny",
    "/oct",
    "/og",
    "/pdf",
    "/python",
    "/repo",
    "/seamless",
    "/test",
    "/trashy",
    "/uploads",
    "/vids",
    "/xmas",
    "/chat.html",
    "/dalle.html",
    "/dallechat.html",
    "/form.html",
    "/index.html",
    "/mush.html",
    "/pod.html",
    "/privacy.html",
    "/seamless.htm",
]


def list_remote_files(sftp, remote_path):
    try:
        return {f.filename: f.st_mtime for f in sftp.listdir_attr(remote_path)}
    except FileNotFoundError:
        print(f"Remote directory not found: {remote_path}")
        return {}


def list_local_files(local_path):
    if not os.path.exists(local_path):
        os.makedirs(local_path)
    return {
        f: os.path.getmtime(os.path.join(local_path, f)) for f in os.listdir(local_path)
    }


def download_files(sftp, remote_path, local_path):
    os.makedirs(local_path, exist_ok=True)
    for file, mtime in list_remote_files(sftp, remote_path).items():
        local_file_path = os.path.join(local_path, file)
        if (
            not os.path.exists(local_file_path)
            or os.path.getmtime(local_file_path) < mtime
        ):
            print(f"Downloading {file}...")
            sftp.get(os.path.join(remote_path, file), local_file_path)
        else:
            print(f"{file} is up-to-date.")


ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(hostname, username=username, password=password)

sftp = ssh.open_sftp()

for remote_dir in remote_dirs:
    local_path = os.path.join(local_dir, os.path.basename(remote_dir))
    print(f"Comparing files in {remote_dir}...")
    download_files(sftp, remote_dir, local_path)

sftp.close()
ssh.close()
