#!/usr/bin/env python3
"""
PyDoc Documentation Generator

This script generates HTML documentation for all Python modules
in the tehSiTes and Documents directories using Python's built-in pydoc.
"""

import os
import sys
import subprocess
import argparse
from pathlib import Path

def find_python_files(directory, exclude_dirs=None):
    """Find all Python files in a directory, excluding specified subdirectories."""
    if exclude_dirs is None:
        exclude_dirs = {'__pycache__', '.git', 'venv', 'env', 'node_modules', 'site-packages'}
    
    python_files = []
    for root, dirs, files in os.walk(directory):
        # Remove excluded directories from dirs list to prevent walking into them
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file.endswith('.py') and not file.startswith('__'):
                python_files.append(os.path.join(root, file))
    
    return python_files

def generate_pydoc_html(module_path, output_dir):
    """Generate HTML documentation for a Python module using pydoc."""
    try:
        # Get the module name from the file path
        module_name = os.path.splitext(os.path.basename(module_path))[0]
        
        # Create output filename
        output_file = os.path.join(output_dir, f"{module_name}.html")
        
        # Generate HTML documentation
        cmd = [sys.executable, '-m', 'pydoc', '-w', module_path]
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=os.path.dirname(module_path))
        
        if result.returncode == 0:
            # Move the generated file to our output directory
            generated_file = f"{module_name}.html"
            if os.path.exists(generated_file):
                os.rename(generated_file, output_file)
                print(f"✓ Generated documentation for {module_name}")
                return True
            else:
                print(f"✗ Failed to generate documentation for {module_name}")
                return False
        else:
            print(f"✗ Error generating documentation for {module_name}: {result.stderr}")
            return False
            
    except Exception as e:
        print(f"✗ Exception generating documentation for {module_path}: {e}")
        return False

def create_index_html(output_dir, modules_info):
    """Create an index HTML file listing all documented modules."""
    index_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Documentation Index</title>
    <style>
        body {{
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }}
        .stats {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }}
        .stat-number {{
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }}
        .modules-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }}
        .module-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }}
        .module-card:hover {{
            transform: translateY(-5px);
        }}
        .module-title {{
            font-size: 1.2em;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }}
        .module-path {{
            color: #666;
            font-size: 0.9em;
            margin-bottom: 10px;
        }}
        .module-link {{
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
        }}
        .module-link:hover {{
            background: #5a6fd8;
        }}
        .category {{
            margin-bottom: 40px;
        }}
        .category-title {{
            font-size: 1.5em;
            font-weight: bold;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Python Documentation Index</h1>
        <p>Generated documentation for all Python modules in tehSiTes and Documents directories</p>
    </div>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-number">{len(modules_info)}</div>
            <div>Total Modules</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len([m for m in modules_info if m['category'] == 'tehSiTes'])}</div>
            <div>tehSiTes Modules</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len([m for m in modules_info if m['category'] == 'Documents'])}</div>
            <div>Documents Modules</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">{len(set([m['category'] for m in modules_info]))}</div>
            <div>Categories</div>
        </div>
    </div>
"""

    # Group modules by category
    categories = {}
    for module in modules_info:
        category = module['category']
        if category not in categories:
            categories[category] = []
        categories[category].append(module)
    
    # Add modules by category
    for category, modules in categories.items():
        index_content += f"""
    <div class="category">
        <div class="category-title">{category} Modules</div>
        <div class="modules-grid">
"""
        for module in sorted(modules, key=lambda x: x['name']):
            index_content += f"""
            <div class="module-card">
                <div class="module-title">{module['name']}</div>
                <div class="module-path">{module['path']}</div>
                <a href="{module['filename']}" class="module-link">View Documentation</a>
            </div>
"""
        index_content += """
        </div>
    </div>
"""
    
    index_content += """
</body>
</html>
"""
    
    with open(os.path.join(output_dir, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(index_content)

def main():
    parser = argparse.ArgumentParser(description='Generate PyDoc documentation for Python modules')
    parser.add_argument('--tehsites', default='/Users/steven/tehSiTes', 
                       help='Path to tehSiTes directory')
    parser.add_argument('--documents', default='/Users/steven/Documents', 
                       help='Path to Documents directory')
    parser.add_argument('--output', default='/Users/steven/python-docs/pydoc-docs', 
                       help='Output directory for documentation')
    parser.add_argument('--exclude-venv', action='store_true', default=True,
                       help='Exclude virtual environment directories')
    
    args = parser.parse_args()
    
    # Create output directory
    os.makedirs(args.output, exist_ok=True)
    
    print("🔍 Finding Python files...")
    
    # Find Python files in both directories
    tehSiTes_files = find_python_files(args.tehsites)
    documents_files = find_python_files(args.documents)
    
    all_files = []
    all_files.extend([(f, 'tehSiTes') for f in tehSiTes_files])
    all_files.extend([(f, 'Documents') for f in documents_files])
    
    print(f"📁 Found {len(tehSiTes_files)} Python files in tehSiTes")
    print(f"📁 Found {len(documents_files)} Python files in Documents")
    print(f"📁 Total: {len(all_files)} Python files")
    
    print("\n📚 Generating documentation...")
    
    modules_info = []
    successful = 0
    failed = 0
    
    for file_path, category in all_files:
        module_name = os.path.splitext(os.path.basename(file_path))[0]
        
        if generate_pydoc_html(file_path, args.output):
            modules_info.append({
                'name': module_name,
                'path': file_path,
                'category': category,
                'filename': f"{module_name}.html"
            })
            successful += 1
        else:
            failed += 1
    
    print(f"\n📊 Documentation Generation Complete!")
    print(f"✅ Successful: {successful}")
    print(f"❌ Failed: {failed}")
    
    if modules_info:
        print("\n📝 Creating index page...")
        create_index_html(args.output, modules_info)
        print(f"🌐 Index page created: {os.path.join(args.output, 'index.html')}")
    
    print(f"\n🎉 Documentation generated in: {args.output}")
    print(f"🌐 Open index.html in your browser to view the documentation")

if __name__ == "__main__":
    main()