# utils/model_select.py
import os
from openai import OpenAI

# 🌟 Environment Variables
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
HF_KEY = os.getenv("HUGGINGFACE_API_KEY")
HF_MODEL = os.getenv("HF_TTS_MODEL", "suno/bark-small")

# 🎯 Preferred Models
PREFERRED_MODELS = ["gpt-4o-tts", "gpt-4o-audio", "gpt-4o-mini-tts"]

def choose_best_openai_model():
    """🔍 Choose the best available OpenAI model for TTS."""
    if not OPENAI_KEY:
        print("⚠️ OpenAI API key is missing.")
        return None, None

    client = OpenAI(api_key=OPENAI_KEY)
    try:
        models = [m.id for m in client.models.list().data]
        print(f"📜 Available models: {models}")
        for name in PREFERRED_MODELS:
            if name in models:
                print(f"✅ Selected model: {name}")
                return client, name
        print("❌ No preferred models available.")
    except Exception as e:
        print(f"⚠️ Error accessing OpenAI models: {e}")
    return None, None

def can_use_hf():
    """🔍 Check if Hugging Face API can be used."""
    if HF_KEY:
        print("✅ Hugging Face API key is available.")
    else:
        print("⚠️ Hugging Face API key is missing.")
    return bool(HF_KEY)

def hf_params():
    """🔧 Get Hugging Face parameters."""
    print(f"🔧 Hugging Face Model: {HF_MODEL}")
    return HF_KEY, HF_MODEL
