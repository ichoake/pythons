#!/usr/bin/env python3
"""
Quick Analysis Tool
Fast analysis of any file with AI insights
"""

import os
import sys
import subprocess

def main():
    if len(sys.argv) < 2:
        print("Usage: quick-analyze.py <file_path> [ai_service]")
        print("Available AI services: claude, xai")
        print("Examples:")
        print("  quick-analyze.py document.txt")
        print("  quick-analyze.py document.txt claude")
        print("  quick-analyze.py document.txt xai")
        sys.exit(1)
    
    file_path = sys.argv[1]
    ai_service = sys.argv[2] if len(sys.argv) > 2 else "claude"
    
    if not os.path.exists(file_path):
        print(f"❌ Error: File '{file_path}' not found")
        sys.exit(1)
    
    print(f"🔍 Quick Analysis: {os.path.basename(file_path)}")
    print("=" * 60)
    
    # Run the AI deep analyzer
    try:
        result = subprocess.run(
            ['python3', os.path.expanduser('~/ai-deep-analyzer.py'), file_path, ai_service],
            capture_output=False,
            text=True
        )
        
        if result.returncode == 0:
            print("\n✅ Analysis completed successfully!")
        else:
            print(f"\n❌ Analysis failed with return code: {result.returncode}")
            
    except Exception as e:
        print(f"❌ Error running analysis: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()