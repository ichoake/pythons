#!/usr/bin/env python3
"""
Deep File Analyzer - Comprehensive Code Quality & Improvement Analyzer

Uses local analysis (no API keys required) to provide deep insights and improvements.
"""

import os
import sys
import ast
import re
from pathlib import Path
from collections import defaultdict
from datetime import datetime
import json

class DeepFileAnalyzer:
    def __init__(self, target_dir: str):
        self.target_dir = Path(target_dir)
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        self.stats = {
            'total_files': 0,
            'analyzed': 0,
            'errors': 0,
            'improvements_found': 0
        }

        self.findings = defaultdict(list)

    def analyze_file(self, file_path: Path) -> dict:
        """Deep analysis of a single Python file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Parse AST
            try:
                tree = ast.parse(content)
            except SyntaxError as e:
                return {'error': f'Syntax error: {e}', 'improvements': []}

            improvements = []

            # 1. Check for missing docstrings
            if not ast.get_docstring(tree):
                improvements.append({
                    'type': 'missing_module_docstring',
                    'severity': 'medium',
                    'message': 'Module lacks a docstring',
                    'suggestion': 'Add a module-level docstring explaining the file purpose'
                })

            # 2. Analyze functions
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Missing docstring
                    if not ast.get_docstring(node):
                        improvements.append({
                            'type': 'missing_function_docstring',
                            'severity': 'medium',
                            'function': node.name,
                            'line': node.lineno,
                            'message': f'Function `{node.name}` lacks docstring',
                            'suggestion': 'Add docstring with parameters, returns, and description'
                        })

                    # Too many arguments
                    if len(node.args.args) > 7:
                        improvements.append({
                            'type': 'too_many_arguments',
                            'severity': 'high',
                            'function': node.name,
                            'line': node.lineno,
                            'count': len(node.args.args),
                            'message': f'Function `{node.name}` has {len(node.args.args)} parameters',
                            'suggestion': 'Consider using a config object or breaking into smaller functions'
                        })

                    # Function too long
                    if hasattr(node, 'end_lineno'):
                        func_length = node.end_lineno - node.lineno
                        if func_length > 100:
                            improvements.append({
                                'type': 'long_function',
                                'severity': 'high',
                                'function': node.name,
                                'line': node.lineno,
                                'length': func_length,
                                'message': f'Function `{node.name}` is {func_length} lines long',
                                'suggestion': 'Break into smaller, focused functions'
                            })

                # Bare except
                if isinstance(node, ast.ExceptHandler):
                    if node.type is None:
                        improvements.append({
                            'type': 'bare_except',
                            'severity': 'high',
                            'line': node.lineno,
                            'message': 'Bare except clause found',
                            'suggestion': 'Specify exception type(s) to catch'
                        })

                # TODO comments
                if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
                    if isinstance(node.value.value, str) and 'TODO' in node.value.value.upper():
                        improvements.append({
                            'type': 'todo_comment',
                            'severity': 'low',
                            'line': node.lineno,
                            'message': 'TODO comment found',
                            'content': node.value.value[:100]
                        })

            # 3. Code smells
            lines = content.split('\n')

            # Long lines
            for i, line in enumerate(lines, 1):
                if len(line) > 120:
                    improvements.append({
                        'type': 'long_line',
                        'severity': 'low',
                        'line': i,
                        'length': len(line),
                        'message': f'Line {i} is {len(line)} characters',
                        'suggestion': 'Break into multiple lines (PEP 8: 79-120 chars)'
                    })

            # Magic numbers
            for i, line in enumerate(lines, 1):
                # Find standalone numbers (not in strings, not 0, 1, -1)
                numbers = re.findall(r'\b(?<!["\'])\d{3,}\b(?!["\'])', line)
                if numbers:
                    improvements.append({
                        'type': 'magic_number',
                        'severity': 'medium',
                        'line': i,
                        'numbers': numbers,
                        'message': f'Magic number(s) found: {", ".join(numbers)}',
                        'suggestion': 'Define as named constants'
                    })

            # Hardcoded paths
            hardcoded_paths = re.findall(r'["\'](?:/[^"\s]*|[A-Z]:\\[^"\s]*)["\']', content)
            if hardcoded_paths:
                improvements.append({
                    'type': 'hardcoded_path',
                    'severity': 'high',
                    'message': f'Found {len(hardcoded_paths)} hardcoded path(s)',
                    'paths': hardcoded_paths[:5],
                    'suggestion': 'Use Path objects and configuration files'
                })

            # Print statements (should use logging)
            print_count = content.count('print(')
            if print_count > 5:
                improvements.append({
                    'type': 'excessive_prints',
                    'severity': 'medium',
                    'count': print_count,
                    'message': f'File has {print_count} print statements',
                    'suggestion': 'Use logging module instead of print()'
                })

            # 4. Complexity metrics
            cyclomatic_complexity = self._calculate_complexity(tree)
            if cyclomatic_complexity > 50:
                improvements.append({
                    'type': 'high_complexity',
                    'severity': 'high',
                    'complexity': cyclomatic_complexity,
                    'message': f'High cyclomatic complexity: {cyclomatic_complexity}',
                    'suggestion': 'Refactor to reduce complexity'
                })

            return {
                'improvements': improvements,
                'complexity': cyclomatic_complexity,
                'lines': len(lines),
                'functions': len([n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]),
                'classes': len([n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)])
            }

        except Exception as e:
            return {'error': str(e), 'improvements': []}

    def _calculate_complexity(self, tree) -> int:
        """Calculate cyclomatic complexity."""
        complexity = 1  # Base complexity

        for node in ast.walk(tree):
            if isinstance(node, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(node, ast.BoolOp):
                complexity += len(node.values) - 1

        return complexity

    def analyze_all_files(self, limit=None):
        """Analyze all Python files in target directory."""
        print(f"\n🔬 Deep File Analysis")
        print(f"Target: {self.target_dir}")
        print(f"{'='*80}\n")

        # Find all Python files
        python_files = list(self.target_dir.rglob("*.py"))

        # Exclude certain directories
        exclude_patterns = ['dedup_backup', 'bare_except_backup', 'deep_rename_backup',
                          '__pycache__', '.git', 'node_modules', 'venv', 'myenv']

        python_files = [
            f for f in python_files
            if not any(pattern in str(f) for pattern in exclude_patterns)
        ]

        if limit:
            python_files = python_files[:limit]

        self.stats['total_files'] = len(python_files)

        print(f"Analyzing {len(python_files)} files...\n")

        # Analyze each file
        file_results = []
        for i, file_path in enumerate(python_files, 1):
            if i % 100 == 0:
                print(f"Progress: {i}/{len(python_files)}...")

            try:
                result = self.analyze_file(file_path)
                result['file'] = str(file_path.relative_to(self.target_dir))

                if 'error' not in result:
                    self.stats['analyzed'] += 1
                    self.stats['improvements_found'] += len(result['improvements'])

                    # Categorize improvements
                    for improvement in result['improvements']:
                        self.findings[improvement['type']].append({
                            'file': result['file'],
                            **improvement
                        })

                    file_results.append(result)
                else:
                    self.stats['errors'] += 1

            except Exception as e:
                self.stats['errors'] += 1
                print(f"❌ Error analyzing {file_path}: {e}")

        return file_results

    def generate_report(self, file_results):
        """Generate comprehensive analysis report."""
        report_path = self.target_dir / f"DEEP_ANALYSIS_REPORT_{self.timestamp}.md"

        with open(report_path, 'w') as f:
            f.write("# 🔬 Deep File Analysis Report\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**Target:** {self.target_dir}\n\n")

            f.write("---\n\n")

            # Summary
            f.write("## 📊 Summary\n\n")
            f.write(f"- **Total Files:** {self.stats['total_files']:,}\n")
            f.write(f"- **Analyzed:** {self.stats['analyzed']:,}\n")
            f.write(f"- **Errors:** {self.stats['errors']}\n")
            f.write(f"- **Improvements Found:** {self.stats['improvements_found']:,}\n\n")

            # Top Issues
            f.write("## 🎯 Top Issues\n\n")
            issue_counts = {issue_type: len(issues) for issue_type, issues in self.findings.items()}
            sorted_issues = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)

            for issue_type, count in sorted_issues[:10]:
                f.write(f"- **{issue_type}**: {count} occurrences\n")

            f.write("\n---\n\n")

            # Detailed Findings
            f.write("## 📋 Detailed Findings\n\n")

            for issue_type, issues in sorted(self.findings.items(), key=lambda x: len(x[1]), reverse=True):
                f.write(f"### {issue_type.replace('_', ' ').title()} ({len(issues)} files)\n\n")

                # Show top 10 examples
                for issue in issues[:10]:
                    f.write(f"**{issue['file']}**")
                    if 'line' in issue:
                        f.write(f" (line {issue['line']})")
                    f.write(f"\n- {issue['message']}\n")
                    if 'suggestion' in issue:
                        f.write(f"- ✨ **Suggestion:** {issue['suggestion']}\n")
                    f.write("\n")

                if len(issues) > 10:
                    f.write(f"*... and {len(issues) - 10} more files*\n\n")

            # Files needing most attention
            f.write("\n---\n\n")
            f.write("## ⚠️ Files Needing Most Attention\n\n")

            file_issue_counts = defaultdict(int)
            for issues in self.findings.values():
                for issue in issues:
                    file_issue_counts[issue['file']] += 1

            sorted_files = sorted(file_issue_counts.items(), key=lambda x: x[1], reverse=True)

            for file_path, count in sorted_files[:20]:
                f.write(f"- **{file_path}**: {count} improvements needed\n")

        print(f"\n✅ Report saved: {report_path}")

        # Generate JSON data
        json_path = self.target_dir / f"DEEP_ANALYSIS_DATA_{self.timestamp}.json"
        with open(json_path, 'w') as f:
            json.dump({
                'stats': self.stats,
                'findings': {k: v[:100] for k, v in self.findings.items()},  # Limit for size
                'timestamp': self.timestamp
            }, f, indent=2)

        print(f"✅ Data saved: {json_path}\n")

        return report_path

def main():
    import argparse

    parser = argparse.ArgumentParser(description='Deep File Analyzer')
    parser.add_argument('--target', default='.', help='Target directory')
    parser.add_argument('--limit', type=int, help='Limit number of files to analyze')

    args = parser.parse_args()

    analyzer = DeepFileAnalyzer(args.target)
    file_results = analyzer.analyze_all_files(limit=args.limit)
    analyzer.generate_report(file_results)

    # Print summary
    print(f"\n{'='*80}")
    print("✅ ANALYSIS COMPLETE!")
    print(f"{'='*80}\n")
    print(f"Files Analyzed: {analyzer.stats['analyzed']:,}")
    print(f"Improvements Found: {analyzer.stats['improvements_found']:,}")
    print(f"Top Issues:")

    issue_counts = {k: len(v) for k, v in analyzer.findings.items()}
    for issue_type, count in sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"  - {issue_type}: {count}")

if __name__ == "__main__":
    main()
