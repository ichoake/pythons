import os
import re


def convert_to_colab(python_code):
    # Install necessary libraries
    python_code = re.sub(
        r"^\s*#\s*Install\s*required\s*libraries\s*",
        "",
        python_code,
        flags=re.MULTILINE,
    )
    python_code = re.sub(
        r"^\s*!pip\s*install\s*(\w+)",
        r"!pip install \1",
        python_code,
        flags=re.MULTILINE,
    )

    # Adjust file paths to be compatible with Colab
    python_code = re.sub(
        r'(\bopen\()([\'"])(.*?)([\'"])(\))', r'\1"/content/\3"\5', python_code
    )
    python_code = re.sub(
        r'(\bpandas.read_csv\()([\'"])(.*?)([\'"])(\))',
        r'\1"/content/\3"\5',
        python_code,
    )

    # Insert Google Drive mount code if files are referenced
    if re.search(r"/content/", python_code):
        drive_mount_code = """
from google.colab import drive
drive.mount('/content/drive')
"""
        python_code = drive_mount_code + python_code

    # Enable GPU/TPU if specified
    if "use_gpu" in python_code or "use_tpu" in python_code:
        gpu_tpu_code = """
import tensorflow as tf

if tf.test.gpu_device_name():
    print('Default GPU Device: {}'.format(tf.test.gpu_device_name()))
else:
    print("Please install GPU version of TF")

if 'COLAB_TPU_ADDR' in os.environ:
    print('Running on TPU')
else:
    print('Running on CPU')
"""
        python_code = gpu_tpu_code + python_code

    return python_code


# Prompt user for file path
file_path = input("Enter the path of the Python file to convert: ")

try:
    # Read the content of the specified file
    with open(file_path, "r") as file:
        python_code = file.read()

    # Convert the content
    converted_code = convert_to_colab(python_code)

    # Define the output file path
    output_file_path = re.sub(r"\.py$", "_colab.py", file_path)

    # Write the converted content to a new file
    with open(output_file_path, "w") as output_file:
        output_file.write(converted_code)

    print(f"Converted file saved as: {output_file_path}")

except Exception as e:
    print(f"An error occurred: {e}")
