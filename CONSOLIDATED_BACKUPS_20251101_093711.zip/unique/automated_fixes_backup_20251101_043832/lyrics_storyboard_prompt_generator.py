from openai import OpenAI

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
import os

from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()


def analyze_text(text):
    response = client.chat.completions.create(model="gpt-3.5-turbo",
        {"role": "user", "content": f"Analyze the following song transcript to extract: (1) main themes, (2) emotions, (3) key objects or characters for the images, (4) suggested lighting and color schemes, and (5) a recommended transition from one image to the next: {text}"}
    ],
    max_tokens=300,
    temperature=0.7)

    return response.choices[0].message.content.strip()

if __name__ == "__main__":
    import sys
            {"role": "user", "content": f"Analyze the following song transcript to extract: (1) main themes, (2) emotions, (3) key objects or characters for the images, (4) suggested lighting and color schemes, and (5) a recommended transition from one image to the next: {text}"}
        ],
        max_tokens=300,
        temperature=0.7
    )

    transcript_file = sys.argv[1]
    output_file = sys.argv[2]
    with open(transcript_file, "r") as f:
        transcript = f.read()

    analysis = analyze_text(transcript)
    with open(output_file, "w") as f:
        f.write(analysis)
