import os
import shutil
import subprocess
import time
from datetime import datetime


# Function to execute a system command and print its output
def run_command(command):
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    stdout, stderr = process.communicate()

    if stdout:
        print(stdout.decode())
    if stderr:
        print(stderr.decode())


# Define the log directory and create it if it does not exist
log_dir = "/Users/Steven/Documents/updateLog"
os.makedirs(log_dir, exist_ok=True)

# Get the current date in YYYY-MM-DD format and create log file
current_date = datetime.now().strftime("%Y-%m-%d")
count = 1
log_filename = f"{current_date}{count}.log"
while os.path.exists(os.path.join(log_dir, log_filename)):
    count += 1
    log_filename = f"{current_date}{count}.log"


# Dynamic progress bar function
def dynamic_progress_bar(step, total_steps, bar_length=50):
    symbols = [
        "#",
        "*",
        "-",
        "=",
        ">",
        "█",
        "▓",
        "▒",
        "░",
        "→",
        "●",
        "○",
        "★",
        "DONE",
        "LOAD",
    ]
    color_start = "\033[92m"  # Green
    color_end = "\033[0m"  # Reset

    percent_complete = step / total_steps
    completed_length = int(bar_length * percent_complete)
    remaining_length = bar_length - completed_length
    completed_symbol = symbols[step % len(symbols)]  # Change symbol at each step
    remaining_symbol = " "

    bar = f"{color_start}{completed_symbol * completed_length}{remaining_symbol * remaining_length}{color_end}"
    return f"[{bar}] {percent_complete:.0%}"


# Redirect standard output and standard error to the log file
log_file_path = os.path.join(log_dir, log_filename)
with open(log_file_path, "w") as log_file:

    def log(message):
        print(message)
        log_file.write(message + "\n")

    # Function to update Python 3.X pips
    def update_pip3():
        if not shutil.which("pip3") or not shutil.which("python3"):
            return

        log("\nUpdating Python 3.X pips")
        run_command("pip cache purge")
        run_command(
            "python3 -c \"import pkg_resources; from subprocess import call; packages = [dist.project_name for dist in pkg_resources.working_set]; call('pip install --upgrade ' + ' '.join(packages), shell=True)\""
        )
        run_command(
            "pip3 list --format=freeze | grep -v '^-e' | cut -d = -f 1 | xargs -n1 pip3 install -U"
        )

    # Function to update Brew formulas and casks
    def update_brew():
        if not shutil.which("brew"):
            return

        log("Updating Brew Formula's")
        run_command("brew update")
        run_command("brew upgrade")
        run_command("brew cleanup -s")

        log("\nUpdating Brew Casks")
        run_command("brew upgrade --cask")
        run_command("brew cleanup -s")
        run_command("brew autoremove")

        log("\nBrew Diagnostics")
        run_command("brew doctor")
        run_command("brew missing")

    # Function to update everything
    def update_all():
        update_brew()
        update_pip3()

    # Call the update-all function to start the updates
    update_all()

    # Display the dynamic progress bar
    total_steps = 15
    for step in range(1, total_steps + 1):
        log(dynamic_progress_bar(step, total_steps))
        time.sleep(0.5)  # Adding a small delay to visualize progress
