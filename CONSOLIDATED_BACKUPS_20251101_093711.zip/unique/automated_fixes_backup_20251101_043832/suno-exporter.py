#!/usr/bin/env python3
"""
SUNO Directory Conversation Exporter
Creates HTML and Markdown exports matching your existing style

Author: Steven Chaplinski
Date: October 2025
Purpose: Export conversations from SUNO directory in your existing format
"""

import os
import re
import html
from pathlib import Path
from datetime import datetime

def create_html_export(title, messages, platform="ChatGPT"):
    """Create HTML export matching your existing style"""
    html_content = f"""<!DOCTYPE html>
<html lang="en-US" data-theme="dark">
<head>
    <meta charset="UTF-8" />
    <link rel="icon" href="https://chat.openai.com/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{title}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/github-dark.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"></script>
    <script>
        hljs.highlightAll()
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.3/katex.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.3/katex.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.3/contrib/auto-render.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {{
            renderMathInElement(document.body, {{
                delimiters: [
                    {{ left: "$$", right: "$$", display: true }},
                    {{ left: "$", right: "$", display: false }},
                    {{ left: "\\\\[", right: "\\\\]", display: true }},
                    {{ left: "\\\\(", right: "\\\\)", display: false }}
                ],
                throwOnError: false,
                ignoredClasses: ["no-katex"],
                preProcess: function(math) {{
                    return `\\\\displaystyle \\\\Large ${{math}}`;
                }}
            }});
            document.querySelectorAll('.katex').forEach(function(el) {{
                const parent = el.parentNode;
                const grandparent = parent.parentNode;
                if (grandparent.tagName === 'P' && isOnlyContent(grandparent, parent)) {{
                    el.style.width = '100%';
                    el.style.display = 'block';
                    el.style.textAlign = 'center';
                    parent.style.textAlign = 'center';
                }} else {{
                    el.style.display = 'inline-block';
                    el.style.width = 'fit-content';
                }}
            }});
            function isOnlyContent(parent, element) {{
                let onlyKaTeX = true;
                parent.childNodes.forEach(function(child) {{
                    console.log(child.textContent);
                    if (child !== element) {{
                        if (child.nodeType === Node.TEXT_NODE) {{
                            if (child.textContent.trim().length > 0) {{
                                onlyKaTeX = false;
                            }}
                        }} else if (child.nodeType === Node.ELEMENT_NODE) {{
                            onlyKaTeX = false;
                        }}
                    }}
                }});
                return onlyKaTeX;
            }}
        }});
    </script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #e5e5e5;
            background: #1a1a1a;
            margin: 0;
            padding: 20px;
        }}
        .conversation-container {{
            max-width: 800px;
            margin: 0 auto;
        }}
        .message {{
            margin-bottom: 20px;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #4CAF50;
        }}
        .message.user {{
            background: #2a2a2a;
            border-left-color: #2196F3;
        }}
        .message.assistant {{
            background: #1e1e1e;
            border-left-color: #4CAF50;
        }}
        .message-header {{
            font-weight: bold;
            margin-bottom: 10px;
            color: #81C784;
        }}
        .message-content {{
            white-space: pre-wrap;
        }}
        .metadata {{
            background: #333;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9em;
        }}
    </style>
</head>
<body>
    <div class="conversation-container">
        <div class="metadata">
            <h1>{title}</h1>
            <p><strong>Platform:</strong> {platform}</p>
            <p><strong>Created:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p><strong>Messages:</strong> {len(messages)}</p>
        </div>
        
        <div class="conversation">
"""
    
    for i, message in enumerate(messages):
        role_icon = "👤" if message['role'] == "user" else "🤖"
        role_name = "Human" if message['role'] == "user" else "Assistant"
        
        html_content += f"""
            <div class="message {message['role']}">
                <div class="message-header">
                    {role_icon} {role_name}
                </div>
                <div class="message-content">{html.escape(message['content'])}</div>
            </div>
"""
    
    html_content += """
        </div>
    </div>
</body>
</html>"""
    
    return html_content

def create_markdown_export(title, messages, platform="ChatGPT"):
    """Create Markdown export matching your existing style"""
    markdown_content = f"""---
title: {title}
platform: {platform}
date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
messages: {len(messages)}
---

# {title}

**Platform:** {platform}  
**Created:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  
**Messages:** {len(messages)}  

---

"""
    
    for i, message in enumerate(messages):
        role_name = "Human" if message['role'] == "user" else "Assistant"
        markdown_content += f"## {role_name}\n\n{message['content']}\n\n---\n\n"
    
    return markdown_content

def parse_html_conversation(file_path):
    """Parse conversation from HTML file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract title
        title_match = re.search(r'<title>(.*?)</title>', content)
        title = title_match.group(1) if title_match else Path(file_path).stem
        
        # Extract messages
        messages = []
        
        # Look for message patterns
        message_patterns = [
            r'<div[^>]*class="[^"]*message[^"]*"[^>]*>(.*?)</div>',
            r'<div[^>]*class="[^"]*conversation[^"]*"[^>]*>(.*?)</div>',
            r'<p[^>]*class="[^"]*user[^"]*"[^>]*>(.*?)</p>',
            r'<p[^>]*class="[^"]*assistant[^"]*"[^>]*>(.*?)</p>'
        ]
        
        for pattern in message_patterns:
            matches = re.findall(pattern, content, re.DOTALL)
            for i, match in enumerate(matches):
                clean_content = re.sub(r'<[^>]+>', '', match)
                clean_content = html.unescape(clean_content).strip()
                
                if clean_content and len(clean_content) > 10:
                    role = 'assistant' if any(word in clean_content.lower() for word in [
                        'i can', 'i\'ll', 'here\'s', 'based on', 'let me'
                    ]) else 'user'
                    
                    messages.append({
                        'role': role,
                        'content': clean_content,
                        'timestamp': datetime.now().isoformat()
                    })
        
        return title, messages
        
    except Exception as e:
        print(f"Error parsing HTML {file_path}: {e}")
        return None, None

def parse_markdown_conversation(file_path):
    """Parse conversation from Markdown file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract metadata
        metadata = {}
        if content.startswith('---'):
            frontmatter_end = content.find('---', 3)
            if frontmatter_end != -1:
                frontmatter = content[3:frontmatter_end]
                content = content[frontmatter_end + 3:]
                
                for line in frontmatter.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        metadata[key.strip()] = value.strip()
        
        title = metadata.get('title', Path(file_path).stem)
        
        # Parse messages
        messages = []
        current_message = None
        current_role = None
        
        for line in content.split('\n'):
            line = line.strip()
            
            if line.startswith('## 👤 Human') or line.startswith('## Human'):
                if current_message:
                    messages.append(current_message)
                current_role = 'user'
                current_message = None
            elif line.startswith('## 🤖 ChatGPT') or line.startswith('## ChatGPT'):
                if current_message:
                    messages.append(current_message)
                current_role = 'assistant'
                current_message = None
            elif line.startswith('---') and current_message:
                messages.append(current_message)
                current_message = None
            elif current_role and line and not line.startswith('#'):
                if current_message is None:
                    current_message = {
                        'role': current_role,
                        'content': line,
                        'timestamp': metadata.get('date', datetime.now().isoformat())
                    }
                else:
                    current_message['content'] += '\n' + line
        
        if current_message:
            messages.append(current_message)
        
        return title, messages
        
    except Exception as e:
        print(f"Error parsing Markdown {file_path}: {e}")
        return None, None

def main():
    """Main function to export SUNO conversations"""
    suno_dir = Path("/Users/steven/SUNO")
    output_dir = Path("/Users/steven/conversation-exports")
    
    # Create output directories
    html_dir = output_dir / "html"
    markdown_dir = output_dir / "markdown"
    html_dir.mkdir(parents=True, exist_ok=True)
    markdown_dir.mkdir(parents=True, exist_ok=True)
    
    print("🚀 SUNO Conversation Exporter")
    print("=" * 50)
    
    # Find conversation files
    conversation_files = []
    
    # Look for HTML files
    for html_file in suno_dir.rglob("*.html"):
        if any(indicator in html_file.read_text(encoding='utf-8', errors='ignore') for indicator in [
            'chat.openai.com', 'ChatGPT', 'data-theme="dark"', 'hljs.highlightAll()'
        ]):
            conversation_files.append(('html', html_file))
    
    # Look for Markdown files
    for md_file in suno_dir.rglob("*.md"):
        if any(indicator in md_file.read_text(encoding='utf-8', errors='ignore') for indicator in [
            'Platform: ChatGPT', '**Platform:** ChatGPT', '## Human', '## Assistant'
        ]):
            conversation_files.append(('markdown', md_file))
    
    print(f"📁 Found {len(conversation_files)} conversation files")
    
    exported_count = 0
    
    for file_type, file_path in conversation_files:
        print(f"📤 Processing: {file_path.name}")
        
        if file_type == 'html':
            title, messages = parse_html_conversation(file_path)
        else:
            title, messages = parse_markdown_conversation(file_path)
        
        if title and messages:
            # Create safe filename
            safe_title = re.sub(r'[^\w\s-]', '', title).strip()
            safe_title = re.sub(r'[-\s]+', '_', safe_title)
            
            # Create HTML export
            html_content = create_html_export(title, messages)
            html_file = html_dir / f"{safe_title}.html"
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            # Create Markdown export
            markdown_content = create_markdown_export(title, messages)
            markdown_file = markdown_dir / f"{safe_title}.md"
            with open(markdown_file, 'w', encoding='utf-8') as f:
                f.write(markdown_content)
            
            print(f"  ✅ Exported to: {html_file.name}, {markdown_file.name}")
            exported_count += 1
        else:
            print(f"  ⚠️  Could not parse conversation")
    
    print(f"\n🎉 Export complete! {exported_count} conversations exported")
    print(f"📁 HTML files: {html_dir}")
    print(f"📁 Markdown files: {markdown_dir}")

if __name__ == "__main__":
    main()