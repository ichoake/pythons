#!/usr/bin/env python3
"""
Duplicate Cleaner for ~/Documents/python
Handles conflicts and merges similar files (>50% similarity)
"""

import ast
import os
import re
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Set
from collections import defaultdict
import difflib
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


class DuplicateCleaner:
    """Clean up duplicate target names and merge similar files"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.duplicates = defaultdict(list)
        self.similar_files = []
        self.merged_files = []
        self.removed_files = []
        
    def find_duplicate_targets(self) -> Dict[str, List[Path]]:
        """Find files that would have the same target name"""
        logger.info("🔍 Finding duplicate target names...")
        
        # Get all Python files
        python_files = list(self.project_root.glob('*.py'))
        
        # Group by potential target names
        target_groups = defaultdict(list)
        
        for filepath in python_files:
            if filepath.name.startswith('.'):
                continue
                
            # Generate target name using same logic as renamer
            target_name = self._generate_target_name(filepath)
            if target_name and target_name != filepath.name:
                target_groups[target_name].append(filepath)
        
        # Filter to only groups with multiple files
        duplicates = {k: v for k, v in target_groups.items() if len(v) > 1}
        
        logger.info(f"📊 Found {len(duplicates)} duplicate target groups")
        return duplicates
    
    def _generate_target_name(self, filepath: Path) -> str:
        """Generate target name using same logic as simple renamer"""
        try:
            content = filepath.read_text(encoding='utf-8', errors='ignore')
            analysis = self._analyze_file_content(content)
            
            # Extract action and subject
            action = self._extract_action(analysis)
            subject = self._extract_subject(analysis)
            
            # Build name parts
            name_parts = []
            if action:
                name_parts.append(action)
            if subject:
                name_parts.append(subject)
            
            if not name_parts:
                return None
                
            # Build final name
            new_name = '-'.join(name_parts) + '.py'
            new_name = re.sub(r'[^a-zA-Z0-9\-\.]', '', new_name)
            new_name = re.sub(r'-+', '-', new_name)
            new_name = new_name.strip('-')
            
            return new_name
            
        except Exception as e:
            logger.error(f"Error analyzing {filepath}: {e}")
            return None
    
    def _analyze_file_content(self, content: str) -> Dict:
        """Analyze file content for action/subject extraction"""
        analysis = {
            'functions': [],
            'keywords': [],
            'imports': [],
            'docstring': None
        }
        
        try:
            tree = ast.parse(content)
            
            # Get docstring
            if (tree.body and isinstance(tree.body[0], ast.Expr) and
                isinstance(tree.body[0].value, ast.Constant)):
                analysis['docstring'] = tree.body[0].value.value
            
            # Get functions and imports
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        analysis['imports'].append(alias.name)
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        analysis['imports'].append(node.module)
                elif isinstance(node, ast.FunctionDef):
                    analysis['functions'].append(node.name)
        except (ImportError, ModuleNotFoundError):
            pass
        
        # Extract keywords
        keywords = re.findall(r'\b[a-z_]{3,}\b', content.lower())
        analysis['keywords'] = keywords[:20]
        
        return analysis
    
    def _extract_action(self, analysis: Dict) -> str:
        """Extract action word from analysis"""
        action_words = {
            'analyze': ['analyze', 'analysis', 'analytics'],
            'transcribe': ['transcribe', 'transcript', 'whisper'],
            'batch': ['batch', 'bulk', 'process'],
            'archive': ['archive', 'backup', 'compress'],
            'download': ['download', 'fetch', 'get'],
            'upload': ['upload', 'send', 'post'],
            'convert': ['convert', 'transform', 'change'],
            'generate': ['generate', 'create', 'make'],
            'extract': ['extract', 'parse', 'pull'],
            'compress': ['compress', 'zip', 'pack'],
            'resize': ['resize', 'scale', 'crop'],
            'merge': ['merge', 'combine', 'join'],
            'split': ['split', 'divide', 'separate'],
            'clean': ['clean', 'sanitize', 'fix'],
            'validate': ['validate', 'check', 'verify']
        }
        
        # Check functions
        for func in analysis.get('functions', []):
            for action, patterns in action_words.items():
                if any(pattern in func.lower() for pattern in patterns):
                    return action
        
        # Check keywords
        for keyword in analysis.get('keywords', [])[:10]:
            for action, patterns in action_words.items():
                if any(pattern in keyword for pattern in patterns):
                    return action
        
        return None
    
    def _extract_subject(self, analysis: Dict) -> str:
        """Extract subject word from analysis"""
        subject_words = {
            'mp3': ['mp3', 'audio', 'sound', 'music'],
            'video': ['video', 'mp4', 'avi', 'mov'],
            'image': ['image', 'img', 'jpg', 'png', 'photo'],
            'text': ['text', 'txt', 'content', 'data'],
            'csv': ['csv', 'spreadsheet', 'data'],
            'json': ['json', 'api', 'response'],
            'pdf': ['pdf', 'document'],
            'prompt': ['prompt', 'template', 'instruction'],
            'transcript': ['transcript', 'transcription', 'whisper'],
            'file': ['file', 'files'],
            'folder': ['folder', 'directory', 'dir'],
            'url': ['url', 'link', 'web'],
            'youtube': ['youtube', 'yt', 'video'],
            'instagram': ['instagram', 'ig', 'social']
        }
        
        # Check keywords
        for keyword in analysis.get('keywords', [])[:10]:
            for subject, patterns in subject_words.items():
                if any(pattern in keyword for pattern in patterns):
                    return subject
        
        return None
    
    def find_similar_files(self, threshold: float = 0.5) -> List[Tuple[Path, Path, float]]:
        """Find files that are more than threshold% similar"""
        logger.info(f"🔍 Finding similar files (threshold: {threshold:.0%})...")
        
        python_files = list(self.project_root.glob('*.py'))
        similar_pairs = []
        
        for i, file1 in enumerate(python_files):
            if file1.name.startswith('.'):
                continue
                
            try:
                content1 = file1.read_text(encoding='utf-8', errors='ignore')
            except (OSError, IOError, FileNotFoundError):
                continue
            
            for file2 in python_files[i+1:]:
                if file2.name.startswith('.'):
                    continue
                    
                try:
                    content2 = file2.read_text(encoding='utf-8', errors='ignore')
                except (OSError, IOError, FileNotFoundError):
                    continue
                
                # Calculate similarity
                similarity = self._calculate_similarity(content1, content2)
                
                if similarity >= threshold:
                    similar_pairs.append((file1, file2, similarity))
                    logger.info(f"📄 Similar: {file1.name} ↔ {file2.name} ({similarity:.1%})")
        
        logger.info(f"📊 Found {len(similar_pairs)} similar file pairs")
        return similar_pairs
    
    def _calculate_similarity(self, content1: str, content2: str) -> float:
        """Calculate similarity between two file contents"""
        # Normalize content
        content1 = self._normalize_content(content1)
        content2 = self._normalize_content(content2)
        
        # Use difflib for similarity
        matcher = difflib.SequenceMatcher(None, content1, content2)
        return matcher.ratio()
    
    def _normalize_content(self, content: str) -> str:
        """Normalize content for comparison"""
        # Remove comments and docstrings
        lines = content.split('\n')
        normalized_lines = []
        
        for line in lines:
            # Remove comments
            if '#' in line:
                line = line[:line.index('#')]
            
            # Skip empty lines and docstrings
            line = line.strip()
            if line and not line.startswith('"""') and not line.startswith("'''"):
                normalized_lines.append(line)
        
        return '\n'.join(normalized_lines)
    
    def merge_similar_files(self, similar_pairs: List[Tuple[Path, Path, float]]) -> List[Dict]:
        """Merge similar files, keeping the best one"""
        logger.info("🔄 Merging similar files...")
        
        merged_groups = []
        processed_files = set()
        
        for file1, file2, similarity in similar_pairs:
            if file1 in processed_files or file2 in processed_files:
                continue
            
            # Choose the better file (longer, more complete)
            better_file, worse_file = self._choose_better_file(file1, file2)
            
            # Create merge info
            merge_info = {
                'kept_file': better_file,
                'removed_file': worse_file,
                'similarity': similarity,
                'reason': self._get_merge_reason(better_file, worse_file)
            }
            
            merged_groups.append(merge_info)
            processed_files.add(file1)
            processed_files.add(file2)
            
            logger.info(f"✅ Merged: {worse_file.name} → {better_file.name} ({similarity:.1%})")
        
        return merged_groups
    
    def _choose_better_file(self, file1: Path, file2: Path) -> Tuple[Path, Path]:
        """Choose the better file between two similar files"""
        try:
            content1 = file1.read_text(encoding='utf-8', errors='ignore')
            content2 = file2.read_text(encoding='utf-8', errors='ignore')
        except (OSError, IOError, FileNotFoundError):
            return file1, file2
        
        # Criteria for choosing better file:
        # 1. Longer content (more complete)
        # 2. Better naming (no numbers, cleaner)
        # 3. More functions/classes
        
        score1 = self._score_file(file1, content1)
        score2 = self._score_file(file2, content2)
        
        if score1 >= score2:
            return file1, file2
        else:
            return file2, file1
    
    def _score_file(self, filepath: Path, content: str) -> float:
        """Score a file for quality"""
        score = 0
        
        # Length score
        score += len(content) / 1000
        
        # Naming score (prefer cleaner names)
        name = filepath.stem
        if not re.search(r'\d+', name):  # No numbers
            score += 2
        if not name.startswith('yt_') and not name.startswith('ig_'):  # No prefixes
            score += 1
        if '-' in name:  # Hyphenated names
            score += 1
        
        # Code quality score
        try:
            tree = ast.parse(content)
            functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
            classes = [node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]
            score += len(functions) * 0.5
            score += len(classes) * 1.0
        except (IndexError, KeyError):
            pass
        
        return score
    
    def _get_merge_reason(self, kept_file: Path, removed_file: Path) -> str:
        """Get reason for merge decision"""
        try:
            content1 = kept_file.read_text(encoding='utf-8', errors='ignore')
            content2 = removed_file.read_text(encoding='utf-8', errors='ignore')
        except (OSError, IOError, FileNotFoundError):
            return "File analysis failed"
        
        reasons = []
        
        if len(content1) > len(content2):
            reasons.append("longer content")
        elif len(content2) > len(content1):
            reasons.append("shorter content")
        
        if not re.search(r'\d+', kept_file.stem) and re.search(r'\d+', removed_file.stem):
            reasons.append("cleaner naming")
        
        if not kept_file.name.startswith('yt_') and removed_file.name.startswith('yt_'):
            reasons.append("no prefix")
        
        return "; ".join(reasons) if reasons else "better quality"
    
    def apply_merges(self, merged_groups: List[Dict], dry_run: bool = True) -> None:
        """Apply the merges (remove duplicate files)"""
        if dry_run:
            logger.info("🔍 DRY RUN - No files will be deleted")
        else:
            logger.info("🗑️  Applying merges...")
        
        for merge_info in merged_groups:
            kept_file = merge_info['kept_file']
            removed_file = merge_info['removed_file']
            similarity = merge_info['similarity']
            reason = merge_info['reason']
            
            logger.info(f"\n📄 Merge: {removed_file.name} → {kept_file.name}")
            logger.info(f"   Similarity: {similarity:.1%}")
            logger.info(f"   Reason: {reason}")
            
            if not dry_run:
                try:
                    # Check if git tracked
                    result = subprocess.run(
                        ['git', 'ls-files', '--error-unmatch', str(removed_file)],
                        capture_output=True
                    )
                    is_tracked = result.returncode == 0
                    
                    if is_tracked:
                        subprocess.run(['git', 'rm', str(removed_file)], check=True)
                        logger.info(f"   ✅ Removed (git tracked)")
                    else:
                        removed_file.unlink()
                        logger.info(f"   ✅ Removed")
                    
                    self.removed_files.append(removed_file)
                    
                except Exception as e:
                    logger.error(f"   ❌ Error removing {removed_file.name}: {e}")
            else:
                logger.info(f"   🔍 Would remove: {removed_file.name}")
    
    def cleanup_numbered_files(self) -> List[Path]:
        """Find and suggest cleanup for files with random numbers"""
        logger.info("🔍 Finding files with random numbers...")
        
        python_files = list(self.project_root.glob('*.py'))
        numbered_files = []
        
        for filepath in python_files:
            if filepath.name.startswith('.'):
                continue
            
            # Check for random number patterns
            if self._has_random_numbers(filepath.name):
                numbered_files.append(filepath)
                logger.info(f"📄 Numbered file: {filepath.name}")
        
        logger.info(f"📊 Found {len(numbered_files)} files with random numbers")
        return numbered_files
    
    def _has_random_numbers(self, filename: str) -> bool:
        """Check if filename has random number patterns"""
        patterns = [
            r'\(\d+\)',  # (1), (2), etc.
            r'_\d+_\d+',  # _1_2, _2_3, etc.
            r'_\d+\.py$',  # _1.py, _2.py, etc.
            r'\d+_\d+\.py$',  # 1_2.py, 2_3.py, etc.
            r' \d+\.py$',  # 1.py, 2.py, etc.
        ]
        
        for pattern in patterns:
            if re.search(pattern, filename):
                return True
        
        return False
    
    def run_cleanup(self, dry_run: bool = True) -> Dict:
        """Run complete cleanup process"""
        logger.info("🚀 Starting duplicate cleanup process...")
        logger.info("=" * 60)
        
        results = {
            'duplicate_targets': {},
            'similar_files': [],
            'merged_files': [],
            'numbered_files': [],
            'removed_files': []
        }
        
        # 1. Find duplicate target names
        duplicate_targets = self.find_duplicate_targets()
        results['duplicate_targets'] = duplicate_targets
        
        # 2. Find similar files
        similar_pairs = self.find_similar_files(threshold=0.5)
        results['similar_files'] = similar_pairs
        
        # 3. Merge similar files
        if similar_pairs:
            merged_groups = self.merge_similar_files(similar_pairs)
            results['merged_files'] = merged_groups
            
            # Apply merges
            self.apply_merges(merged_groups, dry_run=dry_run)
        
        # 4. Find numbered files
        numbered_files = self.cleanup_numbered_files()
        results['numbered_files'] = numbered_files
        
        # Summary
        logger.info("\n" + "=" * 60)
        logger.info("📊 CLEANUP SUMMARY")
        logger.info("=" * 60)
        logger.info(f"Duplicate target groups: {len(duplicate_targets)}")
        logger.info(f"Similar file pairs: {len(similar_pairs)}")
        logger.info(f"Merged files: {len(results['merged_files'])}")
        logger.info(f"Numbered files: {len(numbered_files)}")
        
        if dry_run:
            logger.info("\n💡 Run with --apply to actually perform cleanup")
        else:
            logger.info(f"\n✅ Cleanup complete! Removed {len(self.removed_files)} files")
        
        return results


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Clean up duplicates and similar files in ~/Documents/python'
    )
    parser.add_argument(
        'path',
        type=Path,
        nargs='?',
        default=Path.home() / 'Documents' / 'python',
        help='Python directory to clean (default: ~/Documents/python)'
    )
    parser.add_argument(
        '--apply',
        action='store_true',
        help='Actually apply the cleanup (default: dry-run only)'
    )
    parser.add_argument(
        '--threshold',
        type=float,
        default=0.5,
        help='Similarity threshold for merging files (default: 0.5)'
    )
    
    args = parser.parse_args()
    
    cleaner = DuplicateCleaner(args.path)
    results = cleaner.run_cleanup(dry_run=not args.apply)
    
    if args.apply:
        logger.info("\n🎉 Cleanup applied successfully!")
    else:
        logger.info("\n💡 Run with --apply to perform the cleanup")


if __name__ == '__main__':
    main()