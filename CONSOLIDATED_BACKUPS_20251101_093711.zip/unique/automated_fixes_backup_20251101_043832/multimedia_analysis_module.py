# analyze_multimedia.py
# Intel macOS-friendly, no external deps beyond `openai` package.
# Usage:
#   from analyze_multimedia import analyze_text_for_section
#   result = analyze_text_for_section(transcript_text, section_number=1)
#
# Returns a Python dict with structured fields and a longform narrative.
#
# Notes:
# - Expects OPENAI_API_KEY in your environment (e.g., ~/.env loaded in your app).
# - Uses OpenAI's Chat Completions API via the official "openai" package.
# - Includes retry logic, JSON parsing robustness, and optional Markdown rendering.

from __future__ import annotations

import json
import time
import re
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional, List, Tuple

try:
    # Newer SDK style
    from openai import OpenAI
    _CLIENT = OpenAI()
    _NEW_SDK = True
except Exception:
    # Fallback to legacy
    import openai  # type: ignore
    _CLIENT = None
    _NEW_SDK = False


@dataclass
class KeyMoment:
    label: str
    why_it_matters: str
    evidence: Optional[str] = None  # short quote or timestamp if present


@dataclass
class AnalysisResult:
    section_number: int
    central_themes: List[str]
    emotional_tone: str
    narrative_arc: str
    creators_intent: str
    metaphors_symbols: List[str]
    techniques: List[str]
    interplay_av: str
    audience_impact: str
    overall_effectiveness: str
    key_moments: List[KeyMoment]
    pull_quotes: List[str]
    caveats: Optional[str]
    narrative_longform: str

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)

    def to_markdown(self) -> str:
        # Compact human-friendly MD
        lines = []
        lines.append(f"# Section {self.section_number} — Analysis\n")
        lines.append("## Central Themes")
        for t in self.central_themes:
            lines.append(f"- {t}")
        lines.append("\n## Emotional Tone\n" + self.emotional_tone)
        lines.append("\n## Narrative Arc\n" + self.narrative_arc)
        lines.append("\n## Creator’s Intent\n" + self.creators_intent)
        if self.metaphors_symbols:
            lines.append("\n## Metaphors, Symbols & Imagery")
            for m in self.metaphors_symbols:
                lines.append(f"- {m}")
        if self.techniques:
            lines.append("\n## Storytelling Techniques")
            for s in self.techniques:
                lines.append(f"- {s}")
        lines.append("\n## Interplay Between Visuals & Audio\n" + self.interplay_av)
        lines.append("\n## Audience Engagement & Impact\n" + self.audience_impact)
        lines.append("\n## Overall Effectiveness\n" + self.overall_effectiveness)
        if self.key_moments:
            lines.append("\n## Key Moments")
            for km in self.key_moments:
                ev = f" — *{km.evidence}*" if km.evidence else ""
                lines.append(f"- **{km.label}**: {km.why_it_matters}{ev}")
        if self.pull_quotes:
            lines.append("\n## Pull Quotes")
            for q in self.pull_quotes:
                lines.append(f"> {q}")
        if self.caveats:
            lines.append("\n## Caveats / Gaps\n" + self.caveats)
        lines.append("\n---\n")
        lines.append("## Longform Narrative\n" + self.narrative_longform)
        return "\n".join(lines)


_SYSTEM_PROMPT = (
    "You are an expert in multimedia analysis and storytelling. "
    "Provide a richly descriptive, evidence-grounded analysis of video/audio content. "
    "Examine themes, emotional tone, narrative structure, creator intent, technical production, and audience impact. "
    "Be specific and avoid speculation beyond the provided transcript. If visual details are not present, say so explicitly. "
    "When timestamps or cue markers appear (e.g., 00:01:23, [SFX], [MUSIC]), use them as evidence anchors."
)

# Single unified checklist that merges both of the user's versions, with additional precision:
_CHECKLIST = (
    "Analyze the following transcript for section {section_number}. Respond in STRICT JSON ONLY, with this schema:\n"
    "{\n"
    '  "section_number": <int>,\n'
    '  "central_themes": [<string>...],\n'
    '  "emotional_tone": <string>,\n'
    '  "narrative_arc": <string>,\n'
    '  "creators_intent": <string>,\n'
    '  "metaphors_symbols": [<string>...],\n'
    '  "techniques": [<string>...],\n'
    '  "interplay_av": <string>,\n'
    '  "audience_impact": <string>,\n'
    '  "overall_effectiveness": <string>,\n'
    '  "key_moments": [{"label": <string>, "why_it_matters": <string>, "evidence": <string|null> }...],\n'
    '  "pull_quotes": [<string>...],\n'
    '  "caveats": <string|null>,\n'
    '  "narrative_longform": <string>\n'
    "}\n\n"
    "Guidelines:\n"
    "1) Central Themes & Messages — identify primary ideas and their nuance; connect to broader narrative.\n"
    "2) Emotional Tone — describe range and how audio/visual cues evoke it (reference any timestamps).\n"
    "3) Narrative Arc — explain how this section advances or turns the story; mark key beats.\n"
    "4) Creator’s Intent — infer purpose (inform, inspire, persuade, entertain) and how elements support it.\n"
    "5) Metaphors, Symbols, Imagery — call out motifs that add depth.\n"
    "6) Storytelling Techniques — pacing, transitions, editing, cinematography, sound design, SFX/VFX.\n"
    "7) Interplay of Visuals & Audio — how they combine to create meaning; cite standout moments.\n"
    "8) Audience Impact — what hooks attention and why; engagement mechanisms.\n"
    "9) Overall Effectiveness — synthesis of why this section works (or doesn’t).\n"
    "10) Key Moments — list 3–7 concise moments; include a brief why and evidence (timestamp/quote) when available.\n"
    "11) Pull Quotes — up to 5 short verbatim phrases from the transcript that capture essence (keep <120 chars each).\n"
    "12) Caveats — note missing visuals or uncertain details if transcript lacks them.\n"
    "13) Narrative Longform — 2–5 paragraphs of flowing, vivid, but precise prose (no fluff), grounded in the transcript.\n\n"
    "IMPORTANT: Output MUST be valid JSON. Do not include Markdown, code fences, or commentary outside the JSON."
)

def _coerce_json(s: str) -> Dict[str, Any]:
    \"\"\"Try to coerce model output into JSON even if it contains stray text.\"\"\"
    s = s.strip()
    # Fast path
    try:
        return json.loads(s)
    except Exception:
        pass

    # Attempt to locate first/last braces
    start = s.find('{')
    end = s.rfind('}')
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(s[start:end+1])
        except Exception:
            pass

    # Last resort: return as narrative_longform only
    return {
        "central_themes": [],
        "emotional_tone": "",
        "narrative_arc": "",
        "creators_intent": "",
        "metaphors_symbols": [],
        "techniques": [],
        "interplay_av": "",
        "audience_impact": "",
        "overall_effectiveness": "",
        "key_moments": [],
        "pull_quotes": [],
        "caveats": "Model did not return parseable JSON; returning raw output in narrative_longform.",
        "narrative_longform": s,
    }

def _call_openai(messages: List[Dict[str, str]], model: str, max_tokens: int, temperature: float, use_json_mode: bool, retries: int = 3) -> str:
    backoff = 1.5
    last_err: Optional[Exception] = None
    for i in range(retries):
        try:
            if _NEW_SDK:
                kwargs = dict(model=model, messages=messages, max_tokens=max_tokens, temperature=temperature)
                if use_json_mode:
                    # JSON mode (supported on modern models)
                    kwargs["response_format"] = {"type": "json_object"}
                resp = _CLIENT.chat.completions.create(**kwargs)
                return resp.choices[0].message.content or ""
            else:
                import openai as _openai  # type: ignore
                _openai.api_key = _openai.api_key or None  # ensure env usage
                kwargs = dict(model=model, messages=messages, max_tokens=max_tokens, temperature=temperature)
                if use_json_mode:
                    kwargs["response_format"] = {"type": "json_object"}
                resp = _openai.ChatCompletion.create(**kwargs)  # type: ignore
                return resp["choices"][0]["message"]["content"]  # type: ignore
        except Exception as e:
            last_err = e
            # If response_format not supported, retry without it once
            if "response_format" in locals().get("kwargs", {}) and "not supported" in str(e).lower():
                try:
                    kwargs.pop("response_format", None)
                except Exception:
                    pass
            time.sleep(backoff ** (i + 1))
    raise RuntimeError(f"OpenAI call failed after {retries} attempts: {last_err}")

def _estimate_trim(text: str, max_chars: int = 120000) -> str:
    \"\"\"Rough guard against overlong transcripts; trims while preserving boundaries.\"\"\"
    if len(text) <= max_chars:
        return text
    # Try to cut at a boundary near max_chars
    cut = text.rfind("\n", 0, max_chars)
    if cut == -1 or cut < max_chars * 0.75:
        cut = max_chars
    return text[:cut] + "\n...[TRIMMED]"

def analyze_text_for_section(
    text: str,
    section_number: int,
    model: str = "gpt-4o",
    temperature: float = 0.4,
    max_tokens: int = 2000,
    retries: int = 3,
    return_markdown: bool = False,
) -> AnalysisResult | Dict[str, Any]:
    \"\"\"Unified, improved function that merges and upgrades both prompt versions.

    - Strong system prompt with explicit, merged checklist.
    - Strict JSON response with schema to enable reliable parsing.
    - Robust JSON coercion if the model returns stray text.
    - Optional Markdown rendering.
    - Gentle transcript length guard to avoid excessive tokens.

    Returns:
        AnalysisResult (default) or a raw dict if JSON coercion fallback engages.
    \"\"\"
    safe_text = _estimate_trim(text)

    user_prompt = _CHECKLIST.format(section_number=section_number) + f"\nTranscript:\n{safe_text}"

    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    raw = _call_openai(
        messages=messages,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        use_json_mode=True,
        retries=retries,
    )

    data = _coerce_json(raw)

    # Build dataclass if keys present
    def _list(x):
        return x if isinstance(x, list) else ([] if x is None else [str(x)])

    def _str(x):
        return "" if x is None else str(x)

    # Attempt to map into AnalysisResult
    try:
        kms = [
            KeyMoment(
                label=_str(k.get("label")),
                why_it_matters=_str(k.get("why_it_matters")),
                evidence=k.get("evidence"),
            )
            for k in data.get("key_moments", [])
            if isinstance(k, dict)
        ]
        result = AnalysisResult(
            section_number=int(data.get("section_number", section_number)),
            central_themes=[str(v) for v in _list(data.get("central_themes"))],
            emotional_tone=_str(data.get("emotional_tone")),
            narrative_arc=_str(data.get("narrative_arc")),
            creators_intent=_str(data.get("creators_intent")),
            metaphors_symbols=[str(v) for v in _list(data.get("metaphors_symbols"))],
            techniques=[str(v) for v in _list(data.get("techniques"))],
            interplay_av=_str(data.get("interplay_av")),
            audience_impact=_str(data.get("audience_impact")),
            overall_effectiveness=_str(data.get("overall_effectiveness")),
            key_moments=kms,
            pull_quotes=[str(v) for v in _list(data.get("pull_quotes"))],
            caveats=(None if data.get("caveats") in (None, "", "null") else _str(data.get("caveats"))),
            narrative_longform=_str(data.get("narrative_longform")) or raw,
        )
        if return_markdown:
            # Attach a convenience attribute for MD
            result.markdown = result.to_markdown()  # type: ignore[attr-defined]
        return result
    except Exception:
        # If the structure is too off, just return raw dict
        return data
