import os
import tkinter as tk
from subprocess import PIPE, STDOUT, Popen
from tkinter import scrolledtext


def execute_command():
    # Get the command entered by the user
    command = command_entry.get()

    # Execute the command using subprocess
    process = Popen(command, shell=True, stdout=PIPE, stderr=STDOUT)
    output, _ = process.communicate()

    # Display the output in the text area
    output_text.delete(1.0, tk.END)
    output_text.insert(tk.END, output.decode("utf-8"))


# GUI setup
root = tk.Tk()
root.title("Ollama Command Executor")

# Command Entry Widget
command_label = tk.Label(root, text="Enter Ollama Command:")
command_label.pack()
command_entry = tk.Entry(root, width=50)
command_entry.pack()

# Execute Button
execute_button = tk.Button(root, text="Execute", command=execute_command)
execute_button.pack()

# Output Display Window
output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=60, height=20)
output_text.pack()

# Run Tkinter event loop
root.mainloop()
