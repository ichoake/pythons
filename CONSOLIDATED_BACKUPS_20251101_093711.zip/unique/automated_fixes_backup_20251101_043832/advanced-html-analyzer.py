#!/usr/bin/env python3
"""
Advanced HTML Content Analyzer with Deep Intelligence
Uses AST-based analysis, semantic pattern recognition, and ML-powered categorization
"""

import os
import re
import csv
import json
import hashlib
import ast
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter
from typing import Dict, List, Tuple, Optional, Any
import mimetypes

class AdvancedHTMLAnalyzer:
    """Advanced HTML analyzer with deep content awareness and intelligence."""
    
    def __init__(self, target_dir: str = "/Users/steven/Documents/HTML", max_depth: int = 6):
        self.target_dir = Path(target_dir)
        self.max_depth = max_depth
        self.analysis_results = {
            'total_files': 0,
            'worth_keeping': [],
            'safe_to_remove': [],
            'needs_review': [],
            'content_patterns': defaultdict(int),
            'quality_scores': {},
            'duplicate_groups': defaultdict(list),
            'semantic_categories': defaultdict(list)
        }
        
        # Advanced pattern recognition
        self.content_patterns = {
            'personal_content': [
                r'steven|chaplinski|personal|my\s+',
                r'contact|about|bio|profile',
                r'portfolio|resume|cv',
                r'family|friends|personal'
            ],
            'generated_content': [
                r'generated|auto|bot|ai\s+created',
                r'template|boilerplate|default',
                r'placeholder|example|demo',
                r'copy\s+of|duplicate|backup'
            ],
            'documentation': [
                r'readme|docs|documentation|guide',
                r'api|reference|manual|tutorial',
                r'help|faq|support|instructions'
            ],
            'temporary_files': [
                r'temp|tmp|backup|old|archive',
                r'test|debug|dev|development',
                r'copy|duplicate|version\s+\d+',
                r'untitled|new\s+file|document'
            ],
            'commercial_content': [
                r'etsy|redbubble|printify|society6',
                r'shop|store|marketplace|commerce',
                r'product|item|listing|sale',
                r'business|commercial|profit'
            ]
        }
        
        # Quality indicators
        self.quality_indicators = {
            'high_quality': [
                'unique_content', 'personal_photos', 'custom_code',
                'original_artwork', 'detailed_descriptions', 'interactive_elements'
            ],
            'low_quality': [
                'generated_text', 'stock_photos', 'template_content',
                'placeholder_text', 'auto_generated', 'duplicate_content'
            ]
        }
    
    def extract_title(self, content: str) -> str:
        """Extract title with advanced pattern matching."""
        title_patterns = [
            r'<title[^>]*>(.*?)</title>',
            r'<h1[^>]*>(.*?)</h1>',
            r'<h2[^>]*>(.*?)</h2>',
            r'<meta[^>]*name=["\']title["\'][^>]*content=["\'](.*?)["\']',
            r'<meta[^>]*property=["\']og:title["\'][^>]*content=["\'](.*?)["\']'
        ]
        
        for pattern in title_patterns:
            match = re.search(pattern, content, re.IGNORECASE | re.DOTALL)
            if match:
                title = match.group(1).strip()
                if len(title) > 3:  # Filter out very short titles
                    return title
        
        return "Untitled"
    
    def analyze_content_structure(self, content: str) -> Dict[str, Any]:
        """Deep analysis of HTML content structure."""
        analysis = {
            'word_count': len(content.split()),
            'has_scripts': bool(re.search(r'<script[^>]*>', content, re.IGNORECASE)),
            'has_styles': bool(re.search(r'<style[^>]*>', content, re.IGNORECASE)),
            'has_forms': bool(re.search(r'<form[^>]*>', content, re.IGNORECASE)),
            'has_images': bool(re.search(r'<img[^>]*>', content, re.IGNORECASE)),
            'has_links': bool(re.search(r'<a[^>]*href', content, re.IGNORECASE)),
            'has_meta_tags': bool(re.search(r'<meta[^>]*>', content, re.IGNORECASE)),
            'has_comments': bool(re.search(r'<!--.*?-->', content, re.DOTALL)),
            'has_doctype': bool(re.search(r'<!DOCTYPE', content, re.IGNORECASE)),
            'has_head_section': bool(re.search(r'<head[^>]*>', content, re.IGNORECASE)),
            'has_body_section': bool(re.search(r'<body[^>]*>', content, re.IGNORECASE))
        }
        
        # Count specific elements
        analysis['script_count'] = len(re.findall(r'<script[^>]*>', content, re.IGNORECASE))
        analysis['image_count'] = len(re.findall(r'<img[^>]*>', content, re.IGNORECASE))
        analysis['link_count'] = len(re.findall(r'<a[^>]*href', content, re.IGNORECASE))
        analysis['paragraph_count'] = len(re.findall(r'<p[^>]*>', content, re.IGNORECASE))
        
        return analysis
    
    def detect_content_type(self, content: str, file_path: Path) -> str:
        """Intelligent content type detection."""
        title = self.extract_title(content)
        filename = file_path.name.lower()
        
        # Check for personal content indicators
        personal_indicators = [
            'steven', 'chaplinski', 'personal', 'about', 'contact',
            'portfolio', 'resume', 'bio', 'family', 'friends'
        ]
        
        if any(indicator in title.lower() or indicator in filename for indicator in personal_indicators):
            return 'personal'
        
        # Check for generated content
        generated_indicators = [
            'generated', 'auto', 'template', 'boilerplate',
            'placeholder', 'example', 'demo', 'copy of'
        ]
        
        if any(indicator in title.lower() or indicator in filename for indicator in generated_indicators):
            return 'generated'
        
        # Check for commercial content
        commercial_indicators = [
            'etsy', 'redbubble', 'printify', 'society6',
            'shop', 'store', 'product', 'business'
        ]
        
        if any(indicator in title.lower() or indicator in filename for indicator in commercial_indicators):
            return 'commercial'
        
        # Check for documentation
        doc_indicators = [
            'readme', 'docs', 'guide', 'manual', 'tutorial',
            'api', 'reference', 'help', 'faq'
        ]
        
        if any(indicator in title.lower() or indicator in filename for indicator in doc_indicators):
            return 'documentation'
        
        # Check for temporary files
        temp_indicators = [
            'temp', 'tmp', 'backup', 'old', 'test',
            'debug', 'copy', 'duplicate', 'untitled'
        ]
        
        if any(indicator in filename for indicator in temp_indicators):
            return 'temporary'
        
        return 'unknown'
    
    def calculate_quality_score(self, content: str, file_path: Path) -> float:
        """Calculate quality score based on multiple factors."""
        score = 0.0
        max_score = 100.0
        
        # Title quality (20 points)
        title = self.extract_title(content)
        if title != "Untitled":
            score += 20
            if len(title) > 10:
                score += 5
            if not any(word in title.lower() for word in ['untitled', 'new', 'document', 'page']):
                score += 5
        
        # Content structure (30 points)
        structure = self.analyze_content_structure(content)
        if structure['has_doctype']:
            score += 10
        if structure['has_head_section']:
            score += 10
        if structure['has_body_section']:
            score += 10
        
        # Content richness (25 points)
        if structure['word_count'] > 100:
            score += 10
        if structure['word_count'] > 500:
            score += 10
        if structure['has_images']:
            score += 5
        
        # Personal content bonus (15 points)
        content_type = self.detect_content_type(content, file_path)
        if content_type == 'personal':
            score += 15
        elif content_type == 'commercial':
            score += 10
        elif content_type == 'documentation':
            score += 8
        elif content_type == 'generated':
            score -= 20
        elif content_type == 'temporary':
            score -= 30
        
        # File naming quality (10 points)
        filename = file_path.name.lower()
        if not any(char in filename for char in [' ', '-', '_', '.']):
            score += 5
        if not any(word in filename for word in ['copy', 'duplicate', 'backup', 'old']):
            score += 5
        
        return max(0, min(score, max_score))
    
    def detect_duplicates(self, files: List[Path]) -> Dict[str, List[Path]]:
        """Detect duplicate files using content hashing."""
        content_hashes = defaultdict(list)
        
        for file_path in files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    content_hash = hashlib.md5(content.encode()).hexdigest()
                    content_hashes[content_hash].append(file_path)
            except Exception as e:
                print(f"Error reading {file_path}: {e}")
        
        # Return only groups with duplicates
        return {hash_val: paths for hash_val, paths in content_hashes.items() if len(paths) > 1}
    
    def analyze_file(self, file_path: Path) -> Dict[str, Any]:
        """Comprehensive analysis of a single HTML file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            return {'error': str(e), 'file_path': str(file_path)}
        
        # Basic file info
        file_info = {
            'file_path': str(file_path),
            'file_name': file_path.name,
            'file_size': file_path.stat().st_size,
            'modified_time': file_path.stat().st_mtime,
            'title': self.extract_title(content),
            'content_type': self.detect_content_type(content, file_path),
            'quality_score': self.calculate_quality_score(content, file_path),
            'structure': self.analyze_content_structure(content)
        }
        
        # Determine recommendation
        if file_info['quality_score'] >= 70:
            file_info['recommendation'] = 'keep'
        elif file_info['quality_score'] >= 40:
            file_info['recommendation'] = 'review'
        else:
            file_info['recommendation'] = 'remove'
        
        return file_info
    
    def run_analysis(self) -> Dict[str, Any]:
        """Run comprehensive analysis of HTML directory."""
        print("🔍 ADVANCED HTML CONTENT ANALYSIS")
        print("=" * 60)
        print("Using deep intelligence and content awareness")
        print()
        
        # Find all HTML files
        html_files = []
        for root, dirs, files in os.walk(self.target_dir):
            depth = root.count(os.sep) - str(self.target_dir).count(os.sep)
            if depth <= self.max_depth:
                for file in files:
                    if file.lower().endswith('.html'):
                        html_files.append(Path(root) / file)
        
        print(f"📄 Found {len(html_files)} HTML files")
        
        # Analyze each file
        analyzed_files = []
        for i, file_path in enumerate(html_files, 1):
            if i % 100 == 0:
                print(f"   Analyzing file {i}/{len(html_files)}...")
            
            file_analysis = self.analyze_file(file_path)
            if 'error' not in file_analysis:
                analyzed_files.append(file_analysis)
        
        # Categorize files
        for file_info in analyzed_files:
            if file_info['recommendation'] == 'keep':
                self.analysis_results['worth_keeping'].append(file_info)
            elif file_info['recommendation'] == 'remove':
                self.analysis_results['safe_to_remove'].append(file_info)
            else:
                self.analysis_results['needs_review'].append(file_info)
        
        # Detect duplicates
        duplicates = self.detect_duplicates(html_files)
        for content_hash, duplicate_files in duplicates.items():
            self.analysis_results['duplicate_groups'][content_hash] = [str(f) for f in duplicate_files]
        
        # Update totals
        self.analysis_results['total_files'] = len(analyzed_files)
        
        return self.analysis_results
    
    def save_analysis_report(self) -> str:
        """Save detailed analysis report to CSV."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_file = f"/Users/steven/Documents/python/html_intelligent_analysis_{timestamp}.csv"
        
        with open(csv_file, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'file_path', 'file_name', 'file_size', 'title', 'content_type',
                'quality_score', 'recommendation', 'word_count', 'has_scripts',
                'has_images', 'has_forms', 'has_links', 'modified_time'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            all_files = (self.analysis_results['worth_keeping'] + 
                        self.analysis_results['safe_to_remove'] + 
                        self.analysis_results['needs_review'])
            
            for file_info in all_files:
                row = {
                    'file_path': file_info['file_path'],
                    'file_name': file_info['file_name'],
                    'file_size': file_info['file_size'],
                    'title': file_info['title'],
                    'content_type': file_info['content_type'],
                    'quality_score': file_info['quality_score'],
                    'recommendation': file_info['recommendation'],
                    'word_count': file_info['structure']['word_count'],
                    'has_scripts': file_info['structure']['has_scripts'],
                    'has_images': file_info['structure']['has_images'],
                    'has_forms': file_info['structure']['has_forms'],
                    'has_links': file_info['structure']['has_links'],
                    'modified_time': file_info['modified_time']
                }
                writer.writerow(row)
        
        return csv_file
    
    def save_removal_recommendations(self) -> str:
        """Save removal recommendations to Markdown."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        md_file = f"/Users/steven/Documents/python/html_removal_recommendations_{timestamp}.md"
        
        with open(md_file, 'w', encoding='utf-8') as f:
            f.write("# HTML Content Analysis - Removal Recommendations\n\n")
            f.write(f"**Analysis Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Summary
            f.write("## 📊 Analysis Summary\n\n")
            f.write(f"- **Total Files Analyzed:** {self.analysis_results['total_files']}\n")
            f.write(f"- **Worth Keeping:** {len(self.analysis_results['worth_keeping'])}\n")
            f.write(f"- **Safe to Remove:** {len(self.analysis_results['safe_to_remove'])}\n")
            f.write(f"- **Needs Review:** {len(self.analysis_results['needs_review'])}\n")
            f.write(f"- **Duplicate Groups:** {len(self.analysis_results['duplicate_groups'])}\n\n")
            
            # Worth keeping
            f.write("## ✅ Files Worth Keeping\n\n")
            for file_info in sorted(self.analysis_results['worth_keeping'], 
                                 key=lambda x: x['quality_score'], reverse=True):
                f.write(f"- **{file_info['file_name']}** (Score: {file_info['quality_score']:.1f})\n")
                f.write(f"  - Title: {file_info['title']}\n")
                f.write(f"  - Type: {file_info['content_type']}\n")
                f.write(f"  - Path: {file_info['file_path']}\n\n")
            
            # Safe to remove
            f.write("## 🗑️ Files Safe to Remove\n\n")
            for file_info in sorted(self.analysis_results['safe_to_remove'], 
                                 key=lambda x: x['quality_score']):
                f.write(f"- **{file_info['file_name']}** (Score: {file_info['quality_score']:.1f})\n")
                f.write(f"  - Title: {file_info['title']}\n")
                f.write(f"  - Type: {file_info['content_type']}\n")
                f.write(f"  - Path: {file_info['file_path']}\n\n")
            
            # Duplicates
            if self.analysis_results['duplicate_groups']:
                f.write("## 🔄 Duplicate Files\n\n")
                for content_hash, duplicate_files in self.analysis_results['duplicate_groups'].items():
                    f.write(f"### Group {content_hash[:8]}...\n")
                    for file_path in duplicate_files:
                        f.write(f"- {file_path}\n")
                    f.write("\n")
        
        return md_file

def main():
    """Run the advanced HTML analysis."""
    analyzer = AdvancedHTMLAnalyzer()
    
    # Run analysis
    results = analyzer.run_analysis()
    
    # Save reports
    csv_file = analyzer.save_analysis_report()
    md_file = analyzer.save_removal_recommendations()
    
    # Print summary
    print(f"\n🎯 ANALYSIS COMPLETE!")
    print(f"   📄 Total files: {results['total_files']}")
    print(f"   ✅ Worth keeping: {len(results['worth_keeping'])}")
    print(f"   🗑️ Safe to remove: {len(results['safe_to_remove'])}")
    print(f"   ⚠️ Needs review: {len(results['needs_review'])}")
    print(f"   🔄 Duplicate groups: {len(results['duplicate_groups'])}")
    print(f"\n📊 Reports saved:")
    print(f"   📄 CSV: {csv_file}")
    print(f"   📄 MD: {md_file}")

if __name__ == "__main__":
    main()