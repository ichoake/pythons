#!/usr/bin/env python3
"""
Intelligent Deep Folder Flattener with Parent Context Awareness

Scans to unlimited depth, excludes library/backup folders,
and flattens user scripts intelligently using parent folder names.
"""

import os
import sys
import shutil
from pathlib import Path
from collections import defaultdict
from datetime import datetime

class IntelligentFlattener:
    def __init__(self, target_dir: str, target_depth: int = 6):
        self.target_dir = Path(target_dir)
        self.target_depth = target_depth
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Directories to exclude from flattening
        self.exclude_patterns = {
            'dedup_backup', 'bare_except_backup', 'deep_rename_backup',
            'myenv', 'venv', 'env', '.venv',
            'node_modules', '.git', '__pycache__',
            'site-packages', 'dist-packages',
            '.history', '.pytest_cache', '.tox'
        }

        self.moves = []
        self.stats = {
            'folders_analyzed': 0,
            'files_found': 0,
            'files_to_move': 0,
            'files_moved': 0,
            'errors': 0
        }

    def should_exclude(self, path: Path) -> bool:
        """Check if path should be excluded from flattening."""
        parts = path.parts
        return any(excl in parts for excl in self.exclude_patterns)

    def get_depth(self, path: Path) -> int:
        """Get depth of path relative to target directory."""
        try:
            rel_path = path.relative_to(self.target_dir)
            return len(rel_path.parts)
        except ValueError:
            return 0

    def create_smart_name(self, file_path: Path) -> str:
        """Create intelligent filename using parent folder context."""
        # Get relative path
        rel_path = file_path.relative_to(self.target_dir)
        parts = list(rel_path.parts[:-1])  # Exclude filename

        # Filter out generic folder names
        generic = {'src', 'lib', 'scripts', 'code', 'files', 'data'}
        meaningful_parts = [p for p in parts if p.lower() not in generic]

        # Get original filename without extension
        original_name = file_path.stem
        ext = file_path.suffix

        # Build smart name
        if meaningful_parts:
            # Use last 2-3 meaningful folder names
            context_parts = meaningful_parts[-2:] if len(meaningful_parts) > 1 else meaningful_parts
            # Clean folder names
            context = '-'.join(context_parts).lower()
            context = context.replace('_', '-').replace(' ', '-')

            # If original name doesn't contain context, prepend it
            if not any(part.lower() in original_name.lower() for part in context_parts):
                new_name = f"{context}-{original_name}{ext}"
            else:
                new_name = f"{original_name}{ext}"
        else:
            new_name = f"{original_name}{ext}"

        return new_name

    def find_deep_files(self):
        """Find all Python files deeper than target depth."""
        print(f"\n🔍 Scanning for files deeper than level {self.target_depth}...\n")

        deep_files = []

        for root, dirs, files in os.walk(self.target_dir):
            root_path = Path(root)

            # Skip excluded directories
            if self.should_exclude(root_path):
                dirs.clear()  # Don't recurse into this directory
                continue

            # Check depth
            depth = self.get_depth(root_path)
            self.stats['folders_analyzed'] += 1

            # Find Python files
            for file in files:
                if file.endswith('.py'):
                    file_path = root_path / file
                    self.stats['files_found'] += 1

                    if depth > self.target_depth:
                        deep_files.append(file_path)
                        self.stats['files_to_move'] += 1

        return deep_files

    def create_move_plan(self, deep_files):
        """Create intelligent move plan with parent context awareness."""
        print(f"📋 Creating intelligent move plan...\n")

        move_plan = []
        target_level_map = defaultdict(list)

        for file_path in deep_files:
            # Determine target location (go up to target_depth)
            rel_path = file_path.relative_to(self.target_dir)
            parts = list(rel_path.parts)

            # Target directory is at target_depth
            if len(parts) > self.target_depth:
                target_parts = parts[:self.target_depth]
                target_dir = self.target_dir / Path(*target_parts)
            else:
                target_dir = self.target_dir

            # Create smart filename
            smart_name = self.create_smart_name(file_path)
            target_path = target_dir / smart_name

            # Handle name conflicts
            counter = 1
            original_target = target_path
            while target_path.exists() or target_path in [m['target'] for m in move_plan]:
                stem = original_target.stem
                ext = original_target.suffix
                target_path = target_dir / f"{stem}-{counter}{ext}"
                counter += 1

            move_plan.append({
                'source': file_path,
                'target': target_path,
                'depth': self.get_depth(file_path),
                'target_depth': self.get_depth(target_path.parent)
            })

        return move_plan

    def execute_plan(self, move_plan, dry_run=True):
        """Execute the move plan."""
        mode = "DRY RUN" if dry_run else "LIVE"
        print(f"\n{'='*80}")
        print(f"🚀 EXECUTING MOVE PLAN - {mode}")
        print(f"{'='*80}\n")

        print(f"📊 Files to move: {len(move_plan)}\n")

        for i, move in enumerate(move_plan, 1):
            source = move['source']
            target = move['target']
            depth = move['depth']

            rel_source = source.relative_to(self.target_dir)
            rel_target = target.relative_to(self.target_dir)

            print(f"[{i}/{len(move_plan)}]")
            print(f"  FROM (depth {depth}): {rel_source}")
            print(f"  TO   (depth {move['target_depth']}): {rel_target}")

            if not dry_run:
                try:
                    # Ensure target directory exists
                    target.parent.mkdir(parents=True, exist_ok=True)

                    # Move file
                    shutil.move(str(source), str(target))
                    print(f"  ✅ Moved\n")
                    self.stats['files_moved'] += 1
                except Exception as e:
                    print(f"  ❌ Error: {e}\n")
                    self.stats['errors'] += 1
            else:
                print(f"  🔍 Would move\n")

    def generate_report(self, move_plan):
        """Generate comprehensive report."""
        report_path = self.target_dir / f"INTELLIGENT_FLATTEN_REPORT_{self.timestamp}.md"

        with open(report_path, 'w') as f:
            f.write("# Intelligent Deep Flattening Report\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"**Target Directory:** {self.target_dir}\n")
            f.write(f"**Target Depth:** {self.target_depth} levels\n\n")

            f.write("## Statistics\n\n")
            f.write(f"- **Folders Analyzed:** {self.stats['folders_analyzed']:,}\n")
            f.write(f"- **Python Files Found:** {self.stats['files_found']:,}\n")
            f.write(f"- **Deep Files (>{self.target_depth}):** {self.stats['files_to_move']:,}\n")
            f.write(f"- **Files Moved:** {self.stats['files_moved']:,}\n")
            f.write(f"- **Errors:** {self.stats['errors']}\n\n")

            f.write("## Moves Executed\n\n")
            for i, move in enumerate(move_plan, 1):
                rel_source = move['source'].relative_to(self.target_dir)
                rel_target = move['target'].relative_to(self.target_dir)
                f.write(f"### Move {i}\n")
                f.write(f"- **From (depth {move['depth']}):** `{rel_source}`\n")
                f.write(f"- **To (depth {move['target_depth']}):** `{rel_target}`\n\n")

        print(f"\n📄 Report: {report_path}")
        return report_path

    def run(self, dry_run=True):
        """Run the complete flattening process."""
        print(f"\n{'='*80}")
        print("🧠 INTELLIGENT DEEP FOLDER FLATTENER")
        print(f"{'='*80}\n")
        print(f"Target: {self.target_dir}")
        print(f"Target Depth: {self.target_depth} levels")
        print(f"Mode: {'DRY RUN' if dry_run else 'LIVE'}\n")

        # Step 1: Find deep files
        deep_files = self.find_deep_files()

        print(f"✅ Found {len(deep_files)} files deeper than level {self.target_depth}")
        print(f"📊 Total Python files analyzed: {self.stats['files_found']:,}\n")

        if not deep_files:
            print("✨ No files need flattening! Structure already optimal.\n")
            return

        # Step 2: Create move plan
        move_plan = self.create_move_plan(deep_files)

        # Step 3: Execute plan
        self.execute_plan(move_plan, dry_run)

        # Step 4: Generate report
        if not dry_run:
            self.generate_report(move_plan)

        # Final summary
        print(f"\n{'='*80}")
        print("✅ COMPLETE!")
        print(f"{'='*80}\n")
        print(f"Folders Analyzed: {self.stats['folders_analyzed']:,}")
        print(f"Files Found: {self.stats['files_found']:,}")
        print(f"Files to Move: {self.stats['files_to_move']:,}")
        if not dry_run:
            print(f"Files Moved: {self.stats['files_moved']:,}")
            print(f"Errors: {self.stats['errors']}")
        print()

def main():
    import argparse

    parser = argparse.ArgumentParser(description='Intelligent Deep Folder Flattener')
    parser.add_argument('--target', default='.', help='Target directory')
    parser.add_argument('--depth', type=int, default=6, help='Target max depth (default: 6)')
    parser.add_argument('--live', action='store_true', help='Execute moves (default: dry run)')

    args = parser.parse_args()

    flattener = IntelligentFlattener(args.target, args.depth)
    flattener.run(dry_run=not args.live)

if __name__ == "__main__":
    main()
