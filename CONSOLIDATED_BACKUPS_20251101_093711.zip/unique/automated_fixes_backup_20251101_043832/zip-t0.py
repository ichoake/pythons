import csv
import os
import zipfile
from datetime import datetime


def main():
    # Prompt for folder path
    zip_folder = input(
        "📂 Enter the full path to the folder containing ZIP files: "
    ).strip()

    if not os.path.isdir(zip_folder):
        print(f"❌ Error: '{zip_folder}' is not a valid directory.")
        return

    # Output CSV name (saved in the current script directory)
    output_csv = "zip_contents_inventory.csv"

    # Scan for .zip files
    zip_files = [
        os.path.join(zip_folder, f)
        for f in os.listdir(zip_folder)
        if f.lower().endswith(".zip")
    ]

    if not zip_files:
        print("⚠️ No .zip files found in the directory.")
        return

    # Write to CSV
    with open(output_csv, mode="w", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(
            [
                "ZIP File",
                "Contained File",
                "Size (bytes)",
                "Modified",
                "Compressed Size (bytes)",
            ]
        )

        for zip_path in zip_files:
            try:
                with zipfile.ZipFile(zip_path, "r") as zf:
                    for info in zf.infolist():
                        modified = datetime(*info.date_time).strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                        writer.writerow(
                            [
                                os.path.basename(zip_path),
                                info.filename,
                                info.file_size,
                                modified,
                                info.compress_size,
                            ]
                        )
            except Exception as e:
                print(f"❌ Error reading {zip_path}: {e}")

    print(f"\n✅ Done! CSV saved as: {os.path.abspath(output_csv)}")


if __name__ == "__main__":
    main()
