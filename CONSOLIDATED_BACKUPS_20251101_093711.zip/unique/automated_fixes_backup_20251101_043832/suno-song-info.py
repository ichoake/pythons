import re

import pandas as pd

# Load HTML content from file
file_path = "/Users/steven/Music/suno/1.html"
with open(file_path, "r", encoding="utf-8") as file:
    html_content = file.read()

# Adjusted regex pattern to extract src, title, song_href, style_href, and style
pattern = r'src="([^"]+)".*?title="([^"]+)".*?href="([^"]+)".*?href="([^"]+)">([^<]+)'

# Extract matches
matches = re.findall(pattern, html_content)

# Prepare results for output
results = []
for match in matches:
    results.append(
        {
            "src": match[0],
            "title": match[1],
            "song_href": match[2],
            "style_href": match[3],
            "style": match[4],
        }
    )

# Convert results to DataFrame for better presentation
df = pd.DataFrame(results)
import ace_tools as tools

tools.display_dataframe_to_user(name="Extracted Song and Style Data", dataframe=df)
