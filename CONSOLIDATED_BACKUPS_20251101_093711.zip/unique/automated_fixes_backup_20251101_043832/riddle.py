from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
import csv
import os

# Set up OpenAI API key


def fetch_riddles(number_of_riddles=3):
    prompt_text = "Generate a sphinx riddle with a question, an answer, a correct response message, and an incorrect response message."
    messages = [
        {
            "role": "system",
            "content": "You are about to generate a series of sphinx riddles.",
        },
        {"role": "user", "content": prompt_text * number_of_riddles},
    ]

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=messages,
            temperature=0.7,
            max_tokens=150 * number_of_riddles,
            n=1,
            stop=None,
        )
    except Exception as e:
        print(f"Error fetching riddles: {str(e)}")
        return []

    riddle_texts = response.choices[0].message.content.strip().split("\n\n")
    riddles = [
        dict(
            zip(
                ["query", "answer", "correct_response", "incorrect_response"],
                riddle_text.strip().split("\n"),
            )
        )
        for riddle_text in riddle_texts
        if len(riddle_text.strip().split("\n")) == 4
    ]
    return riddles[:number_of_riddles]


game_log = []


def play_dynamic_game_with_choices():
    try:
        number_of_riddles = int(input("How many riddles do you want to play with? "))
    except ValueError:
        print("Please enter a valid number.")
        return

    riddles = fetch_riddles(number_of_riddles)
    if not riddles:
        return

    for idx, riddle in enumerate(riddles, start=1):
        print(f"{idx}. {riddle['query']}")
        user_answer = input("Your answer: ").strip().lower()

        if user_answer == riddle["answer"]:
            print(riddle["correct_response"])
            result = "Correct"
        else:
            print(riddle["incorrect_response"])
            result = "Incorrect"

        game_log.append(
            {
                "riddle_question": riddle["query"],
                "user_answer": user_answer,
                "correct_answer": riddle["answer"],
                "result": result,
            }
        )


def output_to_csv(logs, filename="riddle_game_log.csv"):
    if logs:
        keys = logs[0].keys()
        with open(filename, "w", newline="") as output_file:
            dict_writer = csv.DictWriter(output_file, keys)
            dict_writer.writeheader()
            dict_writer.writerows(logs)
        print(f"Game log saved to {filename}")


if __name__ == "__main__":
    print("\nSphinx: 'Ah, traveler! Solve my riddles, or be devoured by me.'\n")
    play_dynamic_game_with_choices()
    output_to_csv(game_log)
