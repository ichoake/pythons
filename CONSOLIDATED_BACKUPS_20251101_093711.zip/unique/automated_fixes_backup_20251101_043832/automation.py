#!/usr/bin/env python3
"""
Test Automation Script
=====================
Demonstrates that all automation packages are working correctly.
"""

import sys
import os
from pathlib import Path

# Test all major packages
def test_packages():
    print("🧪 Testing Python Automation Packages")
    print("=" * 50)
    
    # Core packages
    try:
        import requests
        print(f"✅ requests {requests.__version__}")
    except ImportError as e:
        print(f"❌ requests: {e}")
    
    try:
        import pandas as pd
        print(f"✅ pandas {pd.__version__}")
    except ImportError as e:
        print(f"❌ pandas: {e}")
    
    try:
        import numpy as np
        print(f"✅ numpy {np.__version__}")
    except ImportError as e:
        print(f"❌ numpy: {e}")
    
    try:
        import matplotlib.pyplot as plt
        print(f"✅ matplotlib {plt.matplotlib.__version__}")
    except ImportError as e:
        print(f"❌ matplotlib: {e}")
    
    # AI packages
    try:
        import openai
        print(f"✅ openai {openai.__version__}")
    except ImportError as e:
        print(f"❌ openai: {e}")
    
    try:
        import anthropic
        print(f"✅ anthropic {anthropic.__version__}")
    except ImportError as e:
        print(f"❌ anthropic: {e}")
    
    try:
        import groq
        print(f"✅ groq {groq.__version__}")
    except ImportError as e:
        print(f"❌ groq: {e}")
    
    try:
        import ollama
        print("✅ ollama (local AI models)")
    except ImportError as e:
        print(f"❌ ollama: {e}")
    
    # Web automation
    try:
        from selenium import webdriver
        print("✅ selenium (web automation)")
    except ImportError as e:
        print(f"❌ selenium: {e}")
    
    try:
        from playwright.sync_api import sync_playwright
        print("✅ playwright (modern web automation)")
    except ImportError as e:
        print(f"❌ playwright: {e}")
    
    # Data processing
    try:
        from bs4 import BeautifulSoup
        print("✅ beautifulsoup4 (HTML parsing)")
    except ImportError as e:
        print(f"❌ beautifulsoup4: {e}")
    
    # Utility packages
    try:
        from dotenv import load_dotenv
        print("✅ python-dotenv (environment variables)")
    except ImportError as e:
        print(f"❌ python-dotenv: {e}")
    
    try:
        import schedule
        print("✅ schedule (job scheduling)")
    except ImportError as e:
        print(f"❌ schedule: {e}")
    
    try:
        from rich.console import Console
        print("✅ rich (rich text formatting)")
    except ImportError as e:
        print(f"❌ rich: {e}")

def test_environment():
    print("\n🔧 Environment Information")
    print("=" * 50)
    print(f"Python version: {sys.version}")
    print(f"Python executable: {sys.executable}")
    print(f"Working directory: {os.getcwd()}")
    
    # Check if we're in the global environment
    if "global_python_env" in sys.executable:
        print("✅ Using global Python environment")
    else:
        print("⚠️  Not using global Python environment")

def test_api_keys():
    print("\n🔑 API Keys Status")
    print("=" * 50)
    
    # Load environment variables
    try:
        from dotenv import load_dotenv
        load_dotenv()
        
        api_keys = [
            "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY", 
            "GROQ_API_KEY",
            "GROK_API_KEY",
            "DEEPSEEK_API_KEY"
        ]
        
        for key in api_keys:
            if os.getenv(key):
                print(f"✅ {key} loaded")
            else:
                print(f"⚠️  {key} not found")
                
    except ImportError:
        print("❌ python-dotenv not available")

def test_ollama():
    print("\n🦙 Ollama Test")
    print("=" * 50)
    
    try:
        import ollama
        
        # Try to list models
        models = ollama.list()
        print(f"✅ Ollama connection successful")
        print(f"Available models: {len(models['models'])}")
        
        for model in models['models'][:3]:
            model_name = model.get('name', 'Unknown')
            print(f"  • {model_name}")
        
        if len(models['models']) > 3:
            print(f"  ... and {len(models['models']) - 3} more")
            
    except Exception as e:
        print(f"❌ Ollama connection failed: {e}")
        print("💡 Make sure Ollama is running: ollama serve")

def main():
    print("🚀 Python Automation Environment Test")
    print("=" * 60)
    
    test_environment()
    test_packages()
    test_api_keys()
    test_ollama()
    
    print("\n🎉 Test Complete!")
    print("=" * 60)
    print("Your Python automation environment is ready!")
    print("All packages are available without activation.")
    print("Just run: python your_script.py")

if __name__ == "__main__":
    main()