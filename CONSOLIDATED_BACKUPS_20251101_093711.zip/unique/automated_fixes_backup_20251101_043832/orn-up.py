import os

from PIL import Image

# Input and output directories
input_dir = "/Users/steven/Pictures/ornament/processed_output"
output_dir = "/Users/steven/Pictures/ornament/output"

# Max file size in bytes (9MB = 9 * 1024 * 1024)
max_size = 9 * 1024 * 1024

# Target DPI
target_dpi = 300

# Create the output directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)


def upscale_and_compress_image(input_path, output_path, max_size, target_dpi):
    """
    Upscale the image by 2x, set the DPI to 300, and compress to ensure file size is <= 9MB.
    """
    # Open the image
    img = Image.open(input_path)

    # Get original dimensions
    original_width, original_height = img.size

    # Calculate new dimensions (2x upscaling)
    new_width = original_width * 2
    new_height = original_height * 2

    # Resize the image (upscale by 2x)
    img_resized = img.resize((new_width, new_height), Image.LANCZOS)

    # Save the resized image with the correct DPI and high quality
    img_resized.save(output_path, dpi=(target_dpi, target_dpi), quality=95)

    # Compress the image to ensure it's <= 9MB
    compress_image_to_size(output_path, max_size)


def compress_image_to_size(output_path, max_size):
    """
    Compress the image iteratively to fit within the maximum file size.
    """
    quality = 95  # Start with high quality
    while os.path.getsize(output_path) > max_size and quality > 10:
        with Image.open(output_path) as img:
            img.save(output_path, dpi=(300, 300), quality=quality)
            quality -= 5  # Reduce quality in steps

    # Print warning if compression quality drops too low
    if quality <= 10:
        print(f"Warning: Image compression quality dropped below 10 for {output_path}")


# Process all images in the input directory
for filename in os.listdir(input_dir):
    if filename.lower().endswith((".png", ".jpg", ".jpeg")):
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, filename)

        # Process the image: upscale by 2x, set DPI, and compress to max 9MB
        upscale_and_compress_image(input_path, output_path, max_size, target_dpi)

        print(f"Processed and saved: {output_path}")
