#!/usr/bin/env python3
"""
xAI (Grok) CLI - Interface for xAI's Grok models
Supports: Grok-1, Grok-2, and other xAI models
"""

import os
import sys
import argparse
import json
import requests
from typing import Optional, Dict, Any

class XAICLI:
    def __init__(self):
        self.load_env()
        self.base_url = "https://api.x.ai/v1"
    
    def load_env(self):
        """Load environment variables from ~/.env file"""
        env_file = os.path.expanduser("~/.env")
        if os.path.exists(env_file):
            with open(env_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        os.environ[key] = value
    
    def get_models(self) -> list:
        """Get available xAI models"""
        return [
            "grok-beta",           # Grok-2 (latest)
            "grok-2-1212",         # Grok-2 specific version
            "grok-2-1212-preview", # Grok-2 preview
            "grok-1.5",            # Grok-1.5
            "grok-1",              # Grok-1
        ]
    
    def chat(self, message: str, model: str = "grok-beta") -> str:
        """Chat with xAI Grok models"""
        api_key = os.getenv('XAI_API_KEY')
        if not api_key:
            return "❌ Error: XAI_API_KEY not found in environment variables\n💡 Add your API key to ~/.env file:\n   XAI_API_KEY=your_key_here"
        
        try:
            url = f"{self.base_url}/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            data = {
                "model": model,
                "messages": [{"role": "user", "content": message}],
                "max_tokens": 4000,
                "temperature": 0.7
            }
            
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            result = response.json()
            return result['choices'][0]['message']['content']
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                return "❌ Error: Invalid XAI API key. Please check your XAI_API_KEY in ~/.env"
            elif e.response.status_code == 429:
                return "❌ Error: Rate limit exceeded. Please try again later."
            else:
                return f"❌ Error: HTTP {e.response.status_code} - {e.response.text}"
        except Exception as e:
            return f"❌ Error: {e}"
    
    def stream_chat(self, message: str, model: str = "grok-beta") -> None:
        """Stream chat response from xAI Grok models"""
        api_key = os.getenv('XAI_API_KEY')
        if not api_key:
            print("❌ Error: XAI_API_KEY not found")
            return
        
        try:
            url = f"{self.base_url}/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            data = {
                "model": model,
                "messages": [{"role": "user", "content": message}],
                "max_tokens": 4000,
                "temperature": 0.7,
                "stream": True
            }
            
            response = requests.post(url, headers=headers, json=data, stream=True)
            response.raise_for_status()
            
            print("🤖 Grok: ", end="", flush=True)
            for line in response.iter_lines():
                if line:
                    try:
                        line_data = json.loads(line.decode('utf-8'))
                        if 'choices' in line_data and len(line_data['choices']) > 0:
                            delta = line_data['choices'][0].get('delta', {})
                            if 'content' in delta:
                                print(delta['content'], end="", flush=True)
                    except json.JSONDecodeError:
                        continue
            print()  # New line after streaming
        except Exception as e:
            print(f"❌ Error: {e}")

def main():
    parser = argparse.ArgumentParser(description='xAI (Grok) CLI - Chat with xAI models')
    parser.add_argument('message', nargs='?', help='Your message to Grok')
    parser.add_argument('-m', '--model', default='grok-beta', 
                       help='Grok model to use (default: grok-beta)')
    parser.add_argument('-i', '--interactive', action='store_true', 
                       help='Start interactive mode')
    parser.add_argument('-s', '--stream', action='store_true', 
                       help='Stream the response')
    parser.add_argument('-l', '--list-models', action='store_true', 
                       help='List available models')
    parser.add_argument('-f', '--file', help='Read message from file')
    
    args = parser.parse_args()
    
    xai = XAICLI()
    
    if args.list_models:
        models = xai.get_models()
        print("🤖 Available xAI Models:")
        print("=" * 40)
        for model in models:
            print(f"  • {model}")
        print("\n💡 Recommended: grok-beta (Grok-2)")
        return
    
    # Get message
    if args.file:
        try:
            with open(args.file, 'r') as f:
                message = f.read().strip()
        except FileNotFoundError:
            print(f"❌ Error: File '{args.file}' not found")
            sys.exit(1)
    elif args.interactive:
        print(f"🤖 xAI Grok Interactive Mode - {args.model} (type 'quit' to exit)")
        print("=" * 60)
        while True:
            try:
                message = input(f"\n💬 You: ").strip()
                if message.lower() in ['quit', 'exit', 'q']:
                    print("👋 Goodbye!")
                    break
                if not message:
                    continue
                
                if args.stream:
                    xai.stream_chat(message, args.model)
                else:
                    response = xai.chat(message, args.model)
                    print(f"\n🤖 Grok: {response}")
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                break
        return
    elif args.message:
        message = args.message
    else:
        # Read from stdin
        message = sys.stdin.read().strip()
        if not message:
            print("❌ No message provided")
            parser.print_help()
            sys.exit(1)
    
    # Chat with Grok
    if args.stream:
        xai.stream_chat(message, args.model)
    else:
        response = xai.chat(message, args.model)
        print(response)

if __name__ == "__main__":
    main()