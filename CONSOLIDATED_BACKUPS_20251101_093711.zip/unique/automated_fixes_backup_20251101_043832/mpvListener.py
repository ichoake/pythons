import mpv

player = mpv.MPV()
player.stop()
