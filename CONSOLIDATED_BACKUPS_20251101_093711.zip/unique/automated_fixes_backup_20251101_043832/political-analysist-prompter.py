import os
import argparse
from pathlib import Path
from dotenv import load_dotenv
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor
import logging
import base64
import subprocess

# Config class with updated prompt for Christian Nationalism
class Config:
    MODEL = "gpt-4o"
    MAX_TOKENS = 1500
    TEMPERATURE = 0.7
    MAX_ATTEMPTS = 3
    PROMPT_TYPE = "christian_nationalism"  # New prompt type

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Load environment
load_dotenv(Path.home() / ".env")
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
if not client.api_key:
    raise EnvironmentError("OpenAI API key not found.")

# Format timestamp
def format_timestamp(seconds: float) -> str:
    minutes = int(seconds // 60)
    seconds = int(seconds % 60)
    return f"{minutes:02d}:{seconds:02d}"

# Transcribe audio/video
def transcribe_media(file_path: Path, max_attempts: int = Config.MAX_ATTEMPTS) -> str | None:
    if not file_path.exists() or file_path.stat().st_size == 0:
        logging.error(f"Invalid file: {file_path}")
        return None
    for attempt in range(max_attempts):
        try:
            with file_path.open("rb") as f:
                transcript_data = client.audio.transcriptions.create(
                    model="whisper-1", file=f, response_format="verbose_json"
                )
                return "\n".join(
                    f"{format_timestamp(s['start'])} -- {format_timestamp(s['end'])}: {s['text']}"
                    for s in transcript_data.segments
                )
        except Exception as e:
            logging.error(f"Attempt {attempt + 1} failed for {file_path}: {e}")
            if attempt < max_attempts - 1:
                time.sleep(2 ** attempt)
    return None

# Analyze text with Christian Nationalism focus
def analyze_text(text: str, prompt_type: str = Config.PROMPT_TYPE) -> str | None:
    prompts = {
        "christian_nationalism": (
            "You are an expert in political analysis. Analyze the transcript for themes of White Christian Nationalism, crusader symbolism, and fascist aesthetics. Identify references to theocracy, authoritarian control, and exclusionary policies. Structure in 7 sections: "
            "1. Central Themes, 2. Emotional Tone, 3. Crusader Symbolism, 4. Fascist Aesthetics, 5. Theocratic Elements, 6. Policy Impacts, 7. Narrative Arc. Transcript: {text}"
        ),
        "multimedia": "You are an expert in multimedia analysis. Analyze for themes, emotional tone, narrative structure, and visual/audio synergy. Structure in 9 sections: 1. Central Themes... Transcript: {text}",
        "shorts": "You are an expert in YouTube Shorts. Analyze for brevity, core message, emotional tone, and engagement in 5 sections: 1. Core Message... Transcript: {text}"
    }
    system_prompt = prompts.get(prompt_type, prompts["christian_nationalism"]).format(text=text)
    for attempt in range(Config.MAX_ATTEMPTS):
        try:
            response = client.chat.completions.create(
                model=Config.MODEL,
                messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": text}],
                max_tokens=Config.MAX_TOKENS,
                temperature=Config.TEMPERATURE
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            logging.error(f"Analysis attempt {attempt + 1} failed: {e}")
            if attempt < Config.MAX_ATTEMPTS - 1:
                time.sleep(2 ** attempt)
    return None

# Analyze image for crusader/fascist aesthetics
def analyze_image(image_path: Path) -> dict | None:
    try:
        with image_path.open("rb") as f:
            image_data = base64.b64encode(f.read()).decode("utf-8")
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{
                "role": "user",
                "content": [
                    {"type": "text", "text": "Analyze for print-on-demand: main subject, style, colors, emotional tone, typography suitability. Focus on White Christian Nationalism, crusader symbolism, and fascist aesthetics."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_data}"}}
                ]
            }],
            max_tokens=1000
        )
        return response.choices[0].message.content
    except Exception as e:
        logging.error(f"Image analysis failed for {image_path}: {e}")
        return None

# Main processing
def process_media(input_path: str, output_dir: str, media_type: str, prompt_type: str):
    input_path = Path(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    files = [input_path] if input_path.is_file() else list(input_path.glob("*.mp3")) + list(input_path.glob("*.mp4"))
    with ThreadPoolExecutor() as executor:
        for file in files:
            transcript = transcribe_media(file)
            if transcript:
                analysis = analyze_text(transcript, prompt_type)
                with (output_dir / f"{file.stem}_analysis.txt").open("w") as f:
                    f.write(analysis)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Analyze media for Project 2025 Christian Nationalism podcast.")
    parser.add_argument("--input", default="/Users/steven/Music/py", help="Input file or directory")
    parser.add_argument("--output", default="/Users/steven/Music/output", help="Output directory")
    parser.add_argument("--type", choices=["audio", "video", "image"], default="audio", help="Media type")
    parser.add_argument("--prompt", choices=["christian_nationalism", "multimedia", "shorts"], default="christian_nationalism", help="Prompt type")
    args = parser.parse_args()
    process_media(args.input, args.output, args.type, args.prompt)