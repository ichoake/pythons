import os

import pandas as pd


# 🚀 Your Custom Sorting Logic – Because Machines Should Think for You
def categorize_platform(filename):
    """Determines if an image belongs on Etsy or TikTok based on filename magic."""
    etsy_keywords = [
        "vintage",
        "handmade",
        "rustic",
        "cozy",
        "aesthetic",
        "custom",
        "wedding",
        "gift",
        "doormat",
        "candle",
    ]
    tiktok_keywords = [
        "viral",
        "meme",
        "trend",
        "bold",
        "neon",
        "glitch",
        "edgy",
        "pop",
        "hype",
        "streetwear",
    ]

    filename_lower = filename.lower()

    if any(keyword in filename_lower for keyword in etsy_keywords):
        return "Etsy"
    elif any(keyword in filename_lower for keyword in tiktok_keywords):
        return "TikTok"
    else:
        return "Unknown (Fix Your Naming)"


# 📂 Load Your File – Assuming It’s in the Same Folder as This Script
input_file = "/Users/steven/Downloads/Misc/Untitled spreadsheet - image_data-01-29-22-55(1).csv"  # Change this to match your actual file
output_file = f"/Users/steven/Downloads/Misc/sorted.csv"

# 🧐 Read the CSV with Intelligence (or at Least an Attempt)
try:
    df = pd.read_csv(input_file)

    if "Filename" not in df.columns:
        raise ValueError(
            "💀 ERROR: Your CSV file is missing the 'Filename' column. Add it and try again."
        )

    # 🏷 Apply Platform Categorization
    df["Platform"] = df["Filename"].apply(categorize_platform)

    # 🎩 Sorting Like a Pro
    df_sorted = df.sort_values(by=["Platform", "Filename"])

    # 📝 Save the Magic
    df_sorted.to_csv(output_file, index=False)

    print(f"🎉 Success! Your images are now sorted into {output_file}")
except Exception as e:
    print(f"❌ ERROR: {e}")
