import hashlib
import random
from datetime import datetime


class ChaosScheduler:
    def __init__(self, seed=None):
        self.seed = seed or self._generate_quantum_seed()

    def _generate_quantum_seed(self):
        ts = str(datetime.now().timestamp()).encode()
        return int(hashlib.sha3_256(ts).hexdigest(), 16) % 2**32

    def schedule_operation(self, operation, criticality=3):
        random.seed(self.seed)
        chaos_level = (criticality * 0.15) + (random.random() * 0.35)
        if random.random() < chaos_level:
            raise RuntimeError(f"Chaos failure (Level {chaos_level:.2f})")
        return operation()
