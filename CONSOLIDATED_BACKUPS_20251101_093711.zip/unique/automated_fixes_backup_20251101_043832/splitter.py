def split_text(text: str, char_limit: int = 6000):
    """Chunk by characters, splitting on sentence boundaries where possible."""
    import re
    sents = re.split(r'(?<=[.!?])\s+', text.strip())
    chunks, cur = [], ""
    for s in sents:
        if len(cur) + len(s) + 1 > char_limit and cur:
            chunks.append(cur.strip())
            cur = s
        else:
            cur = (cur + " " + s).strip()
    if cur:
        chunks.append(cur)
    return chunks
