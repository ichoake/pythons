"""
This is not a plugin, this is just the place were plugins are registered.
"""

from jedi.plugins import django, flask, plugin_manager, pytest, stdlib

plugin_manager.register(stdlib, flask, pytest, django)
