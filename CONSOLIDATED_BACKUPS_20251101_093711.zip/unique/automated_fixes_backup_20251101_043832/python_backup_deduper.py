#!/usr/bin/env python3
"""
Comprehensive Python Backup Analysis Tool
Analyzes, compares, sorts, merges, and removes duplicates from Python backup directories
"""

import os
import hashlib
import json
import shutil
from datetime import datetime
from pathlib import Path
from collections import defaultdict
import zipfile

class PythonBackupAnalyzer:
    def __init__(self, paths):
        self.paths = paths
        self.file_hashes = defaultdict(list)
        self.file_info = {}
        self.duplicates = []
        self.unique_files = []
        self.analysis_results = {}
        
    def calculate_file_hash(self, file_path):
        """Calculate SHA256 hash of a file"""
        hash_sha256 = hashlib.sha256()
        try:
            with open(file_path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except (IOError, OSError):
            return None
    
    def get_file_info(self, file_path):
        """Get comprehensive file information"""
        try:
            stat = os.stat(file_path)
            return {
                'path': str(file_path),
                'size': stat.st_size,
                'mtime': stat.st_mtime,
                'mtime_readable': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S'),
                'relative_path': str(file_path.relative_to(Path(file_path).parents[1])),
                'extension': Path(file_path).suffix,
                'name': Path(file_path).name
            }
        except (IOError, OSError):
            return None
    
    def analyze_directory(self, dir_path):
        """Analyze a directory and collect file information"""
        print(f"Analyzing directory: {dir_path}")
        file_count = 0
        
        for root, dirs, files in os.walk(dir_path):
            for file in files:
                file_path = Path(root) / file
                file_info = self.get_file_info(file_path)
                
                if file_info:
                    file_hash = self.calculate_file_hash(file_path)
                    if file_hash:
                        file_info['hash'] = file_hash
                        self.file_hashes[file_hash].append(file_info)
                        self.file_info[file_path] = file_info
                        file_count += 1
        
        print(f"Found {file_count} files in {dir_path}")
        return file_count
    
    def analyze_zip_file(self, zip_path):
        """Analyze a ZIP file and extract file information"""
        print(f"Analyzing ZIP file: {zip_path}")
        file_count = 0
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_file:
                for file_info in zip_file.infolist():
                    if not file_info.is_dir():
                        # Create a temporary file info structure
                        temp_info = {
                            'path': f"{zip_path}::{file_info.filename}",
                            'size': file_info.file_size,
                            'mtime': file_info.date_time,
                            'mtime_readable': datetime(*file_info.date_time).strftime('%Y-%m-%d %H:%M:%S'),
                            'relative_path': file_info.filename,
                            'extension': Path(file_info.filename).suffix,
                            'name': Path(file_info.filename).name,
                            'is_zip_content': True
                        }
                        
                        # For ZIP contents, we can't easily calculate hash without extracting
                        # We'll use a combination of size, name, and path as a pseudo-hash
                        pseudo_hash = hashlib.sha256(
                            f"{file_info.filename}:{file_info.file_size}".encode()
                        ).hexdigest()
                        
                        temp_info['hash'] = pseudo_hash
                        self.file_hashes[pseudo_hash].append(temp_info)
                        self.file_info[temp_info['path']] = temp_info
                        file_count += 1
        except Exception as e:
            print(f"Error analyzing ZIP file {zip_path}: {e}")
        
        print(f"Found {file_count} files in ZIP {zip_path}")
        return file_count
    
    def identify_duplicates(self):
        """Identify duplicate files based on hash"""
        print("\nIdentifying duplicates...")
        
        for file_hash, files in self.file_hashes.items():
            if len(files) > 1:
                # Sort by modification time (newest first)
                files.sort(key=lambda x: x['mtime'], reverse=True)
                
                # Keep the newest file as the "master"
                master_file = files[0]
                duplicates = files[1:]
                
                self.duplicates.append({
                    'hash': file_hash,
                    'master': master_file,
                    'duplicates': duplicates,
                    'count': len(files)
                })
                
                self.unique_files.append(master_file)
            else:
                self.unique_files.append(files[0])
        
        print(f"Found {len(self.duplicates)} groups of duplicate files")
        print(f"Total unique files: {len(self.unique_files)}")
    
    def generate_analysis_report(self):
        """Generate comprehensive analysis report"""
        total_files = sum(len(files) for files in self.file_hashes.values())
        total_duplicates = sum(dup['count'] - 1 for dup in self.duplicates)
        space_saved = sum(dup['master']['size'] * (dup['count'] - 1) for dup in self.duplicates)
        
        self.analysis_results = {
            'timestamp': datetime.now().isoformat(),
            'total_files_analyzed': total_files,
            'unique_files': len(self.unique_files),
            'duplicate_groups': len(self.duplicates),
            'total_duplicates': total_duplicates,
            'space_saved_bytes': space_saved,
            'space_saved_mb': round(space_saved / (1024 * 1024), 2),
            'space_saved_gb': round(space_saved / (1024 * 1024 * 1024), 2),
            'paths_analyzed': self.paths,
            'file_breakdown': {}
        }
        
        # Analyze by source
        for path in self.paths:
            if os.path.isdir(path):
                files_from_path = [f for f in self.unique_files if f['path'].startswith(path)]
                self.analysis_results['file_breakdown'][path] = {
                    'type': 'directory',
                    'file_count': len(files_from_path),
                    'total_size': sum(f['size'] for f in files_from_path)
                }
            elif path.endswith('.zip'):
                files_from_zip = [f for f in self.unique_files if f['path'].startswith(path)]
                self.analysis_results['file_breakdown'][path] = {
                    'type': 'zip',
                    'file_count': len(files_from_zip),
                    'total_size': sum(f['size'] for f in files_from_zip)
                }
    
    def sort_files(self):
        """Sort files by various criteria"""
        print("\nSorting files...")
        
        # Sort by modification time (newest first)
        self.unique_files.sort(key=lambda x: x['mtime'], reverse=True)
        
        # Sort by size (largest first)
        self.unique_files.sort(key=lambda x: x['size'], reverse=True)
        
        print("Files sorted by size (largest first) and modification time (newest first)")
    
    def create_merge_plan(self, output_dir):
        """Create a plan for merging directories"""
        print(f"\nCreating merge plan for output directory: {output_dir}")
        
        merge_plan = {
            'output_directory': output_dir,
            'files_to_copy': [],
            'duplicates_to_remove': [],
            'directories_to_create': set()
        }
        
        # Plan file copies
        for file_info in self.unique_files:
            if not file_info.get('is_zip_content', False):
                # Calculate relative path for output
                relative_path = file_info['relative_path']
                output_path = os.path.join(output_dir, relative_path)
                
                merge_plan['files_to_copy'].append({
                    'source': file_info['path'],
                    'destination': output_path,
                    'size': file_info['size'],
                    'mtime': file_info['mtime']
                })
                
                # Track directories to create
                merge_plan['directories_to_create'].add(os.path.dirname(output_path))
        
        # Plan duplicate removal
        for dup_group in self.duplicates:
            for duplicate in dup_group['duplicates']:
                if not duplicate.get('is_zip_content', False):
                    merge_plan['duplicates_to_remove'].append(duplicate['path'])
        
        merge_plan['directories_to_create'] = list(merge_plan['directories_to_create'])
        
        return merge_plan
    
    def save_analysis_report(self, output_file):
        """Save analysis report to JSON file"""
        with open(output_file, 'w') as f:
            json.dump(self.analysis_results, f, indent=2)
        print(f"Analysis report saved to: {output_file}")
    
    def save_duplicates_report(self, output_file):
        """Save detailed duplicates report"""
        duplicates_report = {
            'timestamp': datetime.now().isoformat(),
            'duplicate_groups': self.duplicates,
            'summary': {
                'total_groups': len(self.duplicates),
                'total_duplicates': sum(dup['count'] - 1 for dup in self.duplicates)
            }
        }
        
        with open(output_file, 'w') as f:
            json.dump(duplicates_report, f, indent=2)
        print(f"Duplicates report saved to: {output_file}")

def main():
    # Define paths to analyze
    paths = [
        "/Users/steven/Documents/python_backup_20251013_005711",
        "/Users/steven/Documents/python_backup_20251013_005814", 
        "/Users/steven/Documents/python",
        "/Users/steven/Documents/python.zip",
        "/Users/steven/Documents/python2.zip"
    ]
    
    # Initialize analyzer
    analyzer = PythonBackupAnalyzer(paths)
    
    print("=== Python Backup Analysis Tool ===")
    print(f"Analyzing {len(paths)} locations...")
    
    # Analyze each path
    for path in paths:
        if os.path.isdir(path):
            analyzer.analyze_directory(path)
        elif path.endswith('.zip') and os.path.exists(path):
            analyzer.analyze_zip_file(path)
        else:
            print(f"Warning: Path not found or not supported: {path}")
    
    # Identify duplicates
    analyzer.identify_duplicates()
    
    # Sort files
    analyzer.sort_files()
    
    # Generate analysis report
    analyzer.generate_analysis_report()
    
    # Save reports
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    analyzer.save_analysis_report(f"/Users/steven/python_backup_analysis_{timestamp}.json")
    analyzer.save_duplicates_report(f"/Users/steven/python_backup_duplicates_{timestamp}.json")
    
    # Create merge plan
    output_dir = "/Users/steven/Documents/python_merged"
    merge_plan = analyzer.create_merge_plan(output_dir)
    
    # Save merge plan
    with open(f"/Users/steven/python_merge_plan_{timestamp}.json", 'w') as f:
        json.dump(merge_plan, f, indent=2)
    
    print(f"\n=== ANALYSIS COMPLETE ===")
    print(f"Total files analyzed: {analyzer.analysis_results['total_files_analyzed']}")
    print(f"Unique files: {analyzer.analysis_results['unique_files']}")
    print(f"Duplicate groups: {analyzer.analysis_results['duplicate_groups']}")
    print(f"Space that can be saved: {analyzer.analysis_results['space_saved_gb']} GB")
    print(f"Merge plan created for: {output_dir}")

if __name__ == "__main__":
    main()