import os
from difflib import SequenceMatcher
from pathlib import Path

def similarity(a, b):
    return SequenceMatcher(None, a, b).ratio()

def find_similar_files(directory, name_threshold=0.9, content_threshold=0.8):
    py_files = [f for f in Path(directory).rglob("*.py")]
    similar_files = []
    for i, file1 in enumerate(py_files):
        for file2 in py_files[i + 1:]:
            name_sim = similarity(file1.stem.lower(), file2.stem.lower())
            if name_sim > name_threshold:
                with open(file1, 'r', encoding='utf-8') as f1, open(file2, 'r', encoding='utf-8') as f2:
                    content1 = f1.read()
                    content2 = f2.read()
                    content_sim = similarity(content1, content2)
                    if content_sim > content_threshold:
                        similar_files.append((str(file1), str(file2), name_sim, content_sim))
    return similar_files

def keep_latest_file(group):
    sorted_group = sorted(group, key=lambda x: Path(x).stem, reverse=True)
    keep_file = sorted_group[0]
    delete_files = sorted_group[1:]
    print(f"Keeping: {keep_file}")
    for file in delete_files:
        print(f"Deleting: {file}")
        os.remove(file)

# Backup first
os.system("rsync -a /Users/steven/Documents/python/sphinx-docs/ /Users/steven/Documents/python/sphinx-docs_backup/")

# Find similar files
directory = "/Users/steven/Documents/python/sphinx-docs"
similar_files = find_similar_files(directory)
for file1, file2, name_sim, content_sim in similar_files:
    print(f"Files: {file1} and {file2}")
    print(f"Name Similarity: {name_sim:.2f}, Content Similarity: {content_sim:.2f}\n")
    keep_latest_file([file1, file2])
