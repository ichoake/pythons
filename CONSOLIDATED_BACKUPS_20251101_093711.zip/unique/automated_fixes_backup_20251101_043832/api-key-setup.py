#!/usr/bin/env python3
"""
API Key Setup Assistant
Automatically opens registration pages for missing API keys in ~/.env
"""

import os
import re
import webbrowser
import time
from typing import Dict, List, Tuple

class APIKeySetup:
    def __init__(self):
        self.env_dir = os.path.expanduser("~/.env.d")
        self.api_service_mapping = {
            "PERPLEXITY_API_KEY": "llm-apis.env",
            "GEMINI_API_KEY": "llm-apis.env",
            "XAI_API_KEY": "llm-apis.env",
            "HUGGINGFACE_API_KEY": "llm-apis.env",
            "LEONARDO_API_KEY": "art-vision.env",
            "IMAGGA_API_KEY": "art-vision.env",
            "STABILITY_API_KEY": "art-vision.env",
            "REPLICATE_API_TOKEN": "art-vision.env",
            "RUNWAY_API_KEY": "art-vision.env",
            "IDEOGRAM_API_KEY": "art-vision.env",
            "KAIBER_API_KEY": "art-vision.env",
            "PIKA_API_KEY": "art-vision.env",
            "SUNO_API_KEY": "audio-music.env",
            "ELEVENLABS_API_KEY": "audio-music.env",
            "ASSEMBLYAI_API_KEY": "audio-music.env",
            "DEEPGRAM_API_KEY": "audio-music.env",
            "INVIDEO_API_KEY": "audio-music.env",
            "SORAI_API_KEY": "audio-music.env",
            "COHERE_API_KEY": "llm-apis.env",
            "FIREWORKS_API_KEY": "llm-apis.env",
            "PINECONE_API_KEY": "vector-memory.env",
            "SUPABASE_KEY": "vector-memory.env",
            "QDRANT_API_KEY": "vector-memory.env",
            "OPENROUTER_API_KEY": "llm-apis.env",
            "LANGSMITH_API_KEY": "llm-apis.env",
            "SERPAPI_KEY": "seo-analytics.env",
            "NEWSAPI_KEY": "seo-analytics.env",
            "AZURE_OPENAI_KEY": "cloud-infrastructure.env",
            "TWILIO_ACCOUNT_SID": "notifications.env",
            "ZAPIER_API_KEY": "automation-agents.env",
            "MAKE_API_KEY": "automation-agents.env",
            "NOTION_TOKEN": "documents.env",
            "SLITE_API_KEY": "documents.env",
            "CHROMADB_API_KEY": "vector-memory.env",
            "ZEP_API_KEY": "vector-memory.env",
            "MOONVALLEY_API_KEY": "other-tools.env",
            "ARCGIS_API_KEY": "other-tools.env",
            "SUPERNORMAL_API_KEY": "other-tools.env",
            "DESCRIPT_API_KEY": "other-tools.env",
            "SONIX_API_KEY": "other-tools.env",
            "REVAI_API_KEY": "other-tools.env",
            "SPEECHMATICS_API_KEY": "other-tools.env",
        }
        self.api_services = {
            # LLMs / TEXT / RESEARCH
            "PERPLEXITY_API_KEY": {
                "name": "Perplexity AI",
                "url": "https://www.perplexity.ai/settings/api",
                "description": "AI-powered search and research"
            },
            "GEMINI_API_KEY": {
                "name": "Google Gemini",
                "url": "https://makersuite.google.com/app/apikey",
                "description": "Google's AI model"
            },
            "XAI_API_KEY": {
                "name": "xAI (Grok)",
                "url": "https://console.x.ai/",
                "description": "Elon Musk's AI company (Grok models)"
            },
            "HUGGINGFACE_API_KEY": {
                "name": "Hugging Face",
                "url": "https://huggingface.co/settings/tokens",
                "description": "Open source AI models and datasets"
            },
            
            # ART / VISION / IMAGE
            "LEONARDO_API_KEY": {
                "name": "Leonardo AI",
                "url": "https://leonardo.ai/",
                "description": "AI image generation"
            },
            "IMAGGA_API_KEY": {
                "name": "Imagga",
                "url": "https://imagga.com/profile/signup",
                "description": "Image analysis and tagging"
            },
            "STABILITY_API_KEY": {
                "name": "Stability AI",
                "url": "https://platform.stability.ai/account/keys",
                "description": "Stable Diffusion and other AI models"
            },
            "REPLICATE_API_TOKEN": {
                "name": "Replicate",
                "url": "https://replicate.com/account/api-tokens",
                "description": "Run AI models in the cloud"
            },
            "RUNWAY_API_KEY": {
                "name": "Runway ML",
                "url": "https://runwayml.com/",
                "description": "AI video and image generation"
            },
            "IDEOGRAM_API_KEY": {
                "name": "Ideogram",
                "url": "https://ideogram.ai/",
                "description": "AI image generation with text"
            },
            "KAIBER_API_KEY": {
                "name": "Kaiber",
                "url": "https://kaiber.ai/",
                "description": "AI music video generation"
            },
            "PIKA_API_KEY": {
                "name": "Pika Labs",
                "url": "https://pika.art/",
                "description": "AI video generation"
            },
            
            # AUDIO / MUSIC / VIDEO
            "SUNO_API_KEY": {
                "name": "Suno AI",
                "url": "https://suno.ai/",
                "description": "AI music generation"
            },
            "ELEVENLABS_API_KEY": {
                "name": "ElevenLabs",
                "url": "https://elevenlabs.io/app/settings/api-keys",
                "description": "AI voice synthesis"
            },
            "ASSEMBLYAI_API_KEY": {
                "name": "AssemblyAI",
                "url": "https://www.assemblyai.com/dashboard/signup",
                "description": "Speech-to-text API"
            },
            "DEEPGRAM_API_KEY": {
                "name": "Deepgram",
                "url": "https://console.deepgram.com/signup",
                "description": "Speech recognition and understanding"
            },
            "INVIDEO_API_KEY": {
                "name": "InVideo",
                "url": "https://invideo.io/",
                "description": "AI video creation"
            },
            "SORAI_API_KEY": {
                "name": "Sora AI",
                "url": "https://openai.com/sora",
                "description": "OpenAI's video generation"
            },
            
            # AUTOMATION / AGENTS / VECTOR DB
            "COHERE_API_KEY": {
                "name": "Cohere",
                "url": "https://dashboard.cohere.ai/",
                "description": "Language AI platform"
            },
            "FIREWORKS_API_KEY": {
                "name": "Fireworks AI",
                "url": "https://fireworks.ai/",
                "description": "Fast inference for open source models"
            },
            "PINECONE_API_KEY": {
                "name": "Pinecone",
                "url": "https://app.pinecone.io/",
                "description": "Vector database for AI"
            },
            "SUPABASE_KEY": {
                "name": "Supabase",
                "url": "https://supabase.com/dashboard",
                "description": "Open source Firebase alternative"
            },
            "QDRANT_API_KEY": {
                "name": "Qdrant",
                "url": "https://cloud.qdrant.io/",
                "description": "Vector database and similarity search"
            },
            "OPENROUTER_API_KEY": {
                "name": "OpenRouter",
                "url": "https://openrouter.ai/",
                "description": "Universal API for LLMs"
            },
            "LANGSMITH_API_KEY": {
                "name": "LangSmith",
                "url": "https://smith.langchain.com/",
                "description": "LangChain's debugging and monitoring"
            },
            
            # SEO / SCRAPING / ANALYTICS
            "SERPAPI_KEY": {
                "name": "SerpAPI",
                "url": "https://serpapi.com/",
                "description": "Google search results API"
            },
            "NEWSAPI_KEY": {
                "name": "NewsAPI",
                "url": "https://newsapi.org/register",
                "description": "News headlines API"
            },
            
            # CLOUD / INFRASTRUCTURE
            "AZURE_OPENAI_KEY": {
                "name": "Azure OpenAI",
                "url": "https://portal.azure.com/",
                "description": "Microsoft's OpenAI service"
            },
            
            # NOTIFICATIONS / AUTOMATION
            "TWILIO_ACCOUNT_SID": {
                "name": "Twilio",
                "url": "https://console.twilio.com/",
                "description": "Communication platform (SMS, voice, etc.)"
            },
            "ZAPIER_API_KEY": {
                "name": "Zapier",
                "url": "https://zapier.com/app/settings/integrations",
                "description": "Workflow automation"
            },
            "MAKE_API_KEY": {
                "name": "Make (Integromat)",
                "url": "https://www.make.com/",
                "description": "Visual automation platform"
            },
            
            # DOCUMENTS / KNOWLEDGE
            "NOTION_TOKEN": {
                "name": "Notion",
                "url": "https://www.notion.so/my-integrations",
                "description": "All-in-one workspace"
            },
            "SLITE_API_KEY": {
                "name": "Slite",
                "url": "https://slite.com/",
                "description": "Team knowledge base"
            },
            
            # VECTOR / MEMORY
            "CHROMADB_API_KEY": {
                "name": "Chroma",
                "url": "https://www.trychroma.com/",
                "description": "Open source vector database"
            },
            "ZEP_API_KEY": {
                "name": "Zep",
                "url": "https://www.getzep.com/",
                "description": "Long-term memory for AI applications"
            },
            
            # OTHER
            "MOONVALLEY_API_KEY": {
                "name": "Moonvalley",
                "url": "https://moonvalley.ai/",
                "description": "AI video generation"
            },
            "ARCGIS_API_KEY": {
                "name": "ArcGIS",
                "url": "https://developers.arcgis.com/",
                "description": "Mapping and location services"
            },
            "SUPERNORMAL_API_KEY": {
                "name": "Supernormal",
                "url": "https://supernormal.com/",
                "description": "AI meeting notes"
            },
            "DESCRIPT_API_KEY": {
                "name": "Descript",
                "url": "https://www.descript.com/",
                "description": "AI video and audio editing"
            },
            "SONIX_API_KEY": {
                "name": "Sonix",
                "url": "https://sonix.ai/",
                "description": "AI transcription service"
            },
            "REVAI_API_KEY": {
                "name": "Rev.ai",
                "url": "https://www.rev.ai/",
                "description": "Speech-to-text API"
            },
            "SPEECHMATICS_API_KEY": {
                "name": "Speechmatics",
                "url": "https://www.speechmatics.com/",
                "description": "Speech recognition API"
            }
        }

    def load_env_files(self) -> List[str]:
        """Load all .env files from the ~/.env.d directory and return their lines"""
        lines = []
        if not os.path.exists(self.env_dir):
            print(f"❌ Error: {self.env_dir} not found")
            return []
        
        for filename in os.listdir(self.env_dir):
            if filename.endswith(".env"):
                filepath = os.path.join(self.env_dir, filename)
                with open(filepath, 'r') as f:
                    lines.extend(f.readlines())
        return lines

    def find_missing_keys(self) -> List[Tuple[str, Dict]]:
        """Find API keys that are missing or have placeholder values"""
        lines = self.load_env_files()
        defined_keys = set()
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if '=' in line:
                key, value = line.split('=', 1)
                value = value.strip()
                if value and value not in ['your_key_here', 'your_xai_api_key_here', 'your_secret_here', 'your_token_here'] and not value.startswith('your_'):
                    defined_keys.add(key)

        missing_keys = []
        for key, service_info in self.api_services.items():
            if key not in defined_keys:
                missing_keys.append((key, service_info))
        
        return missing_keys

    def open_registration_page(self, key: str, service_info: Dict) -> None:
        """Open the registration page for a service"""
        print(f"\n🌐 Opening {service_info['name']} registration page...")
        print(f"   📝 {service_info['description']}")
        print(f"   🔗 {service_info['url']}")
        
        try:
            webbrowser.open(service_info['url'])
            print(f"   ✅ Page opened in browser")
        except Exception as e:
            print(f"   ❌ Error opening page: {e}")

    def update_env_file(self, key: str, new_value: str) -> bool:
        """Append a new API key to the appropriate categorized .env file"""
        if key not in self.api_service_mapping:
            print(f"❌ Error: Unknown API key {key}. Cannot determine which file to update.")
            return False
            
        category_file = self.api_service_mapping[key]
        filepath = os.path.join(self.env_dir, category_file)
        
        try:
            with open(filepath, 'a') as f:
                f.write(f"\n{key}={new_value}\n")
            print(f"✅ Appended {key} to {filepath}")
            return True
        except Exception as e:
            print(f"❌ Error updating {filepath}: {e}")
            return False

    def interactive_setup(self) -> None:
        """Interactive setup process"""
        missing_keys = self.find_missing_keys()
        
        if not missing_keys:
            print("🎉 All API keys are configured!")
            return
        
        print(f"🔍 Found {len(missing_keys)} missing API keys:")
        print("=" * 50)
        
        for i, (key, service_info) in enumerate(missing_keys, 1):
            print(f"\n{i}. {key}")
            print(f"   Service: {service_info['name']}")
            print(f"   Description: {service_info['description']}")
        
        print(f"\n🚀 Starting interactive setup...")
        print("=" * 50)
        
        for i, (key, service_info) in enumerate(missing_keys, 1):
            print(f"\n📍 Step {i}/{len(missing_keys)}: {service_info['name']}")
            print(f"   Key: {key}")
            print(f"   Description: {service_info['description']}")
            
            self.open_registration_page(key, service_info)
            
            print(f"\n⏳ Please get your API key from the opened page...")
            print("   (The page should have opened in your browser)")
            
            while True:
                response = input(f"\n💡 Enter your {service_info['name']} API key (or 'skip' to skip, 'quit' to exit): ").strip()
                
                if response.lower() == 'quit':
                    print("👋 Setup cancelled. You can run this script again later.")
                    return
                elif response.lower() == 'skip':
                    print(f"⏭️  Skipped {service_info['name']}")
                    break
                elif response:
                    if self.update_env_file(key, response):
                        break
                    else:
                        print(f"❌ Error updating environment file. Please try again.")
                else:
                    print("❌ Please enter a valid API key or 'skip'")
            
            if i < len(missing_keys):
                continue_setup = input(f"\n🔄 Continue to next API key? (y/n): ").strip().lower()
                if continue_setup not in ['y', 'yes', '']:
                    print("👋 Setup paused. You can run this script again later.")
                    return
        
        print(f"\n🎉 Setup complete! All API keys have been processed.")
        print("💡 To apply the changes, run: source ~/.env.d/loader.sh")

    def list_missing_keys(self) -> None:
        """List all missing API keys without interactive setup"""
        missing_keys = self.find_missing_keys()
        
        if not missing_keys:
            print("🎉 All API keys are configured!")
            return
        
        print(f"🔍 Found {len(missing_keys)} missing API keys:")
        print("=" * 60)
        
        for i, (key, service_info) in enumerate(missing_keys, 1):
            print(f"\n{i}. {key}")
            print(f"   Service: {service_info['name']}")
            print(f"   Description: {service_info['description']}")
            print(f"   URL: {service_info['url']}")
        
        print(f"\n💡 Run with --interactive to set up these keys automatically:")
        print(f"   python3 {__file__} --interactive")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description='API Key Setup Assistant')
    parser.add_argument('--interactive', '-i', action='store_true', 
                       help='Start interactive setup process')
    parser.add_argument('--list', '-l', action='store_true', 
                       help='List missing API keys')
    
    args = parser.parse_args()
    
    setup = APIKeySetup()
    
    if args.list:
        setup.list_missing_keys()
    elif args.interactive:
        setup.interactive_setup()
    else:
        print("🔧 API Key Setup Assistant")
        print("=" * 30)
        print("Usage:")
        print("  python3 ~/api-key-setup.py --list        # List missing keys")
        print("  python3 ~/api-key-setup.py --interactive # Interactive setup")
        print("\n💡 This will help you set up all missing API keys in your ~/.env file")

if __name__ == "__main__":
    main()