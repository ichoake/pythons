#!/usr/bin/env python3
"""
Etsy Collection Analyzer
Analyzes and creates indexes for the Etsy design collection without moving files.
"""

import os
import json
import re
from pathlib import Path
from collections import defaultdict, Counter
import hashlib

def get_file_hash(filepath):
    """Get MD5 hash of file for duplicate detection"""
    hash_md5 = hashlib.md5()
    try:
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except (OSError, IOError, FileNotFoundError):
        return None

def analyze_file(filename, filepath):
    """Analyze individual file and return metadata"""
    file_info = {
        'filename': filename,
        'path': str(filepath),
        'size': os.path.getsize(filepath),
        'extension': Path(filename).suffix.lower(),
        'categories': [],
        'is_high_res': False,
        'is_duplicate': False
    }
    
    filename_lower = filename.lower()
    
    # Check for high resolution
    if '300dpi' in filename_lower:
        file_info['is_high_res'] = True
        file_info['categories'].append('high_resolution')
    
    # Categorize by content
    if any(word in filename_lower for word in ['christmas', 'holiday', 'santa', 'elf', 'snowman', 'reindeer']):
        file_info['categories'].append('christmas_holiday')
    
    if any(word in filename_lower for word in ['animal', 'cat', 'dog', 'pet', 'bunny', 'rabbit', 'puppy', 'kitten']):
        file_info['categories'].append('animals_pets')
    
    if any(word in filename_lower for word in ['pattern', 'seamless', 'repeat']):
        file_info['categories'].append('patterns')
    
    if any(word in filename_lower for word in ['sublimation', 'mug', 'tumbler']):
        file_info['categories'].append('sublimation')
    
    if any(word in filename_lower for word in ['tshirt', 't-shirt', 'shirt']):
        file_info['categories'].append('t_shirts')
    
    if any(word in filename_lower for word in ['bundle', 'collection']):
        file_info['categories'].append('bundles')
    
    # If no specific category found, mark as miscellaneous
    if not file_info['categories']:
        file_info['categories'].append('miscellaneous')
    
    return file_info

def analyze_directory(root_path):
    """Analyze the entire directory structure"""
    analysis = {
        'summary': {
            'total_files': 0,
            'total_directories': 0,
            'total_size': 0,
            'file_types': Counter(),
            'categories': Counter(),
            'high_res_count': 0,
            'duplicate_count': 0
        },
        'directories': {},
        'files': [],
        'duplicates': defaultdict(list),
        'project_folders': [],
        'bundle_folders': []
    }
    
    file_hashes = {}
    
    for root, dirs, files in os.walk(root_path):
        # Skip the organization folder
        if '00_Organization' in root:
            continue
            
        rel_path = os.path.relpath(root, root_path)
        
        # Analyze directories
        if rel_path != '.':
            dir_info = {
                'name': os.path.basename(root),
                'path': rel_path,
                'file_count': len(files),
                'is_project': False,
                'is_bundle': False
            }
            
            # Check if it's a project folder (has many files, not just a few)
            if len(files) > 10:
                dir_info['is_project'] = True
                analysis['project_folders'].append(dir_info)
            
            # Check if it's a bundle folder
            if any(word in root.lower() for word in ['bundle', 'collection', 'pack']):
                dir_info['is_bundle'] = True
                analysis['bundle_folders'].append(dir_info)
            
            analysis['directories'][rel_path] = dir_info
        
        # Analyze files
        for filename in files:
            if filename.startswith('.'):
                continue
                
            filepath = os.path.join(root, filename)
            file_info = analyze_file(filename, filepath)
            
            # Update summary
            analysis['summary']['total_files'] += 1
            analysis['summary']['total_size'] += file_info['size']
            analysis['summary']['file_types'][file_info['extension']] += 1
            
            for category in file_info['categories']:
                analysis['summary']['categories'][category] += 1
            
            if file_info['is_high_res']:
                analysis['summary']['high_res_count'] += 1
            
            # Check for duplicates
            file_hash = get_file_hash(filepath)
            if file_hash:
                if file_hash in file_hashes:
                    file_info['is_duplicate'] = True
                    analysis['summary']['duplicate_count'] += 1
                    analysis['duplicates'][file_hash].append(file_info)
                else:
                    file_hashes[file_hash] = file_info
            
            analysis['files'].append(file_info)
    
    analysis['summary']['total_directories'] = len(analysis['directories'])
    
    return analysis

def generate_reports(analysis, output_dir):
    """Generate various reports and indexes"""
    
    # Main analysis report
    with open(os.path.join(output_dir, 'collection_analysis.json'), 'w') as f:
        json.dump(analysis, f, indent=2)
    
    # Summary report
    summary = analysis['summary']
    report = f"""
# Etsy Collection Analysis Report

## Overview
- **Total Files:** {summary['total_files']:,}
- **Total Directories:** {summary['total_directories']:,}
- **Total Size:** {summary['total_size'] / (1024**3):.2f} GB
- **High Resolution Files:** {summary['high_res_count']:,}
- **Duplicate Files:** {summary['duplicate_count']:,}

## File Types
"""
    for ext, count in summary['file_types'].most_common():
        report += f"- {ext}: {count:,} files\n"
    
    report += "\n## Categories\n"
    for category, count in summary['categories'].most_common():
        report += f"- {category}: {count:,} files\n"
    
    report += f"\n## Project Folders ({len(analysis['project_folders'])})\n"
    for project in sorted(analysis['project_folders'], key=lambda x: x['file_count'], reverse=True)[:20]:
        report += f"- {project['name']}: {project['file_count']} files\n"
    
    report += f"\n## Bundle Folders ({len(analysis['bundle_folders'])})\n"
    for bundle in analysis['bundle_folders']:
        report += f"- {bundle['name']}: {bundle['file_count']} files\n"
    
    with open(os.path.join(output_dir, 'collection_summary.md'), 'w') as f:
        f.write(report)
    
    # Category indexes
    for category in summary['categories'].keys():
        category_files = [f for f in analysis['files'] if category in f['categories']]
        category_dir = os.path.join(output_dir, category)
        os.makedirs(category_dir, exist_ok=True)
        
        with open(os.path.join(category_dir, f'{category}_index.txt'), 'w') as f:
            f.write(f"# {category.replace('_', ' ').title()} Files\n\n")
            for file_info in sorted(category_files, key=lambda x: x['filename']):
                f.write(f"{file_info['filename']} ({file_info['size']:,} bytes)\n")
                f.write(f"  Path: {file_info['path']}\n")
                if file_info['is_high_res']:
                    f.write(f"  [HIGH RESOLUTION]\n")
                f.write("\n")
    
    # High resolution files index
    high_res_files = [f for f in analysis['files'] if f['is_high_res']]
    with open(os.path.join(output_dir, 'High_Res_Files', 'high_res_index.txt'), 'w') as f:
        f.write("# High Resolution Files (300dpi)\n\n")
        for file_info in sorted(high_res_files, key=lambda x: x['filename']):
            f.write(f"{file_info['filename']} ({file_info['size']:,} bytes)\n")
            f.write(f"  Path: {file_info['path']}\n")
            f.write(f"  Categories: {', '.join(file_info['categories'])}\n\n")
    
    # Duplicates report
    if analysis['duplicates']:
        with open(os.path.join(output_dir, 'duplicates_report.txt'), 'w') as f:
            f.write("# Duplicate Files Report\n\n")
            for hash_val, files in analysis['duplicates'].items():
                f.write(f"## Duplicate Group (Hash: {hash_val[:8]}...)\n")
                for file_info in files:
                    f.write(f"- {file_info['filename']} ({file_info['size']:,} bytes)\n")
                    f.write(f"  Path: {file_info['path']}\n")
                f.write("\n")

def main():
    root_path = "/Users/steven/Pictures/etsy"
    output_dir = "/Users/steven/Pictures/etsy/00_Organization"
    
    print("Analyzing Etsy collection...")
    analysis = analyze_directory(root_path)
    
    print("Generating reports...")
    generate_reports(analysis, output_dir)
    
    print(f"Analysis complete! Reports saved to {output_dir}")
    print(f"Found {analysis['summary']['total_files']:,} files in {analysis['summary']['total_directories']:,} directories")
    print(f"Total size: {analysis['summary']['total_size'] / (1024**3):.2f} GB")

if __name__ == "__main__":
    main()