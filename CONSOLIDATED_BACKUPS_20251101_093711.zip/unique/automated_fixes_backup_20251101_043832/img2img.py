import os
from PIL import Image


def convert_and_upscale_images(source_directory, destination_directory):
    os.makedirs(destination_directory, exist_ok=True)

    for filename in os.listdir(source_directory):
        if filename.endswith(".png"):
            source_file = os.path.join(source_directory, filename)
            filename_no_ext = os.path.splitext(filename)[0]
            destination_file = os.path.join(
                destination_directory, f"{filename_no_ext}.png"
            )

            try:
                im = Image.open(source_file)
                width, height = im.size
                upscale_width = width * 2
                upscale_height = height * 2
                im_resized = im.resize((upscale_width, upscale_height))

                # Save the image with 300 DPI
                im_resized.save(destination_file, dpi=(300, 300), format="PNG")

                # Check file size and adjust quality if necessary
                file_size = os.path.getsize(destination_file)
                if file_size > 8 * 1024 * 1024:  # 8MB in bytes
                    print(
                        f"File size of {destination_file} exceeds 8MB. Reducing quality."
                    )
                    im_resized.save(
                        destination_file, dpi=(
                            300, 300), format="PNG", quality=85)

                # Only remove the source file if everything went well
                os.remove(source_file)
                print(
                    f"Converted, upscaled, and removed: {filename} -> {filename_no_ext}.png"
                )

            except Exception as e:
                print(f"Error processing {filename}: {e}")
                continue


def main():
    source_directory = input(
        "Enter the path to the source directory containing images: "
    )

    if not os.path.isdir(source_directory):
        print("Source directory does not exist.")
        return

    destination_directory = input(
        "Enter the path for the destination directory: ")
    convert_and_upscale_images(source_directory, destination_directory)


if __name__ == "__main__":
    main()
