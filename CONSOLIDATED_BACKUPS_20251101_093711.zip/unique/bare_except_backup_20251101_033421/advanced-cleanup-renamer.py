#!/usr/bin/env python3
"""
Advanced Cleanup Renamer for ~/Documents/python
Handles duplicate target names, merges similar files, and cleans up funky numbers
"""

import ast
import os
import re
import subprocess
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
from collections import Counter, defaultdict
import difflib
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


class AdvancedCleanupRenamer:
    """Advanced cleanup renamer for handling duplicates and merging similar files"""
    
    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.duplicate_groups = []
        self.similar_files = []
        self.cleanup_suggestions = []
        
        # Patterns for funky numbers to clean up
        self.funky_patterns = [
            r'\(\d+\)',  # (1), (2), etc.
            r'\s+\d+$',  # trailing numbers
            r'_\d+_\d+',  # _1_2, _2_3, etc.
            r'_\d+$',     # trailing _1, _2, etc.
            r'-\d+$',     # trailing -1, -2, etc.
            r'\s+\d+_\d+',  # space + numbers
            r'\.\d+\.py$',  # .1.py, .2.py, etc.
        ]
        
        # File similarity threshold (50%+ similarity triggers merge)
        self.similarity_threshold = 0.5
        
    def find_duplicate_targets(self) -> Dict[str, List[Path]]:
        """Find files that would have the same target name"""
        target_map = defaultdict(list)
        
        for py_file in self.project_root.glob('*.py'):
            if py_file.name.startswith('.'):
                continue
                
            # Generate target name using simple logic
            target_name = self._generate_simple_target_name(py_file)
            if target_name:
                target_map[target_name].append(py_file)
        
        # Return only groups with multiple files
        return {k: v for k, v in target_map.items() if len(v) > 1}
    
    def _generate_simple_target_name(self, filepath: Path) -> str:
        """Generate a simple target name for a file"""
        name = filepath.stem
        
        # Remove common prefixes
        name = re.sub(r'^yt_', '', name)
        name = re.sub(r'^ig_', '', name)
        name = re.sub(r'^test_', '', name)
        name = re.sub(r'^main_', '', name)
        name = re.sub(r'^script_', '', name)
        name = re.sub(r'^temp_', '', name)
        name = re.sub(r'^new_', '', name)
        name = re.sub(r'^old_', '', name)
        
        # Clean up funky numbers
        for pattern in self.funky_patterns:
            name = re.sub(pattern, '', name)
        
        # Convert to hyphenated style
        name = re.sub(r'[_\s]+', '-', name)
        name = re.sub(r'-+', '-', name)
        name = name.strip('-')
        
        # Add .py extension
        return f"{name}.py" if name else None
    
    def find_similar_files(self, similarity_threshold: float = 0.5) -> List[List[Path]]:
        """Find files that are more than 50% similar"""
        python_files = list(self.project_root.glob('*.py'))
        similar_groups = []
        processed = set()
        
        for i, file1 in enumerate(python_files):
            if file1 in processed or file1.name.startswith('.'):
                continue
                
            similar_group = [file1]
            processed.add(file1)
            
            for j, file2 in enumerate(python_files[i+1:], i+1):
                if file2 in processed or file2.name.startswith('.'):
                    continue
                
                similarity = self._calculate_file_similarity(file1, file2)
                if similarity >= similarity_threshold:
                    similar_group.append(file2)
                    processed.add(file2)
            
            if len(similar_group) > 1:
                similar_groups.append(similar_group)
        
        return similar_groups
    
    def _calculate_file_similarity(self, file1: Path, file2: Path) -> float:
        """Calculate similarity between two files"""
        try:
            # Read file contents
            content1 = file1.read_text(encoding='utf-8', errors='ignore')
            content2 = file2.read_text(encoding='utf-8', errors='ignore')
            
            # Calculate similarity using difflib
            similarity = difflib.SequenceMatcher(None, content1, content2).ratio()
            
            # Also check filename similarity
            name_similarity = difflib.SequenceMatcher(None, file1.name, file2.name).ratio()
            
            # Weighted average (content 70%, filename 30%)
            return similarity * 0.7 + name_similarity * 0.3
            
        except Exception as e:
            logger.error(f"Error calculating similarity between {file1} and {file2}: {e}")
            return 0.0
    
    def analyze_file_content(self, filepath: Path) -> Dict:
        """Analyze file content to understand its purpose"""
        try:
            content = filepath.read_text(encoding='utf-8', errors='ignore')
            
            analysis = {
                'imports': [],
                'functions': [],
                'classes': [],
                'docstring': None,
                'keywords': [],
                'file_operations': [],
                'api_services': [],
                'size': len(content),
                'lines': len(content.splitlines())
            }
            
            # Parse AST
            try:
                tree = ast.parse(content)
                
                # Get docstring
                if (tree.body and isinstance(tree.body[0], ast.Expr) and
                    isinstance(tree.body[0].value, ast.Constant)):
                    analysis['docstring'] = tree.body[0].value.value
                
                # Get imports and functions
                for node in ast.walk(tree):
                    if isinstance(node, ast.Import):
                        for alias in node.names:
                            analysis['imports'].append(alias.name)
                    elif isinstance(node, ast.ImportFrom):
                        if node.module:
                            analysis['imports'].append(node.module)
                    elif isinstance(node, ast.FunctionDef):
                        analysis['functions'].append(node.name)
                    elif isinstance(node, ast.ClassDef):
                        analysis['classes'].append(node.name)
            except:
                pass
            
            # Extract keywords from content
            keywords = re.findall(r'\b[a-z_]{3,}\b', content.lower())
            keyword_counts = Counter(keywords)
            analysis['keywords'] = [k for k, v in keyword_counts.most_common(20)]
            
            # Detect file operations
            analysis['file_operations'] = self._detect_file_operations(content)
            
            # Detect API services
            analysis['api_services'] = self._detect_api_services(content)
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing {filepath}: {e}")
            return {}
    
    def _detect_file_operations(self, content: str) -> List[str]:
        """Detect file operations from content"""
        ops = []
        content_lower = content.lower()
        
        if 'open(' in content_lower and 'read' in content_lower:
            ops.append('read')
        if 'open(' in content_lower and 'write' in content_lower:
            ops.append('write')
        if 'os.rename' in content_lower or 'rename' in content_lower:
            ops.append('rename')
        if 'os.remove' in content_lower or 'delete' in content_lower:
            ops.append('delete')
        if 'shutil.copy' in content_lower or 'copy' in content_lower:
            ops.append('copy')
        if 'move' in content_lower:
            ops.append('move')
        
        return ops
    
    def _detect_api_services(self, content: str) -> List[str]:
        """Detect API services from content"""
        services = []
        content_lower = content.lower()
        
        if 'openai' in content_lower or 'whisper' in content_lower:
            services.append('openai')
        if 'youtube' in content_lower or 'yt-dlp' in content_lower:
            services.append('youtube')
        if 'instagram' in content_lower or 'instabot' in content_lower:
            services.append('instagram')
        if 'requests' in content_lower:
            services.append('requests')
        if 'pandas' in content_lower:
            services.append('pandas')
        if 'pillow' in content_lower or 'pil' in content_lower:
            services.append('pillow')
        
        return services
    
    def merge_similar_files(self, file_group: List[Path]) -> Dict:
        """Merge similar files into one comprehensive file"""
        if len(file_group) < 2:
            return {}
        
        # Find the best file to keep (largest, most complete)
        best_file = max(file_group, key=lambda f: f.stat().st_size)
        other_files = [f for f in file_group if f != best_file]
        
        # Analyze all files
        analyses = {f: self.analyze_file_content(f) for f in file_group}
        
        # Create merged content
        merged_content = self._create_merged_content(file_group, analyses)
        
        # Create backup directory
        backup_dir = self.project_root / 'merged_backups'
        backup_dir.mkdir(exist_ok=True)
        
        # Move other files to backup
        for file_path in other_files:
            backup_path = backup_dir / file_path.name
            if file_path.exists():
                shutil.move(str(file_path), str(backup_path))
                logger.info(f"📦 Moved {file_path.name} to backup")
        
        # Update the best file with merged content
        best_file.write_text(merged_content, encoding='utf-8')
        
        return {
            'kept_file': best_file,
            'merged_files': other_files,
            'backup_dir': backup_dir
        }
    
    def _create_merged_content(self, file_group: List[Path], analyses: Dict) -> str:
        """Create merged content from similar files"""
        # Start with the largest file
        best_file = max(file_group, key=lambda f: f.stat().st_size)
        base_content = best_file.read_text(encoding='utf-8', errors='ignore')
        
        # Add unique functions/classes from other files
        merged_lines = base_content.splitlines()
        
        for file_path in file_group:
            if file_path == best_file:
                continue
                
            try:
                content = file_path.read_text(encoding='utf-8', errors='ignore')
                tree = ast.parse(content)
                
                # Extract unique functions and classes
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                        # Check if this function/class exists in base content
                        if node.name not in base_content:
                            # Add the function/class
                            start_line = node.lineno - 1
                            end_line = node.end_lineno
                            function_lines = content.splitlines()[start_line:end_line]
                            
                            # Add with proper indentation
                            merged_lines.append("")
                            merged_lines.append(f"# From {file_path.name}")
                            merged_lines.extend(function_lines)
                            
            except Exception as e:
                logger.error(f"Error processing {file_path} for merge: {e}")
        
        return '\n'.join(merged_lines)
    
    def cleanup_funky_names(self) -> List[Dict]:
        """Clean up files with funky random numbers in names"""
        cleanup_suggestions = []
        
        for py_file in self.project_root.glob('*.py'):
            if py_file.name.startswith('.'):
                continue
            
            original_name = py_file.name
            clean_name = self._clean_filename(original_name)
            
            if clean_name != original_name:
                cleanup_suggestions.append({
                    'current_path': str(py_file),
                    'current_name': original_name,
                    'suggested_name': clean_name,
                    'reason': 'Cleaned up funky numbers and patterns'
                })
        
        return cleanup_suggestions
    
    def _clean_filename(self, filename: str) -> str:
        """Clean up a filename by removing funky patterns"""
        name, ext = os.path.splitext(filename)
        
        # Remove funky patterns
        for pattern in self.funky_patterns:
            name = re.sub(pattern, '', name)
        
        # Clean up multiple spaces and underscores
        name = re.sub(r'[_\s]+', '-', name)
        name = re.sub(r'-+', '-', name)
        name = name.strip('-')
        
        # Remove trailing numbers if they look random
        name = re.sub(r'-\d+$', '', name)
        name = re.sub(r'_\d+$', '', name)
        
        return f"{name}{ext}" if name else filename
    
    def run_advanced_cleanup(self) -> Dict:
        """Run the complete advanced cleanup process"""
        logger.info("🧹 Starting Advanced Cleanup Process...")
        logger.info("=" * 60)
        
        results = {
            'duplicate_targets': {},
            'similar_files': [],
            'cleanup_suggestions': [],
            'merged_files': [],
            'backup_dir': None
        }
        
        # 1. Find and handle duplicate targets
        logger.info("🔍 Step 1: Finding duplicate target names...")
        duplicate_targets = self.find_duplicate_targets()
        results['duplicate_targets'] = duplicate_targets
        
        if duplicate_targets:
            logger.info(f"📊 Found {len(duplicate_targets)} groups of duplicate targets")
            for target, files in duplicate_targets.items():
                logger.info(f"   {target}: {len(files)} files")
        else:
            logger.info("✅ No duplicate targets found")
        
        # 2. Find and merge similar files
        logger.info("\n🔍 Step 2: Finding similar files (>50% similarity)...")
        similar_groups = self.find_similar_files(self.similarity_threshold)
        results['similar_files'] = similar_groups
        
        if similar_groups:
            logger.info(f"📊 Found {len(similar_groups)} groups of similar files")
            for group in similar_groups:
                logger.info(f"   Group: {[f.name for f in group]}")
        else:
            logger.info("✅ No similar files found")
        
        # 3. Clean up funky names
        logger.info("\n🔍 Step 3: Cleaning up funky filenames...")
        cleanup_suggestions = self.cleanup_funky_names()
        results['cleanup_suggestions'] = cleanup_suggestions
        
        if cleanup_suggestions:
            logger.info(f"📊 Found {len(cleanup_suggestions)} files with funky names")
        else:
            logger.info("✅ No funky names found")
        
        return results
    
    def apply_cleanup(self, results: Dict, auto_approve: bool = False):
        """Apply the cleanup suggestions"""
        if not auto_approve:
            logger.info("\n📝 Cleanup Summary:")
            logger.info("-" * 40)
            
            # Show duplicate targets
            if results['duplicate_targets']:
                logger.info(f"\n🔄 Duplicate Targets ({len(results['duplicate_targets'])} groups):")
                for target, files in results['duplicate_targets'].items():
                    logger.info(f"   {target}:")
                    for f in files:
                        logger.info(f"     - {f.name}")
            
            # Show similar files
            if results['similar_files']:
                logger.info(f"\n🔗 Similar Files ({len(results['similar_files'])} groups):")
                for group in results['similar_files']:
                    logger.info(f"   Group: {[f.name for f in group]}")
            
            # Show cleanup suggestions
            if results['cleanup_suggestions']:
                logger.info(f"\n🧹 Funky Names ({len(results['cleanup_suggestions'])} files):")
                for suggestion in results['cleanup_suggestions'][:10]:  # Show first 10
                    logger.info(f"   {suggestion['current_name']} → {suggestion['suggested_name']}")
                if len(results['cleanup_suggestions']) > 10:
                    logger.info(f"   ... and {len(results['cleanup_suggestions']) - 10} more")
            
            return
        
        # Apply cleanup
        logger.info("\n🔄 Applying cleanup...")
        
        # Apply funky name cleanup
        for suggestion in results['cleanup_suggestions']:
            try:
                current_path = Path(suggestion['current_path'])
                new_path = current_path.parent / suggestion['suggested_name']
                
                # Check if git tracked
                result = subprocess.run(
                    ['git', 'ls-files', '--error-unmatch', str(current_path)],
                    capture_output=True
                )
                is_tracked = result.returncode == 0
                
                if is_tracked:
                    subprocess.run(['git', 'mv', str(current_path), str(new_path)], check=True)
                    logger.info(f"✅ Renamed {current_path.name} → {new_path.name} (git tracked)")
                else:
                    current_path.rename(new_path)
                    logger.info(f"✅ Renamed {current_path.name} → {new_path.name}")
                    
            except Exception as e:
                logger.error(f"❌ Error renaming {suggestion['current_name']}: {e}")
        
        # Merge similar files
        for group in results['similar_files']:
            try:
                merge_result = self.merge_similar_files(group)
                if merge_result:
                    logger.info(f"✅ Merged {len(group)} similar files, kept {merge_result['kept_file'].name}")
                    results['merged_files'].append(merge_result)
            except Exception as e:
                logger.error(f"❌ Error merging files {[f.name for f in group]}: {e}")
        
        logger.info(f"\n🎉 Cleanup complete! Check merged_backups/ for moved files.")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Advanced Cleanup Renamer for ~/Documents/python'
    )
    parser.add_argument(
        'path',
        type=Path,
        nargs='?',
        default=Path.home() / 'Documents' / 'python',
        help='Python directory to clean up (default: ~/Documents/python)'
    )
    parser.add_argument(
        '--apply',
        action='store_true',
        help='Actually apply the cleanup (default: dry-run only)'
    )
    parser.add_argument(
        '--similarity',
        type=float,
        default=0.5,
        help='Similarity threshold for merging files (default: 0.5)'
    )
    
    args = parser.parse_args()
    
    renamer = AdvancedCleanupRenamer(args.path)
    renamer.similarity_threshold = args.similarity
    
    results = renamer.run_advanced_cleanup()
    renamer.apply_cleanup(results, auto_approve=args.apply)


if __name__ == '__main__':
    main()