#!/usr/bin/env python3
"""
Reorganize to Exact Structure
Sort all content into the exact category structure with proper subcategories
"""

import ast
import shutil
from pathlib import Path
from collections import defaultdict

class ExactStructureReorganizer:
    """Reorganize to exact structure with specific subcategories"""

    def __init__(self, base_dir: Path):
        self.base_dir = base_dir
        self.moves = []

        # Define exact target structure
        self.structure = {
            'AUTOMATION_BOTS': {
                'weight': 0.35,
                'subcategories': {
                    'social_media_automation': ['instagram', 'reddit', 'twitter', 'telegram', 'whatsapp', 'facebook'],
                    'youtube_reddit_content': ['youtube', 'reddit', 'video_generator', 'content_maker'],
                    'bot_frameworks': ['botty', 'selenium', 'playwright', 'automation_framework'],
                    'scrapers': ['scraper', 'scrape', 'crawler', 'extract', 'fetch']
                }
            },
            'MEDIA_PROCESSING': {
                'weight': 0.25,
                'subcategories': {
                    'audio_video_conversion': ['converter', 'ffmpeg', 'moviepy', 'transcode', 'encode'],
                    'image_upscaling': ['upscale', 'enhance', 'super_resolution', 'enlarge'],
                    'gallery_generation': ['gallery', 'album', 'slideshow', 'portfolio'],
                    'tts_generation': ['text_to_speech', 'tts', 'voice', 'speech_synthesis']
                }
            },
            'AI_CONTENT': {
                'weight': 0.20,
                'subcategories': {
                    'tts_engines': ['tts', 'text_to_speech', 'voice_synthesis', 'speech'],
                    'image_generation': ['image_gen', 'stable_diffusion', 'dalle', 'midjourney', 'ai_art'],
                    'prompt_engineering': ['prompt', 'prompt_pipeline', 'prompt_optimization'],
                    'content_creation': ['content_gen', 'article', 'blog', 'writer', 'generator']
                }
            },
            'DATA_UTILITIES': {
                'weight': 0.15,
                'subcategories': {
                    'file_organization': ['organizer', 'organize', 'sort', 'categorize', 'cleanup'],
                    'csv_processing': ['csv', 'excel', 'spreadsheet', 'data_processor'],
                    'data_analysis': ['analyze', 'analytics', 'statistics', 'metrics'],
                    'scrapers': ['download', 'fetch', 'retrieve', 'web_scraper']
                }
            },
            'documentation': {
                'weight': 0.05,
                'subcategories': {
                    'code_browsers': ['browser', 'viewer', 'explorer', 'navigator'],
                    'tutorials': ['tutorial', 'guide', 'how_to', 'example'],
                    'references': ['reference', 'docs', 'documentation', 'wiki']
                }
            }
        }

    def analyze_file_content(self, file_path: Path) -> dict:
        """Analyze file content for categorization"""
        try:
            content = file_path.read_text(encoding='utf-8', errors='ignore')
        except:
            return {'keywords': set(), 'imports': set()}

        content_lower = content.lower()
        keywords = set()
        imports = set()

        # Extract imports
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.add(alias.name.split('.')[0])
                elif isinstance(node, ast.ImportFrom):
                    if node.module:
                        imports.add(node.module.split('.')[0])
        except:
            pass

        # Detect keywords from all subcategories
        for category, cat_data in self.structure.items():
            for subcat, keywords_list in cat_data['subcategories'].items():
                for keyword in keywords_list:
                    if keyword.replace('_', '').replace('-', '') in content_lower.replace('_', '').replace('-', ''):
                        keywords.add(keyword)

        return {'keywords': keywords, 'imports': imports}

    def categorize_item(self, item_path: Path) -> tuple:
        """Determine best category and subcategory for item"""

        # Analyze all Python files in item
        keyword_counts = defaultdict(lambda: defaultdict(int))

        if item_path.is_file() and item_path.suffix == '.py':
            analysis = self.analyze_file_content(item_path)
            # Count keyword matches for each category/subcategory
            for category, cat_data in self.structure.items():
                for subcat, keywords_list in cat_data['subcategories'].items():
                    for keyword in keywords_list:
                        if keyword in analysis['keywords'] or keyword in analysis['imports']:
                            keyword_counts[category][subcat] += 1

        elif item_path.is_dir():
            for py_file in item_path.rglob('*.py'):
                if '__pycache__' in str(py_file):
                    continue
                analysis = self.analyze_file_content(py_file)
                for category, cat_data in self.structure.items():
                    for subcat, keywords_list in cat_data['subcategories'].items():
                        for keyword in keywords_list:
                            if keyword in analysis['keywords'] or keyword in analysis['imports']:
                                keyword_counts[category][subcat] += 1

        # Find best match
        best_category = None
        best_subcat = None
        best_score = 0

        for category in keyword_counts:
            for subcat, score in keyword_counts[category].items():
                if score > best_score:
                    best_score = score
                    best_category = category
                    best_subcat = subcat

        # Fallback based on directory name
        if not best_category:
            item_name = item_path.name.lower()
            for category, cat_data in self.structure.items():
                for subcat, keywords_list in cat_data['subcategories'].items():
                    for keyword in keywords_list:
                        if keyword.replace('_', '') in item_name.replace('_', '').replace('-', ''):
                            return (category, subcat, 5)

            # Default to DATA_UTILITIES
            return ('DATA_UTILITIES', 'file_organization', 0)

        return (best_category, best_subcat, best_score)

    def scan_and_categorize(self):
        """Scan all content and build reorganization plan"""

        print("=" * 70)
        print("🔍 SCANNING FOR EXACT STRUCTURE REORGANIZATION")
        print("=" * 70)
        print()

        # Get all top-level items in main categories
        for category_dir in ['AI_CONTENT', 'AUTOMATION_BOTS', 'DATA_UTILITIES', 'MEDIA_PROCESSING', 'documentation']:
            cat_path = self.base_dir / category_dir
            if not cat_path.exists():
                continue

            # Process each item in category
            for item in cat_path.iterdir():
                if item.name.startswith('.') or item.name == '__pycache__':
                    continue

                # Determine correct categorization
                target_category, target_subcat, score = self.categorize_item(item)

                # Build target path
                target_path = self.base_dir / target_category / target_subcat / item.name

                # Skip if already in correct location
                if item.parent.parent == self.base_dir / target_category and item.parent.name == target_subcat:
                    continue

                self.moves.append({
                    'source': item,
                    'target': target_path,
                    'current_category': category_dir,
                    'target_category': target_category,
                    'target_subcat': target_subcat,
                    'score': score
                })

        print(f"📊 Found {len(self.moves)} items to reorganize")
        print()

    def execute(self, dry_run=True):
        """Execute reorganization"""

        self.scan_and_categorize()

        if not self.moves:
            print("✅ Structure already matches exact specification!")
            return

        print("=" * 70)
        print(f"📝 EXACT STRUCTURE REORGANIZATION {'(DRY RUN)' if dry_run else '(LIVE)'}")
        print("=" * 70)
        print()

        # Group by target category
        by_category = defaultdict(list)
        for move in self.moves:
            by_category[move['target_category']].append(move)

        moved_count = 0
        error_count = 0

        for category in sorted(by_category.keys()):
            items = by_category[category]
            print(f"📂 {category}/ ({len(items)} items)")

            # Group by subcategory
            by_subcat = defaultdict(list)
            for item in items:
                by_subcat[item['target_subcat']].append(item)

            for subcat in sorted(by_subcat.keys()):
                subcat_items = by_subcat[subcat]
                print(f"   └─ {subcat}/ ({len(subcat_items)} items)")

                for move in subcat_items[:5]:  # Show first 5
                    rel_source = move['source'].relative_to(self.base_dir)

                    if dry_run:
                        print(f"      [DRY RUN] {move['source'].name}")
                    else:
                        # Create target directory
                        move['target'].parent.mkdir(parents=True, exist_ok=True)

                        # Handle conflicts
                        target = move['target']
                        if target.exists():
                            from datetime import datetime
                            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                            if move['source'].is_file():
                                new_name = f"{move['source'].stem}_{timestamp}{move['source'].suffix}"
                            else:
                                new_name = f"{move['source'].name}_{timestamp}"
                            target = target.parent / new_name

                        try:
                            shutil.move(str(move['source']), str(target))
                            print(f"      ✅ {move['source'].name}")
                            moved_count += 1
                        except Exception as e:
                            print(f"      ❌ {move['source'].name} - ERROR")
                            error_count += 1

                if len(subcat_items) > 5:
                    print(f"      ... and {len(subcat_items) - 5} more")

            print()

        print("=" * 70)
        print(f"{'Simulation' if dry_run else 'Execution'} complete!")
        if not dry_run:
            print(f"   Moved: {moved_count}")
            print(f"   Errors: {error_count}")
        print("=" * 70)

        if not dry_run:
            print()
            print("✨ Exact structure achieved!")
            print()
            print("📊 Final structure:")
            print("   ├── AUTOMATION_BOTS/ (35%)")
            print("   │   ├── social_media_automation/")
            print("   │   ├── youtube_reddit_content/")
            print("   │   ├── bot_frameworks/")
            print("   │   └── scrapers/")
            print("   ├── MEDIA_PROCESSING/ (25%)")
            print("   │   ├── audio_video_conversion/")
            print("   │   ├── image_upscaling/")
            print("   │   ├── gallery_generation/")
            print("   │   └── tts_generation/")
            print("   ├── AI_CONTENT/ (20%)")
            print("   │   ├── tts_engines/")
            print("   │   ├── image_generation/")
            print("   │   ├── prompt_engineering/")
            print("   │   └── content_creation/")
            print("   ├── DATA_UTILITIES/ (15%)")
            print("   │   ├── file_organization/")
            print("   │   ├── csv_processing/")
            print("   │   ├── data_analysis/")
            print("   │   └── scrapers/")
            print("   └── documentation/ (5%)")
            print("       ├── code_browsers/")
            print("       ├── tutorials/")
            print("       └── references/")

        if dry_run:
            print("\n💡 To execute, run:")
            print("   python3 reorganize_to_exact_structure.py --execute")

def main():
    import sys

    base_dir = Path("/Users/steven/Documents/python")
    dry_run = '--execute' not in sys.argv

    reorganizer = ExactStructureReorganizer(base_dir)
    reorganizer.execute(dry_run=dry_run)

if __name__ == '__main__':
    main()
