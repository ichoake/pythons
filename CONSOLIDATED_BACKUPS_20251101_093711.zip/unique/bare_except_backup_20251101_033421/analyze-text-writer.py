#!/usr/bin/env python3
"""
Quick analysis and merge strategy for 2T-Xx and DeVonDaTa drives
"""

import os
import subprocess
import csv
from datetime import datetime

def run_command(cmd):
    """Run command and return output"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return result.stdout.strip()
    except:
        return ""

def analyze_drive_structure(drive_path, drive_name):
    """Analyze drive structure and create summary"""
    print(f"\n=== Analyzing {drive_name} ===")
    
    # Get total size
    size_cmd = f'du -sh "{drive_path}" 2>/dev/null'
    total_size = run_command(size_cmd)
    print(f"Total size: {total_size}")
    
    # Count files by type
    file_types = {
        'ZIP': f'find "{drive_path}" -name "*.zip" -type f | wc -l',
        'MP4': f'find "{drive_path}" -name "*.mp4" -type f | wc -l',
        'Images': f'find "{drive_path}" \\( -name "*.jpg" -o -name "*.jpeg" -o -name "*.png" -o -name "*.gif" \\) -type f | wc -l',
        'PDF': f'find "{drive_path}" -name "*.pdf" -type f | wc -l',
        'Audio': f'find "{drive_path}" \\( -name "*.mp3" -o -name "*.wav" -o -name "*.flac" \\) -type f | wc -l',
        'PSD': f'find "{drive_path}" -name "*.psd" -type f | wc -l'
    }
    
    counts = {}
    for file_type, cmd in file_types.items():
        count = run_command(cmd)
        counts[file_type] = count if count.isdigit() else "0"
        print(f"{file_type}: {counts[file_type]} files")
    
    # Get largest directories
    dirs_cmd = f'du -sh "{drive_path}"/* 2>/dev/null | sort -hr | head -10'
    largest_dirs = run_command(dirs_cmd)
    print(f"\nLargest directories:\n{largest_dirs}")
    
    return {
        'total_size': total_size,
        'file_counts': counts,
        'largest_dirs': largest_dirs
    }

def find_common_files():
    """Find files that exist on both drives"""
    print("\n=== Finding Common Files ===")
    
    # Get file lists
    cmd1 = 'find "/Volumes/2T-Xx" -type f -name "*.zip" -exec basename {} \\; | sort'
    cmd2 = 'find "/Volumes/DeVonDaTa" -type f -name "*.zip" -exec basename {} \\; | sort'
    
    files1 = set(run_command(cmd1).split('\n')) if run_command(cmd1) else set()
    files2 = set(run_command(cmd2).split('\n')) if run_command(cmd2) else set()
    
    common_files = files1.intersection(files2)
    print(f"Common ZIP files: {len(common_files)}")
    
    if common_files:
        print("Common files:")
        for file in sorted(list(common_files)[:10]):
            print(f"  {file}")
        if len(common_files) > 10:
            print(f"  ... and {len(common_files) - 10} more")
    
    return common_files

def create_merge_plan():
    """Create merge plan based on analysis"""
    print("\n=== MERGE STRATEGY ===")
    
    # Analyze both drives
    drive1_analysis = analyze_drive_structure("/Volumes/2T-Xx", "2T-Xx")
    drive2_analysis = analyze_drive_structure("/Volumes/DeVonDaTa", "DeVonDaTa")
    
    # Find common files
    common_files = find_common_files()
    
    # Create merge plan
    merge_plan = []
    
    print("\n=== RECOMMENDED MERGE ACTIONS ===")
    
    # 1. Use 2T-Xx as primary (larger, more content)
    print("1. Use 2T-Xx as PRIMARY drive (386GB vs 54GB)")
    
    # 2. Move unique content from DeVonDaTa to 2T-Xx
    print("2. Move unique content from DeVonDaTa to 2T-Xx")
    
    # 3. Handle duplicates
    if common_files:
        print(f"3. Found {len(common_files)} duplicate files - keep versions from 2T-Xx")
    
    # 4. Organize by content type
    print("4. Organize content by type:")
    print("   - Music: /Volumes/2T-Xx/Organized/Music/")
    print("   - Videos: /Volumes/2T-Xx/Organized/Videos/")
    print("   - Images: /Volumes/2T-Xx/Organized/Images/")
    print("   - Archives: /Volumes/2T-Xx/Organized/Archives/")
    print("   - Documents: /Volumes/2T-Xx/Organized/Documents/")
    
    # Save plan to CSV
    with open("/Volumes/DeVonDaTa/merge_plan.csv", "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Action', 'Source', 'Destination', 'Reason'])
        writer.writerow(['PRIMARY', '2T-Xx', 'Keep as primary', 'Larger drive with more content'])
        writer.writerow(['MOVE_UNIQUE', 'DeVonDaTa', '2T-Xx/Organized/', 'Consolidate unique content'])
        writer.writerow(['HANDLE_DUPLICATES', 'Both', 'Keep 2T-Xx versions', f'{len(common_files)} duplicate files found'])
        writer.writerow(['ORGANIZE', '2T-Xx', 'Create organized structure', 'Better file organization'])
    
    print(f"\nMerge plan saved to: /Volumes/DeVonDaTa/merge_plan.csv")
    
    return merge_plan

def main():
    print("=== DRIVE MERGE ANALYSIS ===")
    print(f"Analysis started at: {datetime.now()}")
    
    # Check if drives are accessible
    if not os.path.exists("/Volumes/2T-Xx"):
        print("ERROR: 2T-Xx drive not accessible")
        return
    
    if not os.path.exists("/Volumes/DeVonDaTa"):
        print("ERROR: DeVonDaTa drive not accessible")
        return
    
    # Create merge plan
    merge_plan = create_merge_plan()
    
    print(f"\nAnalysis completed at: {datetime.now()}")
    print("\nNext steps:")
    print("1. Review the merge plan")
    print("2. Execute the merge operations")
    print("3. Verify results")

if __name__ == "__main__":
    main()