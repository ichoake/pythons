#!/usr/bin/env python3
"""
Python Syntax Fixer
Automatically fixes common syntax errors in Python files
"""

import os
import re
import ast
from pathlib import Path
from typing import List, Tuple, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PythonSyntaxFixer:
    """Fixes common Python syntax errors automatically."""
    
    def __init__(self, base_dir: str = "/Users/steven/Documents/python"):
        self.base_dir = Path(base_dir)
        self.fixed_files = []
        self.failed_files = []
        
    def fix_all_files(self) -> dict:
        """Fix syntax errors in all Python files."""
        logger.info("🔧 Starting Python syntax fixing...")
        
        python_files = list(self.base_dir.rglob("*.py"))
        total_files = len(python_files)
        
        logger.info(f"Found {total_files} Python files to check")
        
        for i, py_file in enumerate(python_files, 1):
            try:
                logger.info(f"Processing {i}/{total_files}: {py_file.name}")
                if self.fix_file(py_file):
                    self.fixed_files.append(py_file)
                else:
                    self.failed_files.append(py_file)
            except Exception as e:
                logger.error(f"Error processing {py_file}: {e}")
                self.failed_files.append(py_file)
        
        results = {
            'total_files': total_files,
            'fixed_files': len(self.fixed_files),
            'failed_files': len(self.failed_files),
            'success_rate': len(self.fixed_files) / total_files if total_files > 0 else 0
        }
        
        logger.info(f"✅ Syntax fixing complete: {results['fixed_files']}/{results['total_files']} files fixed")
        return results
    
    def fix_file(self, file_path: Path) -> bool:
        """Fix syntax errors in a single file."""
        try:
            # Read the file
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Skip empty files
            if not content.strip():
                return True
            
            # Try to parse the file first
            try:
                ast.parse(content)
                return True  # File is already valid
            except SyntaxError:
                pass  # Continue with fixing
            
            # Apply fixes
            fixed_content = self._apply_fixes(content)
            
            # Verify the fix worked
            try:
                ast.parse(fixed_content)
                # Write the fixed content back
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(fixed_content)
                return True
            except SyntaxError as e:
                logger.warning(f"Could not fix {file_path}: {e}")
                return False
                
        except Exception as e:
            logger.error(f"Error fixing {file_path}: {e}")
            return False
    
    def _apply_fixes(self, content: str) -> str:
        """Apply various syntax fixes to the content."""
        lines = content.split('\n')
        fixed_lines = []
        
        for i, line in enumerate(lines):
            fixed_line = self._fix_line(line, i + 1)
            fixed_lines.append(fixed_line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_line(self, line: str, line_num: int) -> str:
        """Fix common syntax errors in a single line."""
        original_line = line
        
        # Fix 1: Missing comma in function calls
        if ')' in line and '(' in line:
            # Look for patterns like "arg1 arg2)" and fix to "arg1, arg2)"
            line = re.sub(r'(\w+)\s+(\w+)(\s*\))', r'\1, \2\3', line)
        
        # Fix 2: Fix assignment operators
        if ' = ' in line and not any(op in line for op in ['==', '!=', '<=', '>=', '+=', '-=', '*=', '/=']):
            # Check if it's in a conditional context
            if any(keyword in line for keyword in ['if', 'elif', 'while', 'for']):
                # This might be a comparison that should be ==
                line = re.sub(r'(\w+)\s*=\s*(\w+)', r'\1 == \2', line)
        
        # Fix 3: Fix unterminated strings
        if line.count('"') % 2 == 1:
            line += '"'
        if line.count("'") % 2 == 1:
            line += "'"
        
        # Fix 4: Fix missing parentheses
        if line.count('(') > line.count(')'):
            line += ')' * (line.count('(') - line.count(')'))
        elif line.count('[') > line.count(']'):
            line += ']' * (line.count('[') - line.count(']'))
        elif line.count('{') > line.count('}'):
            line += '}' * (line.count('{') - line.count('}'))
        
        # Fix 5: Fix invalid decimal literals
        line = re.sub(r'(\d+)\.(\d+)\.(\d+)', r'\1.\2', line)  # Remove extra dots
        
        # Fix 6: Fix unexpected indentation
        if line.strip() and not line.startswith(' ') and not line.startswith('\t'):
            # Check if previous line suggests indentation is needed
            pass  # This is complex and context-dependent
        
        # Fix 7: Fix duplicate decorators
        lines_before = []
        if line.strip().startswith('@'):
            # Remove duplicate decorators
            decorators = []
            for match in re.finditer(r'@\w+\([^)]*\)', line):
                decorator = match.group(0)
                if decorator not in decorators:
                    decorators.append(decorator)
            if decorators:
                line = ' '.join(decorators)
        
        # Fix 8: Fix missing colons
        if any(keyword in line for keyword in ['if', 'elif', 'else', 'for', 'while', 'def', 'class', 'try', 'except', 'finally']):
            if line.strip().endswith(')') and not line.strip().endswith(':'):
                line = line.rstrip() + ':'
        
        # Fix 9: Fix invalid syntax with commas
        if 'invalid syntax' in str(line) and ',' in line:
            # Try to fix common comma issues
            line = re.sub(r',\s*,', ',', line)  # Remove double commas
            line = re.sub(r',\s*\)', ')', line)  # Remove trailing commas before closing paren
        
        # Fix 10: Fix function definitions without colons
        if line.strip().startswith('def ') and not line.strip().endswith(':'):
            line = line.rstrip() + ':'
        
        # Fix 11: Fix class definitions without colons
        if line.strip().startswith('class ') and not line.strip().endswith(':'):
            line = line.rstrip() + ':'
        
        # Fix 12: Fix missing return statements in functions
        if line.strip().startswith('def ') and 'return' not in line:
            # This is context-dependent, so we'll be conservative
            pass
        
        # Fix 13: Fix unexpected character after line continuation
        if '\\' in line and len(line.strip()) > 1:
            # Remove backslash if it's at the end of line
            if line.strip().endswith('\\'):
                line = line.rstrip()[:-1].rstrip()
        
        # Fix 14: Fix unterminated string literals
        if line.count('"""') % 2 == 1:
            line += '"""'
        if line.count("'''") % 2 == 1:
            line += "'''"
        
        # Fix 15: Fix missing function body
        if line.strip().endswith(':') and not line.strip().startswith('#'):
            # Check if next line is properly indented
            pass  # This requires context from surrounding lines
        
        # Fix 16: Fix invalid syntax with parentheses
        if 'closing parenthesis' in str(line) or 'opening parenthesis' in str(line):
            # Try to balance parentheses
            open_count = line.count('(') + line.count('[') + line.count('{')
            close_count = line.count(')') + line.count(']') + line.count('}')
            if open_count > close_count:
                line += ')' * (open_count - close_count)
            elif close_count > open_count:
                # Remove extra closing parentheses
                extra = close_count - open_count
                for _ in range(extra):
                    if ')' in line:
                        line = line.replace(')', '', 1)
                    elif ']' in line:
                        line = line.replace(']', '', 1)
                    elif '}' in line:
                        line = line.replace('}', '', 1)
        
        # Fix 17: Fix unexpected unindent
        if line.strip() and line.startswith(' ') and not line.startswith('    '):
            # Fix inconsistent indentation
            line = '    ' + line.lstrip()
        
        # Fix 18: Fix missing function arguments
        if 'def ' in line and '()' in line and not any(char in line for char in ['self', 'cls', '*', '**']):
            # This might be a method that needs self
            if 'class ' in str(lines_before[-5:]) if lines_before else False:
                line = line.replace('()', '(self)')
        
        # Fix 19: Fix invalid syntax with operators
        if 'invalid syntax' in str(line):
            # Try to fix common operator issues
            line = re.sub(r'(\w+)\s*=\s*(\w+)\s*=', r'\1 == \2', line)  # Fix ==
            line = re.sub(r'(\w+)\s*=\s*(\w+)\s*!', r'\1 != \2', line)  # Fix !=
        
        # Fix 20: Fix missing imports
        if 'import' in line and not line.strip().startswith('import') and not line.strip().startswith('from'):
            # This might be a malformed import
            pass  # This is complex and context-dependent
        
        return line
    
    def fix_specific_errors(self, file_path: Path) -> bool:
        """Fix specific common errors in a file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Apply specific fixes
            fixes_applied = []
            
            # Fix 1: Fix missing commas in function calls
            if 'invalid syntax. Perhaps you forgot a comma?' in str(content):
                content = re.sub(r'(\w+)\s+(\w+)(\s*\))', r'\1, \2\3', content)
                fixes_applied.append("Fixed missing commas")
            
            # Fix 2: Fix unterminated strings
            if 'unterminated string literal' in str(content):
                content = self._fix_unterminated_strings(content)
                fixes_applied.append("Fixed unterminated strings")
            
            # Fix 3: Fix missing parentheses
            if 'closing parenthesis' in str(content) or 'opening parenthesis' in str(content):
                content = self._fix_parentheses(content)
                fixes_applied.append("Fixed parentheses")
            
            # Fix 4: Fix unexpected indent
            if 'unexpected indent' in str(content):
                content = self._fix_indentation(content)
                fixes_applied.append("Fixed indentation")
            
            # Fix 5: Fix invalid decimal literals
            if 'invalid decimal literal' in str(content):
                content = re.sub(r'(\d+)\.(\d+)\.(\d+)', r'\1.\2', content)
                fixes_applied.append("Fixed decimal literals")
            
            # Fix 6: Fix duplicate decorators
            content = self._fix_duplicate_decorators(content)
            if content != f.read():
                fixes_applied.append("Fixed duplicate decorators")
            
            # Write the fixed content
            if fixes_applied:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                logger.info(f"Applied fixes to {file_path}: {', '.join(fixes_applied)}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error fixing {file_path}: {e}")
            return False
    
    def _fix_unterminated_strings(self, content: str) -> str:
        """Fix unterminated string literals."""
        lines = content.split('\n')
        fixed_lines = []
        
        for line in lines:
            # Fix single quotes
            if line.count("'") % 2 == 1:
                line += "'"
            # Fix double quotes
            if line.count('"') % 2 == 1:
                line += '"'
            # Fix triple quotes
            if line.count('"""') % 2 == 1:
                line += '"""'
            if line.count("'''") % 2 == 1:
                line += "'''"
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_parentheses(self, content: str) -> str:
        """Fix unbalanced parentheses."""
        lines = content.split('\n')
        fixed_lines = []
        
        for line in lines:
            # Count different types of brackets
            open_paren = line.count('(')
            close_paren = line.count(')')
            open_bracket = line.count('[')
            close_bracket = line.count(']')
            open_brace = line.count('{')
            close_brace = line.count('}')
            
            # Fix parentheses
            if open_paren > close_paren:
                line += ')' * (open_paren - close_paren)
            elif close_paren > open_paren:
                # Remove extra closing parentheses
                extra = close_paren - open_paren
                for _ in range(extra):
                    if ')' in line:
                        line = line.replace(')', '', 1)
            
            # Fix brackets
            if open_bracket > close_bracket:
                line += ']' * (open_bracket - close_bracket)
            elif close_bracket > open_bracket:
                extra = close_bracket - open_bracket
                for _ in range(extra):
                    if ']' in line:
                        line = line.replace(']', '', 1)
            
            # Fix braces
            if open_brace > close_brace:
                line += '}' * (open_brace - close_brace)
            elif close_brace > open_brace:
                extra = close_brace - open_brace
                for _ in range(extra):
                    if '}' in line:
                        line = line.replace('}', '', 1)
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_indentation(self, content: str) -> str:
        """Fix indentation issues."""
        lines = content.split('\n')
        fixed_lines = []
        
        for i, line in enumerate(lines):
            if line.strip():  # Skip empty lines
                # Check if line should be indented
                if i > 0 and lines[i-1].strip().endswith(':'):
                    # Previous line ends with colon, this should be indented
                    if not line.startswith(' ') and not line.startswith('\t'):
                        line = '    ' + line
                elif line.startswith(' ') and not line.startswith('    '):
                    # Fix inconsistent indentation
                    line = '    ' + line.lstrip()
            
            fixed_lines.append(line)
        
        return '\n'.join(fixed_lines)
    
    def _fix_duplicate_decorators(self, content: str) -> str:
        """Fix duplicate decorators."""
        lines = content.split('\n')
        fixed_lines = []
        
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith('@'):
                # Collect all consecutive decorators
                decorators = []
                j = i
                while j < len(lines) and lines[j].strip().startswith('@'):
                    decorator = lines[j].strip()
                    if decorator not in decorators:
                        decorators.append(decorator)
                    j += 1
                
                # Add unique decorators
                for decorator in decorators:
                    fixed_lines.append(decorator)
                
                # Skip the original decorator lines
                i = j
            else:
                fixed_lines.append(line)
                i += 1
        
        return '\n'.join(fixed_lines)

def main():
    """Main function to run the syntax fixer."""
    fixer = PythonSyntaxFixer()
    
    print("🔧 Python Syntax Fixer")
    print("=" * 50)
    
    # Fix all files
    results = fixer.fix_all_files()
    
    print(f"\n📊 Results:")
    print(f"Total files: {results['total_files']}")
    print(f"Fixed files: {results['fixed_files']}")
    print(f"Failed files: {results['failed_files']}")
    print(f"Success rate: {results['success_rate']:.1%}")
    
    if fixer.fixed_files:
        print(f"\n✅ Successfully fixed files:")
        for file_path in fixer.fixed_files[:10]:  # Show first 10
            print(f"  - {file_path.name}")
        if len(fixer.fixed_files) > 10:
            print(f"  ... and {len(fixer.fixed_files) - 10} more")
    
    if fixer.failed_files:
        print(f"\n❌ Failed to fix files:")
        for file_path in fixer.failed_files[:10]:  # Show first 10
            print(f"  - {file_path.name}")
        if len(fixer.failed_files) > 10:
            print(f"  ... and {len(fixer.failed_files) - 10} more")
    
    print(f"\n🎉 Syntax fixing complete!")

if __name__ == "__main__":
    main()