#!/usr/bin/env python3
"""
Python Code Enhancer
Fixes common issues found in Python scripts and improves code quality
"""

import os
import ast
import re
import shutil
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PythonCodeEnhancer:
    """Enhances Python code quality by fixing common issues."""
    
    def __init__(self, base_dir: str = "/Users/steven/Documents/python"):
        self.base_dir = Path(base_dir)
        self.issues_found = []
        self.improvements_made = []
        
    def enhance_python_files(self, target_dir: str = None) -> Dict[str, Any]:
        """Enhance all Python files in the target directory."""
        if target_dir is None:
            target_dir = self.base_dir
        
        target_path = Path(target_dir)
        logger.info(f"🔧 Enhancing Python files in {target_path}")
        
        results = {
            "files_processed": 0,
            "files_enhanced": 0,
            "issues_fixed": [],
            "errors": [],
            "improvements": []
        }
        
        # Find all Python files
        python_files = list(target_path.rglob("*.py"))
        logger.info(f"Found {len(python_files)} Python files to process")
        
        for py_file in python_files:
            try:
                logger.info(f"Processing: {py_file}")
                results["files_processed"] += 1
                
                # Enhance the file
                enhancement_result = self.enhance_single_file(py_file)
                
                if enhancement_result["enhanced"]:
                    results["files_enhanced"] += 1
                    results["improvements"].extend(enhancement_result["improvements"])
                
                results["issues_fixed"].extend(enhancement_result["issues_fixed"])
                
            except Exception as e:
                error_msg = f"Error processing {py_file}: {e}"
                logger.error(error_msg)
                results["errors"].append(error_msg)
        
        logger.info(f"✅ Enhancement complete: {results['files_enhanced']}/{results['files_processed']} files enhanced")
        return results
    
    def enhance_single_file(self, file_path: Path) -> Dict[str, Any]:
        """Enhance a single Python file."""
        result = {
            "enhanced": False,
            "issues_fixed": [],
            "improvements": []
        }
        
        try:
            # Read the file
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # Apply enhancements
            content = self._fix_imports(content, file_path)
            content = self._add_type_hints(content)
            content = self._add_docstrings(content)
            content = self._add_error_handling(content)
            content = self._fix_code_style(content)
            content = self._add_logging(content)
            content = self._add_main_guard(content)
            
            # Check if changes were made
            if content != original_content:
                # Create backup
                backup_path = file_path.with_suffix('.py.backup')
                shutil.copy2(file_path, backup_path)
                
                # Write enhanced content
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                result["enhanced"] = True
                result["improvements"] = [
                    "Fixed imports",
                    "Added type hints",
                    "Added docstrings",
                    "Added error handling",
                    "Fixed code style",
                    "Added logging",
                    "Added main guard"
                ]
                
                logger.info(f"✅ Enhanced {file_path}")
            else:
                logger.info(f"ℹ️  No changes needed for {file_path}")
                
        except Exception as e:
            logger.error(f"Error enhancing {file_path}: {e}")
            result["issues_fixed"].append(f"Error: {e}")
        
        return result
    
    def _fix_imports(self, content: str, file_path: Path) -> str:
        """Fix import issues and organize imports."""
        lines = content.split('\n')
        new_lines = []
        imports = []
        other_lines = []
        
        # Separate imports from other code
        in_imports = True
        for line in lines:
            stripped = line.strip()
            if in_imports and (stripped.startswith('import ') or stripped.startswith('from ')):
                imports.append(line)
            else:
                in_imports = False
                other_lines.append(line)
        
        # Organize imports
        if imports:
            # Remove TODO comments from imports
            clean_imports = []
            for imp in imports:
                if not imp.strip().startswith('# TODO'):
                    clean_imports.append(imp)
            
            # Add standard library imports
            std_imports = [
                "import os",
                "import sys",
                "import logging",
                "from pathlib import Path",
                "from typing import Dict, List, Any, Optional, Tuple, Union",
                "from datetime import datetime",
                "import json",
                "import re"
            ]
            
            # Add missing standard imports
            existing_imports = [imp.strip() for imp in clean_imports]
            for std_imp in std_imports:
                if std_imp not in existing_imports:
                    clean_imports.insert(0, std_imp)
            
            # Add logger setup
            if not any('logger' in imp for imp in clean_imports):
                clean_imports.append("")
                clean_imports.append("# Configure logging")
                clean_imports.append("logger = logging.getLogger(__name__)")
            
            new_lines.extend(clean_imports)
            new_lines.append("")
        
        new_lines.extend(other_lines)
        return '\n'.join(new_lines)
    
    def _add_type_hints(self, content: str) -> str:
        """Add type hints to functions."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return content
        
        lines = content.split('\n')
        
        # Find function definitions without type hints
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Check if function has type hints
                has_return_annotation = node.returns is not None
                has_args_annotation = any(arg.annotation is not None for arg in node.args.args)
                
                if not has_return_annotation or not has_args_annotation:
                    # Add basic type hints
                    func_line = node.lineno - 1
                    func_def = lines[func_line]
                    
                    # Add return type annotation if missing
                    if not has_return_annotation and not func_def.strip().endswith(':'):
                        if '->' not in func_def:
                            # Determine return type based on function name
                            return_type = self._guess_return_type(node.name)
                            func_def = func_def.replace('):', f') -> {return_type}:')
                            lines[func_line] = func_def
                    
                    # Add parameter type hints if missing
                    if not has_args_annotation:
                        # This is a simplified approach - in practice, you'd need more sophisticated logic
                        pass
        
        return '\n'.join(lines)
    
    def _guess_return_type(self, func_name: str) -> str:
        """Guess return type based on function name."""
        if any(keyword in func_name.lower() for keyword in ['get', 'find', 'search', 'load', 'read']):
            return 'Optional[str]'
        elif any(keyword in func_name.lower() for keyword in ['list', 'get_all', 'find_all']):
            return 'List[Any]'
        elif any(keyword in func_name.lower() for keyword in ['check', 'is_', 'has_', 'can_']):
            return 'bool'
        elif any(keyword in func_name.lower() for keyword in ['count', 'size', 'length']):
            return 'int'
        else:
            return 'Any'
    
    def _add_docstrings(self, content: str) -> str:
        """Add docstrings to functions and classes."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return content
        
        lines = content.split('\n')
        
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                # Check if already has docstring
                if (node.body and 
                    isinstance(node.body[0], ast.Expr) and 
                    isinstance(node.body[0].value, ast.Constant) and
                    isinstance(node.body[0].value.value, str)):
                    continue
                
                # Add docstring
                node_line = node.lineno - 1
                indent = len(lines[node_line]) - len(lines[node_line].lstrip())
                
                if isinstance(node, ast.FunctionDef):
                    docstring = f'    """{node.name} function."""'
                else:
                    docstring = f'    """{node.name} class."""'
                
                # Insert docstring after the definition
                if node.body:
                    lines.insert(node_line + 1, ' ' * indent + docstring)
                else:
                    lines.insert(node_line + 1, ' ' * indent + docstring)
                    lines.insert(node_line + 2, ' ' * indent + '    pass')
        
        return '\n'.join(lines)
    
    def _add_error_handling(self, content: str) -> str:
        """Add basic error handling to functions."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return content
        
        lines = content.split('\n')
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Check if function already has try/except
                has_try_except = any(
                    isinstance(stmt, ast.Try) for stmt in node.body
                )
                
                if not has_try_except and len(node.body) > 0:
                    # Wrap function body in try/except
                    func_line = node.lineno - 1
                    indent = len(lines[func_line]) - len(lines[func_line].lstrip())
                    
                    # Find the end of the function
                    func_end = self._find_function_end(lines, func_line)
                    
                    # Add try/except wrapper
                    try_line = ' ' * (indent + 4) + 'try:'
                    except_line = ' ' * (indent + 4) + 'except Exception as e:'
                    logger_line = ' ' * (indent + 8) + 'logger.error(f"Error in {func_name}: {e}")'
                    raise_line = ' ' * (indent + 8) + 'raise'
                    
                    # Insert try/except
                    lines.insert(func_end, ' ' * (indent + 4) + 'try:')
                    lines.insert(func_end + 1, ' ' * (indent + 8) + 'pass  # Function body')
                    lines.insert(func_end + 2, ' ' * (indent + 4) + 'except Exception as e:')
                    lines.insert(func_end + 3, ' ' * (indent + 8) + f'logger.error(f"Error in {node.name}: {e}")')
                    lines.insert(func_end + 4, ' ' * (indent + 8) + 'raise')
        
        return '\n'.join(lines)
    
    def _find_function_end(self, lines: List[str], start_line: int) -> int:
        """Find the end line of a function."""
        indent = len(lines[start_line]) - len(lines[start_line].lstrip())
        
        for i in range(start_line + 1, len(lines)):
            line = lines[i]
            if line.strip() and len(line) - len(line.lstrip()) <= indent:
                return i
        
        return len(lines)
    
    def _fix_code_style(self, content: str) -> str:
        """Fix basic code style issues."""
        lines = content.split('\n')
        new_lines = []
        
        for line in lines:
            # Remove trailing whitespace
            line = line.rstrip()
            
            # Fix spacing around operators
            line = re.sub(r'(\w+)\s*=\s*(\w+)', r'\1 = \2', line)
            line = re.sub(r'(\w+)\s*==\s*(\w+)', r'\1 == \2', line)
            line = re.sub(r'(\w+)\s*!=\s*(\w+)', r'\1 != \2', line)
            
            # Fix spacing around commas
            line = re.sub(r'\s*,\s*', ', ', line)
            
            new_lines.append(line)
        
        return '\n'.join(new_lines)
    
    def _add_logging(self, content: str) -> str:
        """Add logging statements to functions."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return content
        
        lines = content.split('\n')
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                # Add logging at function start
                func_line = node.lineno - 1
                indent = len(lines[func_line]) - len(lines[func_line].lstrip())
                
                # Check if logging already exists
                has_logging = any(
                    'logger.' in line for line in lines[func_line:func_line + 5]
                )
                
                if not has_logging:
                    log_line = ' ' * (indent + 4) + f'logger.info(f"Starting {node.name}")'
                    lines.insert(func_line + 1, log_line)
        
        return '\n'.join(new_lines)
    
    def _add_main_guard(self, content: str) -> str:
        """Add main guard if not present."""
        if 'if __name__ == "__main__":' not in content:
            content += '\n\nif __name__ == "__main__":\n    main()\n'
        
        return content
    
    def create_requirements_file(self, target_dir: str = None) -> str:
        """Create a comprehensive requirements.txt file."""
        if target_dir is None:
            target_dir = self.base_dir
        
        target_path = Path(target_dir)
        requirements_file = target_path / "requirements.txt"
        
        # Common Python packages based on the analysis
        requirements = """# Core dependencies
requests>=2.31.0
pathlib2>=2.3.7
typing-extensions>=4.7.0

# Data processing
pandas>=2.0.0
numpy>=1.24.0
openpyxl>=3.1.0

# Web frameworks
flask>=2.3.0
fastapi>=0.100.0
django>=4.2.0

# AI/ML
openai>=1.0.0
transformers>=4.30.0
torch>=2.0.0
scikit-learn>=1.3.0

# Image processing
Pillow>=10.0.0
opencv-python>=4.8.0
matplotlib>=3.7.0

# Audio/Video
moviepy>=1.0.3
pydub>=0.25.1
whisper-openai>=20231117

# Development tools
pytest>=7.4.0
black>=23.7.0
flake8>=6.0.0
mypy>=1.5.0
isort>=5.12.0

# Utilities
python-dotenv>=1.0.0
click>=8.1.0
tqdm>=4.65.0
rich>=13.5.0
"""
        
        with open(requirements_file, 'w') as f:
            f.write(requirements)
        
        logger.info(f"✅ Created requirements.txt at {requirements_file}")
        return str(requirements_file)
    
    def create_development_requirements(self, target_dir: str = None) -> str:
        """Create a requirements-dev.txt file."""
        if target_dir is None:
            target_dir = self.base_dir
        
        target_path = Path(target_dir)
        dev_requirements_file = target_path / "requirements-dev.txt"
        
        dev_requirements = """# Development dependencies
-r requirements.txt

# Testing
pytest>=7.4.0
pytest-cov>=4.1.0
pytest-mock>=3.11.0
pytest-asyncio>=0.21.0

# Code quality
black>=23.7.0
flake8>=6.0.0
mypy>=1.5.0
isort>=5.12.0
pre-commit>=3.3.0

# Documentation
sphinx>=7.1.0
sphinx-rtd-theme>=1.3.0
myst-parser>=2.0.0

# Debugging
ipdb>=0.13.0
pdbpp>=0.10.0

# Profiling
memory-profiler>=0.61.0
line-profiler>=4.1.0

# Type checking
types-requests>=2.31.0
types-PyYAML>=6.0.0
"""
        
        with open(dev_requirements_file, 'w') as f:
            f.write(dev_requirements)
        
        logger.info(f"✅ Created requirements-dev.txt at {dev_requirements_file}")
        return str(dev_requirements_file)

def main():
    """Main function to run the Python code enhancer."""
    enhancer = PythonCodeEnhancer()
    
    print("🐍 Python Code Enhancer")
    print("=" * 50)
    
    # Enhance Python files
    print("🔧 Enhancing Python files...")
    results = enhancer.enhance_python_files()
    
    print(f"\n📊 Results:")
    print(f"Files processed: {results['files_processed']}")
    print(f"Files enhanced: {results['files_enhanced']}")
    print(f"Issues fixed: {len(results['issues_fixed'])}")
    print(f"Improvements made: {len(results['improvements'])}")
    
    if results['errors']:
        print(f"\n❌ Errors:")
        for error in results['errors'][:5]:
            print(f"  - {error}")
    
    # Create requirements files
    print("\n📦 Creating requirements files...")
    enhancer.create_requirements_file()
    enhancer.create_development_requirements()
    
    print("\n🎉 Python code enhancement complete!")

if __name__ == "__main__":
    main()