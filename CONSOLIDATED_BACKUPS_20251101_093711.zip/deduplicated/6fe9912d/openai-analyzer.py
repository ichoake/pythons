import os
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env
load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def analyze_text(text):
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",  # Ensure you're using a chat model like gpt-3.5-turbo
        messages=[
            {
                "role": "system",
                "content": "You are a helpful assistant that analyzes song lyrics.",
            },
            {
                "role": "user",
                "content": f"Analyze the following song transcript and extract the main themes, emotions, and keywords: {text}",
            },
        ],
        max_tokens=1050,
        temperature=0.7,
    )
    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    import sys

    transcript_file = sys.argv[1]
    output_file = sys.argv[2]
    with open(transcript_file, "r") as f:
        transcript = f.read()

    analysis = analyze_text(transcript)
    with open(output_file, "w") as f:
        f.write(analysis)
