#!/usr/bin/env python3
"""
Check Current Quality Status
============================

Shows the current quality status and dashboard.
"""

import sys
import json
from pathlib import Path

# Add the development tools to the path
sys.path.insert(0, str(Path(__file__).parent / "06_development_tools"))

from simple_quality_monitor import SimpleQualityMonitor

if __name__ == "__main__":
    base_path = Path(__file__).parent
    monitor = SimpleQualityMonitor(str(base_path))
    
    print("📊 Current Quality Status")
    print("=" * 50)
    
    # Run analysis once
    metrics = monitor.run_analysis()
    
    # Show dashboard
    dashboard = monitor.get_quality_dashboard()
    
    if "error" in dashboard:
        print(f"❌ {dashboard['error']}")
    else:
        current = dashboard["current_metrics"]
        print(f"📁 Total Files: {current['total_files']:,}")
        print(f"📝 Total Lines: {current['total_lines']:,}")
        print(f"🔧 Functions: {current['total_functions']:,}")
        print(f"🏗️ Classes: {current['total_classes']:,}")
        print(f"⭐ Quality Score: {current['average_quality_score']:.1f}/100")
        print(f"🧠 Semantic Score: {current['semantic_score']:.1f}/100")
        print(f"🔧 Maintainability: {current['maintainability_score']:.1f}/100")
        print(f"⚡ Performance Potential: {current['performance_potential']:.1f}/100")
        
        # Coverage metrics
        total_files = current['total_files']
        if total_files > 0:
            docstring_coverage = (current['files_with_docstrings'] / total_files) * 100
            type_hint_coverage = (current['files_with_type_hints'] / total_files) * 100
            error_handling_coverage = (current['files_with_error_handling'] / total_files) * 100
            logging_coverage = (current['files_with_logging'] / total_files) * 100
            
            print(f"\n📊 Coverage Metrics:")
            print(f"📖 Docstrings: {docstring_coverage:.1f}%")
            print(f"🏷️ Type Hints: {type_hint_coverage:.1f}%")
            print(f"⚠️ Error Handling: {error_handling_coverage:.1f}%")
            print(f"📝 Logging: {logging_coverage:.1f}%")
        
        # Trends
        if dashboard["trends"]:
            print(f"\n📈 Trends:")
            for trend in dashboard["trends"]:
                direction = "📈" if trend["trend_direction"] == "improving" else "📉" if trend["trend_direction"] == "declining" else "➡️"
                print(f"{direction} {trend['metric_name']}: {trend['change_percentage']:+.1f}%")
        
        # Recent alerts (if available)
        if "recent_alerts" in dashboard and dashboard["recent_alerts"]:
            print(f"\n🚨 Recent Alerts ({len(dashboard['recent_alerts'])}):")
            for alert in dashboard["recent_alerts"][:5]:  # Show last 5
                severity_icon = "🔴" if alert["severity"] == "high" else "🟡" if alert["severity"] == "medium" else "🟢"
                print(f"{severity_icon} {alert['message']}")
        
        print(f"\n📅 Last Analysis: {dashboard['last_analysis']}")
        print(f"📊 History Length: {dashboard['history_length']} records")
